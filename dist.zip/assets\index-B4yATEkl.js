(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))s(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const h of c.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&s(h)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function s(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();function $_(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var fh={exports:{}},Fo={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var P0;function Ky(){if(P0)return Fo;P0=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function i(s,l,c){var h=null;if(c!==void 0&&(h=""+c),l.key!==void 0&&(h=""+l.key),"key"in l){c={};for(var d in l)d!=="key"&&(c[d]=l[d])}else c=l;return l=c.ref,{$$typeof:r,type:s,key:h,ref:l!==void 0?l:null,props:c}}return Fo.Fragment=t,Fo.jsx=i,Fo.jsxs=i,Fo}var z0;function Qy(){return z0||(z0=1,fh.exports=Ky()),fh.exports}var D=Qy(),hh={exports:{}},ae={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var I0;function Jy(){if(I0)return ae;I0=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),h=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),_=Symbol.for("react.activity"),y=Symbol.iterator;function v(O){return O===null||typeof O!="object"?null:(O=y&&O[y]||O["@@iterator"],typeof O=="function"?O:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},E=Object.assign,M={};function x(O,at,vt){this.props=O,this.context=at,this.refs=M,this.updater=vt||b}x.prototype.isReactComponent={},x.prototype.setState=function(O,at){if(typeof O!="object"&&typeof O!="function"&&O!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,O,at,"setState")},x.prototype.forceUpdate=function(O){this.updater.enqueueForceUpdate(this,O,"forceUpdate")};function P(){}P.prototype=x.prototype;function N(O,at,vt){this.props=O,this.context=at,this.refs=M,this.updater=vt||b}var w=N.prototype=new P;w.constructor=N,E(w,x.prototype),w.isPureReactComponent=!0;var k=Array.isArray;function H(){}var I={H:null,A:null,T:null,S:null},j=Object.prototype.hasOwnProperty;function L(O,at,vt){var Y=vt.ref;return{$$typeof:r,type:O,key:at,ref:Y!==void 0?Y:null,props:vt}}function R(O,at){return L(O.type,at,O.props)}function B(O){return typeof O=="object"&&O!==null&&O.$$typeof===r}function tt(O){var at={"=":"=0",":":"=2"};return"$"+O.replace(/[=:]/g,function(vt){return at[vt]})}var et=/\/+/g;function ut(O,at){return typeof O=="object"&&O!==null&&O.key!=null?tt(""+O.key):at.toString(36)}function ft(O){switch(O.status){case"fulfilled":return O.value;case"rejected":throw O.reason;default:switch(typeof O.status=="string"?O.then(H,H):(O.status="pending",O.then(function(at){O.status==="pending"&&(O.status="fulfilled",O.value=at)},function(at){O.status==="pending"&&(O.status="rejected",O.reason=at)})),O.status){case"fulfilled":return O.value;case"rejected":throw O.reason}}throw O}function z(O,at,vt,Y,st){var xt=typeof O;(xt==="undefined"||xt==="boolean")&&(O=null);var bt=!1;if(O===null)bt=!0;else switch(xt){case"bigint":case"string":case"number":bt=!0;break;case"object":switch(O.$$typeof){case r:case t:bt=!0;break;case g:return bt=O._init,z(bt(O._payload),at,vt,Y,st)}}if(bt)return st=st(O),bt=Y===""?"."+ut(O,0):Y,k(st)?(vt="",bt!=null&&(vt=bt.replace(et,"$&/")+"/"),z(st,at,vt,"",function(Yt){return Yt})):st!=null&&(B(st)&&(st=R(st,vt+(st.key==null||O&&O.key===st.key?"":(""+st.key).replace(et,"$&/")+"/")+bt)),at.push(st)),1;bt=0;var Ft=Y===""?".":Y+":";if(k(O))for(var Xt=0;Xt<O.length;Xt++)Y=O[Xt],xt=Ft+ut(Y,Xt),bt+=z(Y,at,vt,xt,st);else if(Xt=v(O),typeof Xt=="function")for(O=Xt.call(O),Xt=0;!(Y=O.next()).done;)Y=Y.value,xt=Ft+ut(Y,Xt++),bt+=z(Y,at,vt,xt,st);else if(xt==="object"){if(typeof O.then=="function")return z(ft(O),at,vt,Y,st);throw at=String(O),Error("Objects are not valid as a React child (found: "+(at==="[object Object]"?"object with keys {"+Object.keys(O).join(", ")+"}":at)+"). If you meant to render a collection of children, use an array instead.")}return bt}function W(O,at,vt){if(O==null)return O;var Y=[],st=0;return z(O,Y,"","",function(xt){return at.call(vt,xt,st++)}),Y}function X(O){if(O._status===-1){var at=O._result;at=at(),at.then(function(vt){(O._status===0||O._status===-1)&&(O._status=1,O._result=vt)},function(vt){(O._status===0||O._status===-1)&&(O._status=2,O._result=vt)}),O._status===-1&&(O._status=0,O._result=at)}if(O._status===1)return O._result.default;throw O._result}var _t=typeof reportError=="function"?reportError:function(O){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var at=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof O=="object"&&O!==null&&typeof O.message=="string"?String(O.message):String(O),error:O});if(!window.dispatchEvent(at))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",O);return}console.error(O)},Et={map:W,forEach:function(O,at,vt){W(O,function(){at.apply(this,arguments)},vt)},count:function(O){var at=0;return W(O,function(){at++}),at},toArray:function(O){return W(O,function(at){return at})||[]},only:function(O){if(!B(O))throw Error("React.Children.only expected to receive a single React element child.");return O}};return ae.Activity=_,ae.Children=Et,ae.Component=x,ae.Fragment=i,ae.Profiler=l,ae.PureComponent=N,ae.StrictMode=s,ae.Suspense=m,ae.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=I,ae.__COMPILER_RUNTIME={__proto__:null,c:function(O){return I.H.useMemoCache(O)}},ae.cache=function(O){return function(){return O.apply(null,arguments)}},ae.cacheSignal=function(){return null},ae.cloneElement=function(O,at,vt){if(O==null)throw Error("The argument must be a React element, but you passed "+O+".");var Y=E({},O.props),st=O.key;if(at!=null)for(xt in at.key!==void 0&&(st=""+at.key),at)!j.call(at,xt)||xt==="key"||xt==="__self"||xt==="__source"||xt==="ref"&&at.ref===void 0||(Y[xt]=at[xt]);var xt=arguments.length-2;if(xt===1)Y.children=vt;else if(1<xt){for(var bt=Array(xt),Ft=0;Ft<xt;Ft++)bt[Ft]=arguments[Ft+2];Y.children=bt}return L(O.type,st,Y)},ae.createContext=function(O){return O={$$typeof:h,_currentValue:O,_currentValue2:O,_threadCount:0,Provider:null,Consumer:null},O.Provider=O,O.Consumer={$$typeof:c,_context:O},O},ae.createElement=function(O,at,vt){var Y,st={},xt=null;if(at!=null)for(Y in at.key!==void 0&&(xt=""+at.key),at)j.call(at,Y)&&Y!=="key"&&Y!=="__self"&&Y!=="__source"&&(st[Y]=at[Y]);var bt=arguments.length-2;if(bt===1)st.children=vt;else if(1<bt){for(var Ft=Array(bt),Xt=0;Xt<bt;Xt++)Ft[Xt]=arguments[Xt+2];st.children=Ft}if(O&&O.defaultProps)for(Y in bt=O.defaultProps,bt)st[Y]===void 0&&(st[Y]=bt[Y]);return L(O,xt,st)},ae.createRef=function(){return{current:null}},ae.forwardRef=function(O){return{$$typeof:d,render:O}},ae.isValidElement=B,ae.lazy=function(O){return{$$typeof:g,_payload:{_status:-1,_result:O},_init:X}},ae.memo=function(O,at){return{$$typeof:p,type:O,compare:at===void 0?null:at}},ae.startTransition=function(O){var at=I.T,vt={};I.T=vt;try{var Y=O(),st=I.S;st!==null&&st(vt,Y),typeof Y=="object"&&Y!==null&&typeof Y.then=="function"&&Y.then(H,_t)}catch(xt){_t(xt)}finally{at!==null&&vt.types!==null&&(at.types=vt.types),I.T=at}},ae.unstable_useCacheRefresh=function(){return I.H.useCacheRefresh()},ae.use=function(O){return I.H.use(O)},ae.useActionState=function(O,at,vt){return I.H.useActionState(O,at,vt)},ae.useCallback=function(O,at){return I.H.useCallback(O,at)},ae.useContext=function(O){return I.H.useContext(O)},ae.useDebugValue=function(){},ae.useDeferredValue=function(O,at){return I.H.useDeferredValue(O,at)},ae.useEffect=function(O,at){return I.H.useEffect(O,at)},ae.useEffectEvent=function(O){return I.H.useEffectEvent(O)},ae.useId=function(){return I.H.useId()},ae.useImperativeHandle=function(O,at,vt){return I.H.useImperativeHandle(O,at,vt)},ae.useInsertionEffect=function(O,at){return I.H.useInsertionEffect(O,at)},ae.useLayoutEffect=function(O,at){return I.H.useLayoutEffect(O,at)},ae.useMemo=function(O,at){return I.H.useMemo(O,at)},ae.useOptimistic=function(O,at){return I.H.useOptimistic(O,at)},ae.useReducer=function(O,at,vt){return I.H.useReducer(O,at,vt)},ae.useRef=function(O){return I.H.useRef(O)},ae.useState=function(O){return I.H.useState(O)},ae.useSyncExternalStore=function(O,at,vt){return I.H.useSyncExternalStore(O,at,vt)},ae.useTransition=function(){return I.H.useTransition()},ae.version="19.2.8",ae}var B0;function Bd(){return B0||(B0=1,hh.exports=Jy()),hh.exports}var ne=Bd();const $y=$_(ne);var dh={exports:{}},Ho={},ph={exports:{}},mh={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var F0;function tS(){return F0||(F0=1,(function(r){function t(z,W){var X=z.length;z.push(W);t:for(;0<X;){var _t=X-1>>>1,Et=z[_t];if(0<l(Et,W))z[_t]=W,z[X]=Et,X=_t;else break t}}function i(z){return z.length===0?null:z[0]}function s(z){if(z.length===0)return null;var W=z[0],X=z.pop();if(X!==W){z[0]=X;t:for(var _t=0,Et=z.length,O=Et>>>1;_t<O;){var at=2*(_t+1)-1,vt=z[at],Y=at+1,st=z[Y];if(0>l(vt,X))Y<Et&&0>l(st,vt)?(z[_t]=st,z[Y]=X,_t=Y):(z[_t]=vt,z[at]=X,_t=at);else if(Y<Et&&0>l(st,X))z[_t]=st,z[Y]=X,_t=Y;else break t}}return W}function l(z,W){var X=z.sortIndex-W.sortIndex;return X!==0?X:z.id-W.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var h=Date,d=h.now();r.unstable_now=function(){return h.now()-d}}var m=[],p=[],g=1,_=null,y=3,v=!1,b=!1,E=!1,M=!1,x=typeof setTimeout=="function"?setTimeout:null,P=typeof clearTimeout=="function"?clearTimeout:null,N=typeof setImmediate<"u"?setImmediate:null;function w(z){for(var W=i(p);W!==null;){if(W.callback===null)s(p);else if(W.startTime<=z)s(p),W.sortIndex=W.expirationTime,t(m,W);else break;W=i(p)}}function k(z){if(E=!1,w(z),!b)if(i(m)!==null)b=!0,H||(H=!0,tt());else{var W=i(p);W!==null&&ft(k,W.startTime-z)}}var H=!1,I=-1,j=5,L=-1;function R(){return M?!0:!(r.unstable_now()-L<j)}function B(){if(M=!1,H){var z=r.unstable_now();L=z;var W=!0;try{t:{b=!1,E&&(E=!1,P(I),I=-1),v=!0;var X=y;try{e:{for(w(z),_=i(m);_!==null&&!(_.expirationTime>z&&R());){var _t=_.callback;if(typeof _t=="function"){_.callback=null,y=_.priorityLevel;var Et=_t(_.expirationTime<=z);if(z=r.unstable_now(),typeof Et=="function"){_.callback=Et,w(z),W=!0;break e}_===i(m)&&s(m),w(z)}else s(m);_=i(m)}if(_!==null)W=!0;else{var O=i(p);O!==null&&ft(k,O.startTime-z),W=!1}}break t}finally{_=null,y=X,v=!1}W=void 0}}finally{W?tt():H=!1}}}var tt;if(typeof N=="function")tt=function(){N(B)};else if(typeof MessageChannel<"u"){var et=new MessageChannel,ut=et.port2;et.port1.onmessage=B,tt=function(){ut.postMessage(null)}}else tt=function(){x(B,0)};function ft(z,W){I=x(function(){z(r.unstable_now())},W)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(z){z.callback=null},r.unstable_forceFrameRate=function(z){0>z||125<z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):j=0<z?Math.floor(1e3/z):5},r.unstable_getCurrentPriorityLevel=function(){return y},r.unstable_next=function(z){switch(y){case 1:case 2:case 3:var W=3;break;default:W=y}var X=y;y=W;try{return z()}finally{y=X}},r.unstable_requestPaint=function(){M=!0},r.unstable_runWithPriority=function(z,W){switch(z){case 1:case 2:case 3:case 4:case 5:break;default:z=3}var X=y;y=z;try{return W()}finally{y=X}},r.unstable_scheduleCallback=function(z,W,X){var _t=r.unstable_now();switch(typeof X=="object"&&X!==null?(X=X.delay,X=typeof X=="number"&&0<X?_t+X:_t):X=_t,z){case 1:var Et=-1;break;case 2:Et=250;break;case 5:Et=1073741823;break;case 4:Et=1e4;break;default:Et=5e3}return Et=X+Et,z={id:g++,callback:W,priorityLevel:z,startTime:X,expirationTime:Et,sortIndex:-1},X>_t?(z.sortIndex=X,t(p,z),i(m)===null&&z===i(p)&&(E?(P(I),I=-1):E=!0,ft(k,X-_t))):(z.sortIndex=Et,t(m,z),b||v||(b=!0,H||(H=!0,tt()))),z},r.unstable_shouldYield=R,r.unstable_wrapCallback=function(z){var W=y;return function(){var X=y;y=W;try{return z.apply(this,arguments)}finally{y=X}}}})(mh)),mh}var H0;function eS(){return H0||(H0=1,ph.exports=tS()),ph.exports}var gh={exports:{}},Ln={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var G0;function nS(){if(G0)return Ln;G0=1;var r=Bd();function t(m){var p="https://react.dev/errors/"+m;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)p+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+m+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var s={d:{f:i,r:function(){throw Error(t(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(m,p,g){var _=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:_==null?null:""+_,children:m,containerInfo:p,implementation:g}}var h=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(m,p){if(m==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return Ln.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Ln.createPortal=function(m,p){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(t(299));return c(m,p,null,g)},Ln.flushSync=function(m){var p=h.T,g=s.p;try{if(h.T=null,s.p=2,m)return m()}finally{h.T=p,s.p=g,s.d.f()}},Ln.preconnect=function(m,p){typeof m=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,s.d.C(m,p))},Ln.prefetchDNS=function(m){typeof m=="string"&&s.d.D(m)},Ln.preinit=function(m,p){if(typeof m=="string"&&p&&typeof p.as=="string"){var g=p.as,_=d(g,p.crossOrigin),y=typeof p.integrity=="string"?p.integrity:void 0,v=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;g==="style"?s.d.S(m,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:_,integrity:y,fetchPriority:v}):g==="script"&&s.d.X(m,{crossOrigin:_,integrity:y,fetchPriority:v,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},Ln.preinitModule=function(m,p){if(typeof m=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var g=d(p.as,p.crossOrigin);s.d.M(m,{crossOrigin:g,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&s.d.M(m)},Ln.preload=function(m,p){if(typeof m=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var g=p.as,_=d(g,p.crossOrigin);s.d.L(m,g,{crossOrigin:_,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},Ln.preloadModule=function(m,p){if(typeof m=="string")if(p){var g=d(p.as,p.crossOrigin);s.d.m(m,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:g,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else s.d.m(m)},Ln.requestFormReset=function(m){s.d.r(m)},Ln.unstable_batchedUpdates=function(m,p){return m(p)},Ln.useFormState=function(m,p,g){return h.H.useFormState(m,p,g)},Ln.useFormStatus=function(){return h.H.useHostTransitionStatus()},Ln.version="19.2.8",Ln}var V0;function iS(){if(V0)return gh.exports;V0=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),gh.exports=nS(),gh.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var k0;function aS(){if(k0)return Ho;k0=1;var r=eS(),t=Bd(),i=iS();function s(e){var n="https://react.dev/errors/"+e;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)n+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+e+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function c(e){var n=e,a=e;if(e.alternate)for(;n.return;)n=n.return;else{e=n;do n=e,(n.flags&4098)!==0&&(a=n.return),e=n.return;while(e)}return n.tag===3?a:null}function h(e){if(e.tag===13){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function d(e){if(e.tag===31){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function m(e){if(c(e)!==e)throw Error(s(188))}function p(e){var n=e.alternate;if(!n){if(n=c(e),n===null)throw Error(s(188));return n!==e?null:e}for(var a=e,o=n;;){var u=a.return;if(u===null)break;var f=u.alternate;if(f===null){if(o=u.return,o!==null){a=o;continue}break}if(u.child===f.child){for(f=u.child;f;){if(f===a)return m(u),e;if(f===o)return m(u),n;f=f.sibling}throw Error(s(188))}if(a.return!==o.return)a=u,o=f;else{for(var S=!1,A=u.child;A;){if(A===a){S=!0,a=u,o=f;break}if(A===o){S=!0,o=u,a=f;break}A=A.sibling}if(!S){for(A=f.child;A;){if(A===a){S=!0,a=f,o=u;break}if(A===o){S=!0,o=f,a=u;break}A=A.sibling}if(!S)throw Error(s(189))}}if(a.alternate!==o)throw Error(s(190))}if(a.tag!==3)throw Error(s(188));return a.stateNode.current===a?e:n}function g(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e;for(e=e.child;e!==null;){if(n=g(e),n!==null)return n;e=e.sibling}return null}var _=Object.assign,y=Symbol.for("react.element"),v=Symbol.for("react.transitional.element"),b=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),M=Symbol.for("react.strict_mode"),x=Symbol.for("react.profiler"),P=Symbol.for("react.consumer"),N=Symbol.for("react.context"),w=Symbol.for("react.forward_ref"),k=Symbol.for("react.suspense"),H=Symbol.for("react.suspense_list"),I=Symbol.for("react.memo"),j=Symbol.for("react.lazy"),L=Symbol.for("react.activity"),R=Symbol.for("react.memo_cache_sentinel"),B=Symbol.iterator;function tt(e){return e===null||typeof e!="object"?null:(e=B&&e[B]||e["@@iterator"],typeof e=="function"?e:null)}var et=Symbol.for("react.client.reference");function ut(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===et?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case E:return"Fragment";case x:return"Profiler";case M:return"StrictMode";case k:return"Suspense";case H:return"SuspenseList";case L:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case b:return"Portal";case N:return e.displayName||"Context";case P:return(e._context.displayName||"Context")+".Consumer";case w:var n=e.render;return e=e.displayName,e||(e=n.displayName||n.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case I:return n=e.displayName||null,n!==null?n:ut(e.type)||"Memo";case j:n=e._payload,e=e._init;try{return ut(e(n))}catch{}}return null}var ft=Array.isArray,z=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,W=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,X={pending:!1,data:null,method:null,action:null},_t=[],Et=-1;function O(e){return{current:e}}function at(e){0>Et||(e.current=_t[Et],_t[Et]=null,Et--)}function vt(e,n){Et++,_t[Et]=e.current,e.current=n}var Y=O(null),st=O(null),xt=O(null),bt=O(null);function Ft(e,n){switch(vt(xt,n),vt(st,e),vt(Y,null),n.nodeType){case 9:case 11:e=(e=n.documentElement)&&(e=e.namespaceURI)?a0(e):0;break;default:if(e=n.tagName,n=n.namespaceURI)n=a0(n),e=s0(n,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}at(Y),vt(Y,e)}function Xt(){at(Y),at(st),at(xt)}function Yt(e){e.memoizedState!==null&&vt(bt,e);var n=Y.current,a=s0(n,e.type);n!==a&&(vt(st,e),vt(Y,a))}function ze(e){st.current===e&&(at(Y),at(st)),bt.current===e&&(at(bt),Po._currentValue=X)}var Ue,fe;function G(e){if(Ue===void 0)try{throw Error()}catch(a){var n=a.stack.trim().match(/\n( *(at )?)/);Ue=n&&n[1]||"",fe=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ue+e+fe}var Je=!1;function le(e,n){if(!e||Je)return"";Je=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var yt=function(){throw Error()};if(Object.defineProperty(yt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(yt,[])}catch(ct){var rt=ct}Reflect.construct(e,[],yt)}else{try{yt.call()}catch(ct){rt=ct}e.call(yt.prototype)}}else{try{throw Error()}catch(ct){rt=ct}(yt=e())&&typeof yt.catch=="function"&&yt.catch(function(){})}}catch(ct){if(ct&&rt&&typeof ct.stack=="string")return[ct.stack,rt.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var f=o.DetermineComponentFrameRoot(),S=f[0],A=f[1];if(S&&A){var F=S.split(`
`),it=A.split(`
`);for(u=o=0;o<F.length&&!F[o].includes("DetermineComponentFrameRoot");)o++;for(;u<it.length&&!it[u].includes("DetermineComponentFrameRoot");)u++;if(o===F.length||u===it.length)for(o=F.length-1,u=it.length-1;1<=o&&0<=u&&F[o]!==it[u];)u--;for(;1<=o&&0<=u;o--,u--)if(F[o]!==it[u]){if(o!==1||u!==1)do if(o--,u--,0>u||F[o]!==it[u]){var pt=`
`+F[o].replace(" at new "," at ");return e.displayName&&pt.includes("<anonymous>")&&(pt=pt.replace("<anonymous>",e.displayName)),pt}while(1<=o&&0<=u);break}}}finally{Je=!1,Error.prepareStackTrace=a}return(a=e?e.displayName||e.name:"")?G(a):""}function de(e,n){switch(e.tag){case 26:case 27:case 5:return G(e.type);case 16:return G("Lazy");case 13:return e.child!==n&&n!==null?G("Suspense Fallback"):G("Suspense");case 19:return G("SuspenseList");case 0:case 15:return le(e.type,!1);case 11:return le(e.type.render,!1);case 1:return le(e.type,!0);case 31:return G("Activity");default:return""}}function kt(e){try{var n="",a=null;do n+=de(e,a),a=e,e=e.return;while(e);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Ae=Object.prototype.hasOwnProperty,Rt=r.unstable_scheduleCallback,U=r.unstable_cancelCallback,T=r.unstable_shouldYield,$=r.unstable_requestPaint,dt=r.unstable_now,St=r.unstable_getCurrentPriorityLevel,mt=r.unstable_ImmediatePriority,Bt=r.unstable_UserBlockingPriority,Ct=r.unstable_NormalPriority,It=r.unstable_LowPriority,pe=r.unstable_IdlePriority,At=r.log,Ht=r.unstable_setDisableYieldValue,Kt=null,jt=null;function Pt(e){if(typeof At=="function"&&Ht(e),jt&&typeof jt.setStrictMode=="function")try{jt.setStrictMode(Kt,e)}catch{}}var Jt=Math.clz32?Math.clz32:Z,re=Math.log,Ie=Math.LN2;function Z(e){return e>>>=0,e===0?32:31-(re(e)/Ie|0)|0}var wt=256,ht=262144,Mt=4194304;function Dt(e){var n=e&42;if(n!==0)return n;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Lt(e,n,a){var o=e.pendingLanes;if(o===0)return 0;var u=0,f=e.suspendedLanes,S=e.pingedLanes;e=e.warmLanes;var A=o&134217727;return A!==0?(o=A&~f,o!==0?u=Dt(o):(S&=A,S!==0?u=Dt(S):a||(a=A&~e,a!==0&&(u=Dt(a))))):(A=o&~f,A!==0?u=Dt(A):S!==0?u=Dt(S):a||(a=o&~e,a!==0&&(u=Dt(a)))),u===0?0:n!==0&&n!==u&&(n&f)===0&&(f=u&-u,a=n&-n,f>=a||f===32&&(a&4194048)!==0)?n:u}function $t(e,n){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&n)===0}function Ye(e,n){switch(e){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function hn(){var e=Mt;return Mt<<=1,(Mt&62914560)===0&&(Mt=4194304),e}function Te(e){for(var n=[],a=0;31>a;a++)n.push(e);return n}function Mn(e,n){e.pendingLanes|=n,n!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function xi(e,n,a,o,u,f){var S=e.pendingLanes;e.pendingLanes=a,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=a,e.entangledLanes&=a,e.errorRecoveryDisabledLanes&=a,e.shellSuspendCounter=0;var A=e.entanglements,F=e.expirationTimes,it=e.hiddenUpdates;for(a=S&~a;0<a;){var pt=31-Jt(a),yt=1<<pt;A[pt]=0,F[pt]=-1;var rt=it[pt];if(rt!==null)for(it[pt]=null,pt=0;pt<rt.length;pt++){var ct=rt[pt];ct!==null&&(ct.lane&=-536870913)}a&=~yt}o!==0&&Wr(e,o,0),f!==0&&u===0&&e.tag!==0&&(e.suspendedLanes|=f&~(S&~n))}function Wr(e,n,a){e.pendingLanes|=n,e.suspendedLanes&=~n;var o=31-Jt(n);e.entangledLanes|=n,e.entanglements[o]=e.entanglements[o]|1073741824|a&261930}function qr(e,n){var a=e.entangledLanes|=n;for(e=e.entanglements;a;){var o=31-Jt(a),u=1<<o;u&n|e[o]&n&&(e[o]|=n),a&=~u}}function Li(e,n){var a=n&-n;return a=(a&42)!==0?1:$a(a),(a&(e.suspendedLanes|n))!==0?0:a}function $a(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Os(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Yr(){var e=W.p;return e!==0?e:(e=window.event,e===void 0?32:C0(e.type))}function ts(e,n){var a=W.p;try{return W.p=e,n()}finally{W.p=a}}var yi=Math.random().toString(36).slice(2),$e="__reactFiber$"+yi,bn="__reactProps$"+yi,Gi="__reactContainer$"+yi,Zr="__reactEvents$"+yi,au="__reactListeners$"+yi,su="__reactHandles$"+yi,el="__reactResources$"+yi,es="__reactMarker$"+yi;function Kr(e){delete e[$e],delete e[bn],delete e[Zr],delete e[au],delete e[su]}function C(e){var n=e[$e];if(n)return n;for(var a=e.parentNode;a;){if(n=a[Gi]||a[$e]){if(a=n.alternate,n.child!==null||a!==null&&a.child!==null)for(e=h0(e);e!==null;){if(a=e[$e])return a;e=h0(e)}return n}e=a,a=e.parentNode}return null}function K(e){if(e=e[$e]||e[Gi]){var n=e.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return e}return null}function ot(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e.stateNode;throw Error(s(33))}function lt(e){var n=e[el];return n||(n=e[el]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function q(e){e[es]=!0}var Tt=new Set,Ut={};function Ot(e,n){zt(e,n),zt(e+"Capture",n)}function zt(e,n){for(Ut[e]=n,e=0;e<n.length;e++)Tt.add(n[e])}var te=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ee={},Wt={};function ye(e){return Ae.call(Wt,e)?!0:Ae.call(ee,e)?!1:te.test(e)?Wt[e]=!0:(ee[e]=!0,!1)}function Se(e,n,a){if(ye(n))if(a===null)e.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":e.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(n);return}}e.setAttribute(n,""+a)}}function Xe(e,n,a){if(a===null)e.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttribute(n,""+a)}}function Re(e,n,a,o){if(o===null)e.removeAttribute(a);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(a);return}e.setAttributeNS(n,a,""+o)}}function ie(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Zt(e){var n=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function dn(e,n,a){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,n);if(!e.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var u=o.get,f=o.set;return Object.defineProperty(e,n,{configurable:!0,get:function(){return u.call(this)},set:function(S){a=""+S,f.call(this,S)}}),Object.defineProperty(e,n,{enumerable:o.enumerable}),{getValue:function(){return a},setValue:function(S){a=""+S},stopTracking:function(){e._valueTracker=null,delete e[n]}}}}function Ee(e){if(!e._valueTracker){var n=Zt(e)?"checked":"value";e._valueTracker=dn(e,n,""+e[n])}}function Vn(e){if(!e)return!1;var n=e._valueTracker;if(!n)return!0;var a=n.getValue(),o="";return e&&(o=Zt(e)?e.checked?"true":"false":e.value),e=o,e!==a?(n.setValue(e),!0):!1}function Si(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var On=/[\n"\\]/g;function xn(e){return e.replace(On,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function Be(e,n,a,o,u,f,S,A){e.name="",S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"?e.type=S:e.removeAttribute("type"),n!=null?S==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+ie(n)):e.value!==""+ie(n)&&(e.value=""+ie(n)):S!=="submit"&&S!=="reset"||e.removeAttribute("value"),n!=null?Dn(e,S,ie(n)):a!=null?Dn(e,S,ie(a)):o!=null&&e.removeAttribute("value"),u==null&&f!=null&&(e.defaultChecked=!!f),u!=null&&(e.checked=u&&typeof u!="function"&&typeof u!="symbol"),A!=null&&typeof A!="function"&&typeof A!="symbol"&&typeof A!="boolean"?e.name=""+ie(A):e.removeAttribute("name")}function Pn(e,n,a,o,u,f,S,A){if(f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"&&(e.type=f),n!=null||a!=null){if(!(f!=="submit"&&f!=="reset"||n!=null)){Ee(e);return}a=a!=null?""+ie(a):"",n=n!=null?""+ie(n):a,A||n===e.value||(e.value=n),e.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=A?e.checked:!!o,e.defaultChecked=!!o,S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"&&(e.name=S),Ee(e)}function Dn(e,n,a){n==="number"&&Si(e.ownerDocument)===e||e.defaultValue===""+a||(e.defaultValue=""+a)}function tn(e,n,a,o){if(e=e.options,n){n={};for(var u=0;u<a.length;u++)n["$"+a[u]]=!0;for(a=0;a<e.length;a++)u=n.hasOwnProperty("$"+e[a].value),e[a].selected!==u&&(e[a].selected=u),u&&o&&(e[a].defaultSelected=!0)}else{for(a=""+ie(a),n=null,u=0;u<e.length;u++){if(e[u].value===a){e[u].selected=!0,o&&(e[u].defaultSelected=!0);return}n!==null||e[u].disabled||(n=e[u])}n!==null&&(n.selected=!0)}}function En(e,n,a){if(n!=null&&(n=""+ie(n),n!==e.value&&(e.value=n),a==null)){e.defaultValue!==n&&(e.defaultValue=n);return}e.defaultValue=a!=null?""+ie(a):""}function Ps(e,n,a,o){if(n==null){if(o!=null){if(a!=null)throw Error(s(92));if(ft(o)){if(1<o.length)throw Error(s(93));o=o[0]}a=o}a==null&&(a=""),n=a}a=ie(n),e.defaultValue=a,o=e.textContent,o===a&&o!==""&&o!==null&&(e.value=o),Ee(e)}function kn(e,n){if(n){var a=e.firstChild;if(a&&a===e.lastChild&&a.nodeType===3){a.nodeValue=n;return}}e.textContent=n}var Xv=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ep(e,n,a){var o=n.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?o?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="":o?e.setProperty(n,a):typeof a!="number"||a===0||Xv.has(n)?n==="float"?e.cssFloat=a:e[n]=(""+a).trim():e[n]=a+"px"}function np(e,n,a){if(n!=null&&typeof n!="object")throw Error(s(62));if(e=e.style,a!=null){for(var o in a)!a.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&a[u]!==o&&ep(e,u,o)}else for(var f in n)n.hasOwnProperty(f)&&ep(e,f,n[f])}function ru(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Wv=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),qv=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function nl(e){return qv.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Vi(){}var ou=null;function lu(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var zs=null,Is=null;function ip(e){var n=K(e);if(n&&(e=n.stateNode)){var a=e[bn]||null;t:switch(e=n.stateNode,n.type){case"input":if(Be(e,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),n=a.name,a.type==="radio"&&n!=null){for(a=e;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+xn(""+n)+'"][type="radio"]'),n=0;n<a.length;n++){var o=a[n];if(o!==e&&o.form===e.form){var u=o[bn]||null;if(!u)throw Error(s(90));Be(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<a.length;n++)o=a[n],o.form===e.form&&Vn(o)}break t;case"textarea":En(e,a.value,a.defaultValue);break t;case"select":n=a.value,n!=null&&tn(e,!!a.multiple,n,!1)}}}var cu=!1;function ap(e,n,a){if(cu)return e(n,a);cu=!0;try{var o=e(n);return o}finally{if(cu=!1,(zs!==null||Is!==null)&&(kl(),zs&&(n=zs,e=Is,Is=zs=null,ip(n),e)))for(n=0;n<e.length;n++)ip(e[n])}}function Qr(e,n){var a=e.stateNode;if(a===null)return null;var o=a[bn]||null;if(o===null)return null;a=o[n];t:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break t;default:e=!1}if(e)return null;if(a&&typeof a!="function")throw Error(s(231,n,typeof a));return a}var ki=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),uu=!1;if(ki)try{var Jr={};Object.defineProperty(Jr,"passive",{get:function(){uu=!0}}),window.addEventListener("test",Jr,Jr),window.removeEventListener("test",Jr,Jr)}catch{uu=!1}var ma=null,fu=null,il=null;function sp(){if(il)return il;var e,n=fu,a=n.length,o,u="value"in ma?ma.value:ma.textContent,f=u.length;for(e=0;e<a&&n[e]===u[e];e++);var S=a-e;for(o=1;o<=S&&n[a-o]===u[f-o];o++);return il=u.slice(e,1<o?1-o:void 0)}function al(e){var n=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&n===13&&(e=13)):e=n,e===10&&(e=13),32<=e||e===13?e:0}function sl(){return!0}function rp(){return!1}function jn(e){function n(a,o,u,f,S){this._reactName=a,this._targetInst=u,this.type=o,this.nativeEvent=f,this.target=S,this.currentTarget=null;for(var A in e)e.hasOwnProperty(A)&&(a=e[A],this[A]=a?a(f):f[A]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?sl:rp,this.isPropagationStopped=rp,this}return _(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=sl)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=sl)},persist:function(){},isPersistent:sl}),n}var ns={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},rl=jn(ns),$r=_({},ns,{view:0,detail:0}),Yv=jn($r),hu,du,to,ol=_({},$r,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:mu,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==to&&(to&&e.type==="mousemove"?(hu=e.screenX-to.screenX,du=e.screenY-to.screenY):du=hu=0,to=e),hu)},movementY:function(e){return"movementY"in e?e.movementY:du}}),op=jn(ol),Zv=_({},ol,{dataTransfer:0}),Kv=jn(Zv),Qv=_({},$r,{relatedTarget:0}),pu=jn(Qv),Jv=_({},ns,{animationName:0,elapsedTime:0,pseudoElement:0}),$v=jn(Jv),tx=_({},ns,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),ex=jn(tx),nx=_({},ns,{data:0}),lp=jn(nx),ix={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ax={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},sx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function rx(e){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(e):(e=sx[e])?!!n[e]:!1}function mu(){return rx}var ox=_({},$r,{key:function(e){if(e.key){var n=ix[e.key]||e.key;if(n!=="Unidentified")return n}return e.type==="keypress"?(e=al(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?ax[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:mu,charCode:function(e){return e.type==="keypress"?al(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?al(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),lx=jn(ox),cx=_({},ol,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),cp=jn(cx),ux=_({},$r,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:mu}),fx=jn(ux),hx=_({},ns,{propertyName:0,elapsedTime:0,pseudoElement:0}),dx=jn(hx),px=_({},ol,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),mx=jn(px),gx=_({},ns,{newState:0,oldState:0}),_x=jn(gx),vx=[9,13,27,32],gu=ki&&"CompositionEvent"in window,eo=null;ki&&"documentMode"in document&&(eo=document.documentMode);var xx=ki&&"TextEvent"in window&&!eo,up=ki&&(!gu||eo&&8<eo&&11>=eo),fp=" ",hp=!1;function dp(e,n){switch(e){case"keyup":return vx.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function pp(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Bs=!1;function yx(e,n){switch(e){case"compositionend":return pp(n);case"keypress":return n.which!==32?null:(hp=!0,fp);case"textInput":return e=n.data,e===fp&&hp?null:e;default:return null}}function Sx(e,n){if(Bs)return e==="compositionend"||!gu&&dp(e,n)?(e=sp(),il=fu=ma=null,Bs=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return up&&n.locale!=="ko"?null:n.data;default:return null}}var Mx={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function mp(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n==="input"?!!Mx[e.type]:n==="textarea"}function gp(e,n,a,o){zs?Is?Is.push(o):Is=[o]:zs=o,n=Kl(n,"onChange"),0<n.length&&(a=new rl("onChange","change",null,a,o),e.push({event:a,listeners:n}))}var no=null,io=null;function bx(e){Jg(e,0)}function ll(e){var n=ot(e);if(Vn(n))return e}function _p(e,n){if(e==="change")return n}var vp=!1;if(ki){var _u;if(ki){var vu="oninput"in document;if(!vu){var xp=document.createElement("div");xp.setAttribute("oninput","return;"),vu=typeof xp.oninput=="function"}_u=vu}else _u=!1;vp=_u&&(!document.documentMode||9<document.documentMode)}function yp(){no&&(no.detachEvent("onpropertychange",Sp),io=no=null)}function Sp(e){if(e.propertyName==="value"&&ll(io)){var n=[];gp(n,io,e,lu(e)),ap(bx,n)}}function Ex(e,n,a){e==="focusin"?(yp(),no=n,io=a,no.attachEvent("onpropertychange",Sp)):e==="focusout"&&yp()}function Tx(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return ll(io)}function Ax(e,n){if(e==="click")return ll(n)}function Rx(e,n){if(e==="input"||e==="change")return ll(n)}function Cx(e,n){return e===n&&(e!==0||1/e===1/n)||e!==e&&n!==n}var $n=typeof Object.is=="function"?Object.is:Cx;function ao(e,n){if($n(e,n))return!0;if(typeof e!="object"||e===null||typeof n!="object"||n===null)return!1;var a=Object.keys(e),o=Object.keys(n);if(a.length!==o.length)return!1;for(o=0;o<a.length;o++){var u=a[o];if(!Ae.call(n,u)||!$n(e[u],n[u]))return!1}return!0}function Mp(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function bp(e,n){var a=Mp(e);e=0;for(var o;a;){if(a.nodeType===3){if(o=e+a.textContent.length,e<=n&&o>=n)return{node:a,offset:n-e};e=o}t:{for(;a;){if(a.nextSibling){a=a.nextSibling;break t}a=a.parentNode}a=void 0}a=Mp(a)}}function Ep(e,n){return e&&n?e===n?!0:e&&e.nodeType===3?!1:n&&n.nodeType===3?Ep(e,n.parentNode):"contains"in e?e.contains(n):e.compareDocumentPosition?!!(e.compareDocumentPosition(n)&16):!1:!1}function Tp(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var n=Si(e.document);n instanceof e.HTMLIFrameElement;){try{var a=typeof n.contentWindow.location.href=="string"}catch{a=!1}if(a)e=n.contentWindow;else break;n=Si(e.document)}return n}function xu(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n&&(n==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||n==="textarea"||e.contentEditable==="true")}var wx=ki&&"documentMode"in document&&11>=document.documentMode,Fs=null,yu=null,so=null,Su=!1;function Ap(e,n,a){var o=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;Su||Fs==null||Fs!==Si(o)||(o=Fs,"selectionStart"in o&&xu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),so&&ao(so,o)||(so=o,o=Kl(yu,"onSelect"),0<o.length&&(n=new rl("onSelect","select",null,n,a),e.push({event:n,listeners:o}),n.target=Fs)))}function is(e,n){var a={};return a[e.toLowerCase()]=n.toLowerCase(),a["Webkit"+e]="webkit"+n,a["Moz"+e]="moz"+n,a}var Hs={animationend:is("Animation","AnimationEnd"),animationiteration:is("Animation","AnimationIteration"),animationstart:is("Animation","AnimationStart"),transitionrun:is("Transition","TransitionRun"),transitionstart:is("Transition","TransitionStart"),transitioncancel:is("Transition","TransitionCancel"),transitionend:is("Transition","TransitionEnd")},Mu={},Rp={};ki&&(Rp=document.createElement("div").style,"AnimationEvent"in window||(delete Hs.animationend.animation,delete Hs.animationiteration.animation,delete Hs.animationstart.animation),"TransitionEvent"in window||delete Hs.transitionend.transition);function as(e){if(Mu[e])return Mu[e];if(!Hs[e])return e;var n=Hs[e],a;for(a in n)if(n.hasOwnProperty(a)&&a in Rp)return Mu[e]=n[a];return e}var Cp=as("animationend"),wp=as("animationiteration"),Dp=as("animationstart"),Dx=as("transitionrun"),Lx=as("transitionstart"),Ux=as("transitioncancel"),Lp=as("transitionend"),Up=new Map,bu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");bu.push("scrollEnd");function Mi(e,n){Up.set(e,n),Ot(n,[e])}var cl=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},ci=[],Gs=0,Eu=0;function ul(){for(var e=Gs,n=Eu=Gs=0;n<e;){var a=ci[n];ci[n++]=null;var o=ci[n];ci[n++]=null;var u=ci[n];ci[n++]=null;var f=ci[n];if(ci[n++]=null,o!==null&&u!==null){var S=o.pending;S===null?u.next=u:(u.next=S.next,S.next=u),o.pending=u}f!==0&&Np(a,u,f)}}function fl(e,n,a,o){ci[Gs++]=e,ci[Gs++]=n,ci[Gs++]=a,ci[Gs++]=o,Eu|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function Tu(e,n,a,o){return fl(e,n,a,o),hl(e)}function ss(e,n){return fl(e,null,null,n),hl(e)}function Np(e,n,a){e.lanes|=a;var o=e.alternate;o!==null&&(o.lanes|=a);for(var u=!1,f=e.return;f!==null;)f.childLanes|=a,o=f.alternate,o!==null&&(o.childLanes|=a),f.tag===22&&(e=f.stateNode,e===null||e._visibility&1||(u=!0)),e=f,f=f.return;return e.tag===3?(f=e.stateNode,u&&n!==null&&(u=31-Jt(a),e=f.hiddenUpdates,o=e[u],o===null?e[u]=[n]:o.push(n),n.lane=a|536870912),f):null}function hl(e){if(50<Co)throw Co=0,Pf=null,Error(s(185));for(var n=e.return;n!==null;)e=n,n=e.return;return e.tag===3?e.stateNode:null}var Vs={};function Nx(e,n,a,o){this.tag=e,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ti(e,n,a,o){return new Nx(e,n,a,o)}function Au(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ji(e,n){var a=e.alternate;return a===null?(a=ti(e.tag,n,e.key,e.mode),a.elementType=e.elementType,a.type=e.type,a.stateNode=e.stateNode,a.alternate=e,e.alternate=a):(a.pendingProps=n,a.type=e.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=e.flags&65011712,a.childLanes=e.childLanes,a.lanes=e.lanes,a.child=e.child,a.memoizedProps=e.memoizedProps,a.memoizedState=e.memoizedState,a.updateQueue=e.updateQueue,n=e.dependencies,a.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},a.sibling=e.sibling,a.index=e.index,a.ref=e.ref,a.refCleanup=e.refCleanup,a}function Op(e,n){e.flags&=65011714;var a=e.alternate;return a===null?(e.childLanes=0,e.lanes=n,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=a.childLanes,e.lanes=a.lanes,e.child=a.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=a.memoizedProps,e.memoizedState=a.memoizedState,e.updateQueue=a.updateQueue,e.type=a.type,n=a.dependencies,e.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),e}function dl(e,n,a,o,u,f){var S=0;if(o=e,typeof e=="function")Au(e)&&(S=1);else if(typeof e=="string")S=By(e,a,Y.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case L:return e=ti(31,a,n,u),e.elementType=L,e.lanes=f,e;case E:return rs(a.children,u,f,n);case M:S=8,u|=24;break;case x:return e=ti(12,a,n,u|2),e.elementType=x,e.lanes=f,e;case k:return e=ti(13,a,n,u),e.elementType=k,e.lanes=f,e;case H:return e=ti(19,a,n,u),e.elementType=H,e.lanes=f,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case N:S=10;break t;case P:S=9;break t;case w:S=11;break t;case I:S=14;break t;case j:S=16,o=null;break t}S=29,a=Error(s(130,e===null?"null":typeof e,"")),o=null}return n=ti(S,a,n,u),n.elementType=e,n.type=o,n.lanes=f,n}function rs(e,n,a,o){return e=ti(7,e,o,n),e.lanes=a,e}function Ru(e,n,a){return e=ti(6,e,null,n),e.lanes=a,e}function Pp(e){var n=ti(18,null,null,0);return n.stateNode=e,n}function Cu(e,n,a){return n=ti(4,e.children!==null?e.children:[],e.key,n),n.lanes=a,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}var zp=new WeakMap;function ui(e,n){if(typeof e=="object"&&e!==null){var a=zp.get(e);return a!==void 0?a:(n={value:e,source:n,stack:kt(n)},zp.set(e,n),n)}return{value:e,source:n,stack:kt(n)}}var ks=[],js=0,pl=null,ro=0,fi=[],hi=0,ga=null,Ui=1,Ni="";function Xi(e,n){ks[js++]=ro,ks[js++]=pl,pl=e,ro=n}function Ip(e,n,a){fi[hi++]=Ui,fi[hi++]=Ni,fi[hi++]=ga,ga=e;var o=Ui;e=Ni;var u=32-Jt(o)-1;o&=~(1<<u),a+=1;var f=32-Jt(n)+u;if(30<f){var S=u-u%5;f=(o&(1<<S)-1).toString(32),o>>=S,u-=S,Ui=1<<32-Jt(n)+u|a<<u|o,Ni=f+e}else Ui=1<<f|a<<u|o,Ni=e}function wu(e){e.return!==null&&(Xi(e,1),Ip(e,1,0))}function Du(e){for(;e===pl;)pl=ks[--js],ks[js]=null,ro=ks[--js],ks[js]=null;for(;e===ga;)ga=fi[--hi],fi[hi]=null,Ni=fi[--hi],fi[hi]=null,Ui=fi[--hi],fi[hi]=null}function Bp(e,n){fi[hi++]=Ui,fi[hi++]=Ni,fi[hi++]=ga,Ui=n.id,Ni=n.overflow,ga=e}var Tn=null,We=null,Me=!1,_a=null,di=!1,Lu=Error(s(519));function va(e){var n=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw oo(ui(n,e)),Lu}function Fp(e){var n=e.stateNode,a=e.type,o=e.memoizedProps;switch(n[$e]=e,n[bn]=o,a){case"dialog":ge("cancel",n),ge("close",n);break;case"iframe":case"object":case"embed":ge("load",n);break;case"video":case"audio":for(a=0;a<Do.length;a++)ge(Do[a],n);break;case"source":ge("error",n);break;case"img":case"image":case"link":ge("error",n),ge("load",n);break;case"details":ge("toggle",n);break;case"input":ge("invalid",n),Pn(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":ge("invalid",n);break;case"textarea":ge("invalid",n),Ps(n,o.value,o.defaultValue,o.children)}a=o.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||n.textContent===""+a||o.suppressHydrationWarning===!0||n0(n.textContent,a)?(o.popover!=null&&(ge("beforetoggle",n),ge("toggle",n)),o.onScroll!=null&&ge("scroll",n),o.onScrollEnd!=null&&ge("scrollend",n),o.onClick!=null&&(n.onclick=Vi),n=!0):n=!1,n||va(e,!0)}function Hp(e){for(Tn=e.return;Tn;)switch(Tn.tag){case 5:case 31:case 13:di=!1;return;case 27:case 3:di=!0;return;default:Tn=Tn.return}}function Xs(e){if(e!==Tn)return!1;if(!Me)return Hp(e),Me=!0,!1;var n=e.tag,a;if((a=n!==3&&n!==27)&&((a=n===5)&&(a=e.type,a=!(a!=="form"&&a!=="button")||Kf(e.type,e.memoizedProps)),a=!a),a&&We&&va(e),Hp(e),n===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(317));We=f0(e)}else if(n===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(317));We=f0(e)}else n===27?(n=We,Ua(e.type)?(e=eh,eh=null,We=e):We=n):We=Tn?mi(e.stateNode.nextSibling):null;return!0}function os(){We=Tn=null,Me=!1}function Uu(){var e=_a;return e!==null&&(Yn===null?Yn=e:Yn.push.apply(Yn,e),_a=null),e}function oo(e){_a===null?_a=[e]:_a.push(e)}var Nu=O(null),ls=null,Wi=null;function xa(e,n,a){vt(Nu,n._currentValue),n._currentValue=a}function qi(e){e._currentValue=Nu.current,at(Nu)}function Ou(e,n,a){for(;e!==null;){var o=e.alternate;if((e.childLanes&n)!==n?(e.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),e===a)break;e=e.return}}function Pu(e,n,a,o){var u=e.child;for(u!==null&&(u.return=e);u!==null;){var f=u.dependencies;if(f!==null){var S=u.child;f=f.firstContext;t:for(;f!==null;){var A=f;f=u;for(var F=0;F<n.length;F++)if(A.context===n[F]){f.lanes|=a,A=f.alternate,A!==null&&(A.lanes|=a),Ou(f.return,a,e),o||(S=null);break t}f=A.next}}else if(u.tag===18){if(S=u.return,S===null)throw Error(s(341));S.lanes|=a,f=S.alternate,f!==null&&(f.lanes|=a),Ou(S,a,e),S=null}else S=u.child;if(S!==null)S.return=u;else for(S=u;S!==null;){if(S===e){S=null;break}if(u=S.sibling,u!==null){u.return=S.return,S=u;break}S=S.return}u=S}}function Ws(e,n,a,o){e=null;for(var u=n,f=!1;u!==null;){if(!f){if((u.flags&524288)!==0)f=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var S=u.alternate;if(S===null)throw Error(s(387));if(S=S.memoizedProps,S!==null){var A=u.type;$n(u.pendingProps.value,S.value)||(e!==null?e.push(A):e=[A])}}else if(u===bt.current){if(S=u.alternate,S===null)throw Error(s(387));S.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(e!==null?e.push(Po):e=[Po])}u=u.return}e!==null&&Pu(n,e,a,o),n.flags|=262144}function ml(e){for(e=e.firstContext;e!==null;){if(!$n(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function cs(e){ls=e,Wi=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function An(e){return Gp(ls,e)}function gl(e,n){return ls===null&&cs(e),Gp(e,n)}function Gp(e,n){var a=n._currentValue;if(n={context:n,memoizedValue:a,next:null},Wi===null){if(e===null)throw Error(s(308));Wi=n,e.dependencies={lanes:0,firstContext:n},e.flags|=524288}else Wi=Wi.next=n;return a}var Ox=typeof AbortController<"u"?AbortController:function(){var e=[],n=this.signal={aborted:!1,addEventListener:function(a,o){e.push(o)}};this.abort=function(){n.aborted=!0,e.forEach(function(a){return a()})}},Px=r.unstable_scheduleCallback,zx=r.unstable_NormalPriority,on={$$typeof:N,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function zu(){return{controller:new Ox,data:new Map,refCount:0}}function lo(e){e.refCount--,e.refCount===0&&Px(zx,function(){e.controller.abort()})}var co=null,Iu=0,qs=0,Ys=null;function Ix(e,n){if(co===null){var a=co=[];Iu=0,qs=Gf(),Ys={status:"pending",value:void 0,then:function(o){a.push(o)}}}return Iu++,n.then(Vp,Vp),n}function Vp(){if(--Iu===0&&co!==null){Ys!==null&&(Ys.status="fulfilled");var e=co;co=null,qs=0,Ys=null;for(var n=0;n<e.length;n++)(0,e[n])()}}function Bx(e,n){var a=[],o={status:"pending",value:null,reason:null,then:function(u){a.push(u)}};return e.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<a.length;u++)(0,a[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<a.length;u++)(0,a[u])(void 0)}),o}var kp=z.S;z.S=function(e,n){Ag=dt(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&Ix(e,n),kp!==null&&kp(e,n)};var us=O(null);function Bu(){var e=us.current;return e!==null?e:je.pooledCache}function _l(e,n){n===null?vt(us,us.current):vt(us,n.pool)}function jp(){var e=Bu();return e===null?null:{parent:on._currentValue,pool:e}}var Zs=Error(s(460)),Fu=Error(s(474)),vl=Error(s(542)),xl={then:function(){}};function Xp(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Wp(e,n,a){switch(a=e[a],a===void 0?e.push(n):a!==n&&(n.then(Vi,Vi),n=a),n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,Yp(e),e;default:if(typeof n.status=="string")n.then(Vi,Vi);else{if(e=je,e!==null&&100<e.shellSuspendCounter)throw Error(s(482));e=n,e.status="pending",e.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,Yp(e),e}throw hs=n,Zs}}function fs(e){try{var n=e._init;return n(e._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(hs=a,Zs):a}}var hs=null;function qp(){if(hs===null)throw Error(s(459));var e=hs;return hs=null,e}function Yp(e){if(e===Zs||e===vl)throw Error(s(483))}var Ks=null,uo=0;function yl(e){var n=uo;return uo+=1,Ks===null&&(Ks=[]),Wp(Ks,e,n)}function fo(e,n){n=n.props.ref,e.ref=n!==void 0?n:null}function Sl(e,n){throw n.$$typeof===y?Error(s(525)):(e=Object.prototype.toString.call(n),Error(s(31,e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e)))}function Zp(e){function n(Q,V){if(e){var nt=Q.deletions;nt===null?(Q.deletions=[V],Q.flags|=16):nt.push(V)}}function a(Q,V){if(!e)return null;for(;V!==null;)n(Q,V),V=V.sibling;return null}function o(Q){for(var V=new Map;Q!==null;)Q.key!==null?V.set(Q.key,Q):V.set(Q.index,Q),Q=Q.sibling;return V}function u(Q,V){return Q=ji(Q,V),Q.index=0,Q.sibling=null,Q}function f(Q,V,nt){return Q.index=nt,e?(nt=Q.alternate,nt!==null?(nt=nt.index,nt<V?(Q.flags|=67108866,V):nt):(Q.flags|=67108866,V)):(Q.flags|=1048576,V)}function S(Q){return e&&Q.alternate===null&&(Q.flags|=67108866),Q}function A(Q,V,nt,gt){return V===null||V.tag!==6?(V=Ru(nt,Q.mode,gt),V.return=Q,V):(V=u(V,nt),V.return=Q,V)}function F(Q,V,nt,gt){var qt=nt.type;return qt===E?pt(Q,V,nt.props.children,gt,nt.key):V!==null&&(V.elementType===qt||typeof qt=="object"&&qt!==null&&qt.$$typeof===j&&fs(qt)===V.type)?(V=u(V,nt.props),fo(V,nt),V.return=Q,V):(V=dl(nt.type,nt.key,nt.props,null,Q.mode,gt),fo(V,nt),V.return=Q,V)}function it(Q,V,nt,gt){return V===null||V.tag!==4||V.stateNode.containerInfo!==nt.containerInfo||V.stateNode.implementation!==nt.implementation?(V=Cu(nt,Q.mode,gt),V.return=Q,V):(V=u(V,nt.children||[]),V.return=Q,V)}function pt(Q,V,nt,gt,qt){return V===null||V.tag!==7?(V=rs(nt,Q.mode,gt,qt),V.return=Q,V):(V=u(V,nt),V.return=Q,V)}function yt(Q,V,nt){if(typeof V=="string"&&V!==""||typeof V=="number"||typeof V=="bigint")return V=Ru(""+V,Q.mode,nt),V.return=Q,V;if(typeof V=="object"&&V!==null){switch(V.$$typeof){case v:return nt=dl(V.type,V.key,V.props,null,Q.mode,nt),fo(nt,V),nt.return=Q,nt;case b:return V=Cu(V,Q.mode,nt),V.return=Q,V;case j:return V=fs(V),yt(Q,V,nt)}if(ft(V)||tt(V))return V=rs(V,Q.mode,nt,null),V.return=Q,V;if(typeof V.then=="function")return yt(Q,yl(V),nt);if(V.$$typeof===N)return yt(Q,gl(Q,V),nt);Sl(Q,V)}return null}function rt(Q,V,nt,gt){var qt=V!==null?V.key:null;if(typeof nt=="string"&&nt!==""||typeof nt=="number"||typeof nt=="bigint")return qt!==null?null:A(Q,V,""+nt,gt);if(typeof nt=="object"&&nt!==null){switch(nt.$$typeof){case v:return nt.key===qt?F(Q,V,nt,gt):null;case b:return nt.key===qt?it(Q,V,nt,gt):null;case j:return nt=fs(nt),rt(Q,V,nt,gt)}if(ft(nt)||tt(nt))return qt!==null?null:pt(Q,V,nt,gt,null);if(typeof nt.then=="function")return rt(Q,V,yl(nt),gt);if(nt.$$typeof===N)return rt(Q,V,gl(Q,nt),gt);Sl(Q,nt)}return null}function ct(Q,V,nt,gt,qt){if(typeof gt=="string"&&gt!==""||typeof gt=="number"||typeof gt=="bigint")return Q=Q.get(nt)||null,A(V,Q,""+gt,qt);if(typeof gt=="object"&&gt!==null){switch(gt.$$typeof){case v:return Q=Q.get(gt.key===null?nt:gt.key)||null,F(V,Q,gt,qt);case b:return Q=Q.get(gt.key===null?nt:gt.key)||null,it(V,Q,gt,qt);case j:return gt=fs(gt),ct(Q,V,nt,gt,qt)}if(ft(gt)||tt(gt))return Q=Q.get(nt)||null,pt(V,Q,gt,qt,null);if(typeof gt.then=="function")return ct(Q,V,nt,yl(gt),qt);if(gt.$$typeof===N)return ct(Q,V,nt,gl(V,gt),qt);Sl(V,gt)}return null}function Gt(Q,V,nt,gt){for(var qt=null,Ce=null,Vt=V,ce=V=0,xe=null;Vt!==null&&ce<nt.length;ce++){Vt.index>ce?(xe=Vt,Vt=null):xe=Vt.sibling;var we=rt(Q,Vt,nt[ce],gt);if(we===null){Vt===null&&(Vt=xe);break}e&&Vt&&we.alternate===null&&n(Q,Vt),V=f(we,V,ce),Ce===null?qt=we:Ce.sibling=we,Ce=we,Vt=xe}if(ce===nt.length)return a(Q,Vt),Me&&Xi(Q,ce),qt;if(Vt===null){for(;ce<nt.length;ce++)Vt=yt(Q,nt[ce],gt),Vt!==null&&(V=f(Vt,V,ce),Ce===null?qt=Vt:Ce.sibling=Vt,Ce=Vt);return Me&&Xi(Q,ce),qt}for(Vt=o(Vt);ce<nt.length;ce++)xe=ct(Vt,Q,ce,nt[ce],gt),xe!==null&&(e&&xe.alternate!==null&&Vt.delete(xe.key===null?ce:xe.key),V=f(xe,V,ce),Ce===null?qt=xe:Ce.sibling=xe,Ce=xe);return e&&Vt.forEach(function(Ia){return n(Q,Ia)}),Me&&Xi(Q,ce),qt}function Qt(Q,V,nt,gt){if(nt==null)throw Error(s(151));for(var qt=null,Ce=null,Vt=V,ce=V=0,xe=null,we=nt.next();Vt!==null&&!we.done;ce++,we=nt.next()){Vt.index>ce?(xe=Vt,Vt=null):xe=Vt.sibling;var Ia=rt(Q,Vt,we.value,gt);if(Ia===null){Vt===null&&(Vt=xe);break}e&&Vt&&Ia.alternate===null&&n(Q,Vt),V=f(Ia,V,ce),Ce===null?qt=Ia:Ce.sibling=Ia,Ce=Ia,Vt=xe}if(we.done)return a(Q,Vt),Me&&Xi(Q,ce),qt;if(Vt===null){for(;!we.done;ce++,we=nt.next())we=yt(Q,we.value,gt),we!==null&&(V=f(we,V,ce),Ce===null?qt=we:Ce.sibling=we,Ce=we);return Me&&Xi(Q,ce),qt}for(Vt=o(Vt);!we.done;ce++,we=nt.next())we=ct(Vt,Q,ce,we.value,gt),we!==null&&(e&&we.alternate!==null&&Vt.delete(we.key===null?ce:we.key),V=f(we,V,ce),Ce===null?qt=we:Ce.sibling=we,Ce=we);return e&&Vt.forEach(function(Zy){return n(Q,Zy)}),Me&&Xi(Q,ce),qt}function Ge(Q,V,nt,gt){if(typeof nt=="object"&&nt!==null&&nt.type===E&&nt.key===null&&(nt=nt.props.children),typeof nt=="object"&&nt!==null){switch(nt.$$typeof){case v:t:{for(var qt=nt.key;V!==null;){if(V.key===qt){if(qt=nt.type,qt===E){if(V.tag===7){a(Q,V.sibling),gt=u(V,nt.props.children),gt.return=Q,Q=gt;break t}}else if(V.elementType===qt||typeof qt=="object"&&qt!==null&&qt.$$typeof===j&&fs(qt)===V.type){a(Q,V.sibling),gt=u(V,nt.props),fo(gt,nt),gt.return=Q,Q=gt;break t}a(Q,V);break}else n(Q,V);V=V.sibling}nt.type===E?(gt=rs(nt.props.children,Q.mode,gt,nt.key),gt.return=Q,Q=gt):(gt=dl(nt.type,nt.key,nt.props,null,Q.mode,gt),fo(gt,nt),gt.return=Q,Q=gt)}return S(Q);case b:t:{for(qt=nt.key;V!==null;){if(V.key===qt)if(V.tag===4&&V.stateNode.containerInfo===nt.containerInfo&&V.stateNode.implementation===nt.implementation){a(Q,V.sibling),gt=u(V,nt.children||[]),gt.return=Q,Q=gt;break t}else{a(Q,V);break}else n(Q,V);V=V.sibling}gt=Cu(nt,Q.mode,gt),gt.return=Q,Q=gt}return S(Q);case j:return nt=fs(nt),Ge(Q,V,nt,gt)}if(ft(nt))return Gt(Q,V,nt,gt);if(tt(nt)){if(qt=tt(nt),typeof qt!="function")throw Error(s(150));return nt=qt.call(nt),Qt(Q,V,nt,gt)}if(typeof nt.then=="function")return Ge(Q,V,yl(nt),gt);if(nt.$$typeof===N)return Ge(Q,V,gl(Q,nt),gt);Sl(Q,nt)}return typeof nt=="string"&&nt!==""||typeof nt=="number"||typeof nt=="bigint"?(nt=""+nt,V!==null&&V.tag===6?(a(Q,V.sibling),gt=u(V,nt),gt.return=Q,Q=gt):(a(Q,V),gt=Ru(nt,Q.mode,gt),gt.return=Q,Q=gt),S(Q)):a(Q,V)}return function(Q,V,nt,gt){try{uo=0;var qt=Ge(Q,V,nt,gt);return Ks=null,qt}catch(Vt){if(Vt===Zs||Vt===vl)throw Vt;var Ce=ti(29,Vt,null,Q.mode);return Ce.lanes=gt,Ce.return=Q,Ce}finally{}}}var ds=Zp(!0),Kp=Zp(!1),ya=!1;function Hu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Gu(e,n){e=e.updateQueue,n.updateQueue===e&&(n.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Sa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ma(e,n,a){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(Le&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=hl(e),Np(e,null,a),n}return fl(e,o,n,a),hl(e)}function ho(e,n,a){if(n=n.updateQueue,n!==null&&(n=n.shared,(a&4194048)!==0)){var o=n.lanes;o&=e.pendingLanes,a|=o,n.lanes=a,qr(e,a)}}function Vu(e,n){var a=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,a===o)){var u=null,f=null;if(a=a.firstBaseUpdate,a!==null){do{var S={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};f===null?u=f=S:f=f.next=S,a=a.next}while(a!==null);f===null?u=f=n:f=f.next=n}else u=f=n;a={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:f,shared:o.shared,callbacks:o.callbacks},e.updateQueue=a;return}e=a.lastBaseUpdate,e===null?a.firstBaseUpdate=n:e.next=n,a.lastBaseUpdate=n}var ku=!1;function po(){if(ku){var e=Ys;if(e!==null)throw e}}function mo(e,n,a,o){ku=!1;var u=e.updateQueue;ya=!1;var f=u.firstBaseUpdate,S=u.lastBaseUpdate,A=u.shared.pending;if(A!==null){u.shared.pending=null;var F=A,it=F.next;F.next=null,S===null?f=it:S.next=it,S=F;var pt=e.alternate;pt!==null&&(pt=pt.updateQueue,A=pt.lastBaseUpdate,A!==S&&(A===null?pt.firstBaseUpdate=it:A.next=it,pt.lastBaseUpdate=F))}if(f!==null){var yt=u.baseState;S=0,pt=it=F=null,A=f;do{var rt=A.lane&-536870913,ct=rt!==A.lane;if(ct?(ve&rt)===rt:(o&rt)===rt){rt!==0&&rt===qs&&(ku=!0),pt!==null&&(pt=pt.next={lane:0,tag:A.tag,payload:A.payload,callback:null,next:null});t:{var Gt=e,Qt=A;rt=n;var Ge=a;switch(Qt.tag){case 1:if(Gt=Qt.payload,typeof Gt=="function"){yt=Gt.call(Ge,yt,rt);break t}yt=Gt;break t;case 3:Gt.flags=Gt.flags&-65537|128;case 0:if(Gt=Qt.payload,rt=typeof Gt=="function"?Gt.call(Ge,yt,rt):Gt,rt==null)break t;yt=_({},yt,rt);break t;case 2:ya=!0}}rt=A.callback,rt!==null&&(e.flags|=64,ct&&(e.flags|=8192),ct=u.callbacks,ct===null?u.callbacks=[rt]:ct.push(rt))}else ct={lane:rt,tag:A.tag,payload:A.payload,callback:A.callback,next:null},pt===null?(it=pt=ct,F=yt):pt=pt.next=ct,S|=rt;if(A=A.next,A===null){if(A=u.shared.pending,A===null)break;ct=A,A=ct.next,ct.next=null,u.lastBaseUpdate=ct,u.shared.pending=null}}while(!0);pt===null&&(F=yt),u.baseState=F,u.firstBaseUpdate=it,u.lastBaseUpdate=pt,f===null&&(u.shared.lanes=0),Ra|=S,e.lanes=S,e.memoizedState=yt}}function Qp(e,n){if(typeof e!="function")throw Error(s(191,e));e.call(n)}function Jp(e,n){var a=e.callbacks;if(a!==null)for(e.callbacks=null,e=0;e<a.length;e++)Qp(a[e],n)}var Qs=O(null),Ml=O(0);function $p(e,n){e=na,vt(Ml,e),vt(Qs,n),na=e|n.baseLanes}function ju(){vt(Ml,na),vt(Qs,Qs.current)}function Xu(){na=Ml.current,at(Qs),at(Ml)}var ei=O(null),pi=null;function ba(e){var n=e.alternate;vt(sn,sn.current&1),vt(ei,e),pi===null&&(n===null||Qs.current!==null||n.memoizedState!==null)&&(pi=e)}function Wu(e){vt(sn,sn.current),vt(ei,e),pi===null&&(pi=e)}function tm(e){e.tag===22?(vt(sn,sn.current),vt(ei,e),pi===null&&(pi=e)):Ea()}function Ea(){vt(sn,sn.current),vt(ei,ei.current)}function ni(e){at(ei),pi===e&&(pi=null),at(sn)}var sn=O(0);function bl(e){for(var n=e;n!==null;){if(n.tag===13){var a=n.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||$f(a)||th(a)))return n}else if(n.tag===19&&(n.memoizedProps.revealOrder==="forwards"||n.memoizedProps.revealOrder==="backwards"||n.memoizedProps.revealOrder==="unstable_legacy-backwards"||n.memoizedProps.revealOrder==="together")){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var Yi=0,oe=null,Fe=null,ln=null,El=!1,Js=!1,ps=!1,Tl=0,go=0,$s=null,Fx=0;function en(){throw Error(s(321))}function qu(e,n){if(n===null)return!1;for(var a=0;a<n.length&&a<e.length;a++)if(!$n(e[a],n[a]))return!1;return!0}function Yu(e,n,a,o,u,f){return Yi=f,oe=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,z.H=e===null||e.memoizedState===null?Im:uf,ps=!1,f=a(o,u),ps=!1,Js&&(f=nm(n,a,o,u)),em(e),f}function em(e){z.H=xo;var n=Fe!==null&&Fe.next!==null;if(Yi=0,ln=Fe=oe=null,El=!1,go=0,$s=null,n)throw Error(s(300));e===null||cn||(e=e.dependencies,e!==null&&ml(e)&&(cn=!0))}function nm(e,n,a,o){oe=e;var u=0;do{if(Js&&($s=null),go=0,Js=!1,25<=u)throw Error(s(301));if(u+=1,ln=Fe=null,e.updateQueue!=null){var f=e.updateQueue;f.lastEffect=null,f.events=null,f.stores=null,f.memoCache!=null&&(f.memoCache.index=0)}z.H=Bm,f=n(a,o)}while(Js);return f}function Hx(){var e=z.H,n=e.useState()[0];return n=typeof n.then=="function"?_o(n):n,e=e.useState()[0],(Fe!==null?Fe.memoizedState:null)!==e&&(oe.flags|=1024),n}function Zu(){var e=Tl!==0;return Tl=0,e}function Ku(e,n,a){n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~a}function Qu(e){if(El){for(e=e.memoizedState;e!==null;){var n=e.queue;n!==null&&(n.pending=null),e=e.next}El=!1}Yi=0,ln=Fe=oe=null,Js=!1,go=Tl=0,$s=null}function zn(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ln===null?oe.memoizedState=ln=e:ln=ln.next=e,ln}function rn(){if(Fe===null){var e=oe.alternate;e=e!==null?e.memoizedState:null}else e=Fe.next;var n=ln===null?oe.memoizedState:ln.next;if(n!==null)ln=n,Fe=e;else{if(e===null)throw oe.alternate===null?Error(s(467)):Error(s(310));Fe=e,e={memoizedState:Fe.memoizedState,baseState:Fe.baseState,baseQueue:Fe.baseQueue,queue:Fe.queue,next:null},ln===null?oe.memoizedState=ln=e:ln=ln.next=e}return ln}function Al(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function _o(e){var n=go;return go+=1,$s===null&&($s=[]),e=Wp($s,e,n),n=oe,(ln===null?n.memoizedState:ln.next)===null&&(n=n.alternate,z.H=n===null||n.memoizedState===null?Im:uf),e}function Rl(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return _o(e);if(e.$$typeof===N)return An(e)}throw Error(s(438,String(e)))}function Ju(e){var n=null,a=oe.updateQueue;if(a!==null&&(n=a.memoCache),n==null){var o=oe.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),a===null&&(a=Al(),oe.updateQueue=a),a.memoCache=n,a=n.data[n.index],a===void 0)for(a=n.data[n.index]=Array(e),o=0;o<e;o++)a[o]=R;return n.index++,a}function Zi(e,n){return typeof n=="function"?n(e):n}function Cl(e){var n=rn();return $u(n,Fe,e)}function $u(e,n,a){var o=e.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=a;var u=e.baseQueue,f=o.pending;if(f!==null){if(u!==null){var S=u.next;u.next=f.next,f.next=S}n.baseQueue=u=f,o.pending=null}if(f=e.baseState,u===null)e.memoizedState=f;else{n=u.next;var A=S=null,F=null,it=n,pt=!1;do{var yt=it.lane&-536870913;if(yt!==it.lane?(ve&yt)===yt:(Yi&yt)===yt){var rt=it.revertLane;if(rt===0)F!==null&&(F=F.next={lane:0,revertLane:0,gesture:null,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null}),yt===qs&&(pt=!0);else if((Yi&rt)===rt){it=it.next,rt===qs&&(pt=!0);continue}else yt={lane:0,revertLane:it.revertLane,gesture:null,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null},F===null?(A=F=yt,S=f):F=F.next=yt,oe.lanes|=rt,Ra|=rt;yt=it.action,ps&&a(f,yt),f=it.hasEagerState?it.eagerState:a(f,yt)}else rt={lane:yt,revertLane:it.revertLane,gesture:it.gesture,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null},F===null?(A=F=rt,S=f):F=F.next=rt,oe.lanes|=yt,Ra|=yt;it=it.next}while(it!==null&&it!==n);if(F===null?S=f:F.next=A,!$n(f,e.memoizedState)&&(cn=!0,pt&&(a=Ys,a!==null)))throw a;e.memoizedState=f,e.baseState=S,e.baseQueue=F,o.lastRenderedState=f}return u===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function tf(e){var n=rn(),a=n.queue;if(a===null)throw Error(s(311));a.lastRenderedReducer=e;var o=a.dispatch,u=a.pending,f=n.memoizedState;if(u!==null){a.pending=null;var S=u=u.next;do f=e(f,S.action),S=S.next;while(S!==u);$n(f,n.memoizedState)||(cn=!0),n.memoizedState=f,n.baseQueue===null&&(n.baseState=f),a.lastRenderedState=f}return[f,o]}function im(e,n,a){var o=oe,u=rn(),f=Me;if(f){if(a===void 0)throw Error(s(407));a=a()}else a=n();var S=!$n((Fe||u).memoizedState,a);if(S&&(u.memoizedState=a,cn=!0),u=u.queue,af(rm.bind(null,o,u,e),[e]),u.getSnapshot!==n||S||ln!==null&&ln.memoizedState.tag&1){if(o.flags|=2048,tr(9,{destroy:void 0},sm.bind(null,o,u,a,n),null),je===null)throw Error(s(349));f||(Yi&127)!==0||am(o,n,a)}return a}function am(e,n,a){e.flags|=16384,e={getSnapshot:n,value:a},n=oe.updateQueue,n===null?(n=Al(),oe.updateQueue=n,n.stores=[e]):(a=n.stores,a===null?n.stores=[e]:a.push(e))}function sm(e,n,a,o){n.value=a,n.getSnapshot=o,om(n)&&lm(e)}function rm(e,n,a){return a(function(){om(n)&&lm(e)})}function om(e){var n=e.getSnapshot;e=e.value;try{var a=n();return!$n(e,a)}catch{return!0}}function lm(e){var n=ss(e,2);n!==null&&Zn(n,e,2)}function ef(e){var n=zn();if(typeof e=="function"){var a=e;if(e=a(),ps){Pt(!0);try{a()}finally{Pt(!1)}}}return n.memoizedState=n.baseState=e,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Zi,lastRenderedState:e},n}function cm(e,n,a,o){return e.baseState=a,$u(e,Fe,typeof o=="function"?o:Zi)}function Gx(e,n,a,o,u){if(Ll(e))throw Error(s(485));if(e=n.action,e!==null){var f={payload:u,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(S){f.listeners.push(S)}};z.T!==null?a(!0):f.isTransition=!1,o(f),a=n.pending,a===null?(f.next=n.pending=f,um(n,f)):(f.next=a.next,n.pending=a.next=f)}}function um(e,n){var a=n.action,o=n.payload,u=e.state;if(n.isTransition){var f=z.T,S={};z.T=S;try{var A=a(u,o),F=z.S;F!==null&&F(S,A),fm(e,n,A)}catch(it){nf(e,n,it)}finally{f!==null&&S.types!==null&&(f.types=S.types),z.T=f}}else try{f=a(u,o),fm(e,n,f)}catch(it){nf(e,n,it)}}function fm(e,n,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(o){hm(e,n,o)},function(o){return nf(e,n,o)}):hm(e,n,a)}function hm(e,n,a){n.status="fulfilled",n.value=a,dm(n),e.state=a,n=e.pending,n!==null&&(a=n.next,a===n?e.pending=null:(a=a.next,n.next=a,um(e,a)))}function nf(e,n,a){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=a,dm(n),n=n.next;while(n!==o)}e.action=null}function dm(e){e=e.listeners;for(var n=0;n<e.length;n++)(0,e[n])()}function pm(e,n){return n}function mm(e,n){if(Me){var a=je.formState;if(a!==null){t:{var o=oe;if(Me){if(We){e:{for(var u=We,f=di;u.nodeType!==8;){if(!f){u=null;break e}if(u=mi(u.nextSibling),u===null){u=null;break e}}f=u.data,u=f==="F!"||f==="F"?u:null}if(u){We=mi(u.nextSibling),o=u.data==="F!";break t}}va(o)}o=!1}o&&(n=a[0])}}return a=zn(),a.memoizedState=a.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:pm,lastRenderedState:n},a.queue=o,a=Om.bind(null,oe,o),o.dispatch=a,o=ef(!1),f=cf.bind(null,oe,!1,o.queue),o=zn(),u={state:n,dispatch:null,action:e,pending:null},o.queue=u,a=Gx.bind(null,oe,u,f,a),u.dispatch=a,o.memoizedState=e,[n,a,!1]}function gm(e){var n=rn();return _m(n,Fe,e)}function _m(e,n,a){if(n=$u(e,n,pm)[0],e=Cl(Zi)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=_o(n)}catch(S){throw S===Zs?vl:S}else o=n;n=rn();var u=n.queue,f=u.dispatch;return a!==n.memoizedState&&(oe.flags|=2048,tr(9,{destroy:void 0},Vx.bind(null,u,a),null)),[o,f,e]}function Vx(e,n){e.action=n}function vm(e){var n=rn(),a=Fe;if(a!==null)return _m(n,a,e);rn(),n=n.memoizedState,a=rn();var o=a.queue.dispatch;return a.memoizedState=e,[n,o,!1]}function tr(e,n,a,o){return e={tag:e,create:a,deps:o,inst:n,next:null},n=oe.updateQueue,n===null&&(n=Al(),oe.updateQueue=n),a=n.lastEffect,a===null?n.lastEffect=e.next=e:(o=a.next,a.next=e,e.next=o,n.lastEffect=e),e}function xm(){return rn().memoizedState}function wl(e,n,a,o){var u=zn();oe.flags|=e,u.memoizedState=tr(1|n,{destroy:void 0},a,o===void 0?null:o)}function Dl(e,n,a,o){var u=rn();o=o===void 0?null:o;var f=u.memoizedState.inst;Fe!==null&&o!==null&&qu(o,Fe.memoizedState.deps)?u.memoizedState=tr(n,f,a,o):(oe.flags|=e,u.memoizedState=tr(1|n,f,a,o))}function ym(e,n){wl(8390656,8,e,n)}function af(e,n){Dl(2048,8,e,n)}function kx(e){oe.flags|=4;var n=oe.updateQueue;if(n===null)n=Al(),oe.updateQueue=n,n.events=[e];else{var a=n.events;a===null?n.events=[e]:a.push(e)}}function Sm(e){var n=rn().memoizedState;return kx({ref:n,nextImpl:e}),function(){if((Le&2)!==0)throw Error(s(440));return n.impl.apply(void 0,arguments)}}function Mm(e,n){return Dl(4,2,e,n)}function bm(e,n){return Dl(4,4,e,n)}function Em(e,n){if(typeof n=="function"){e=e();var a=n(e);return function(){typeof a=="function"?a():n(null)}}if(n!=null)return e=e(),n.current=e,function(){n.current=null}}function Tm(e,n,a){a=a!=null?a.concat([e]):null,Dl(4,4,Em.bind(null,n,e),a)}function sf(){}function Am(e,n){var a=rn();n=n===void 0?null:n;var o=a.memoizedState;return n!==null&&qu(n,o[1])?o[0]:(a.memoizedState=[e,n],e)}function Rm(e,n){var a=rn();n=n===void 0?null:n;var o=a.memoizedState;if(n!==null&&qu(n,o[1]))return o[0];if(o=e(),ps){Pt(!0);try{e()}finally{Pt(!1)}}return a.memoizedState=[o,n],o}function rf(e,n,a){return a===void 0||(Yi&1073741824)!==0&&(ve&261930)===0?e.memoizedState=n:(e.memoizedState=a,e=Cg(),oe.lanes|=e,Ra|=e,a)}function Cm(e,n,a,o){return $n(a,n)?a:Qs.current!==null?(e=rf(e,a,o),$n(e,n)||(cn=!0),e):(Yi&42)===0||(Yi&1073741824)!==0&&(ve&261930)===0?(cn=!0,e.memoizedState=a):(e=Cg(),oe.lanes|=e,Ra|=e,n)}function wm(e,n,a,o,u){var f=W.p;W.p=f!==0&&8>f?f:8;var S=z.T,A={};z.T=A,cf(e,!1,n,a);try{var F=u(),it=z.S;if(it!==null&&it(A,F),F!==null&&typeof F=="object"&&typeof F.then=="function"){var pt=Bx(F,o);vo(e,n,pt,si(e))}else vo(e,n,o,si(e))}catch(yt){vo(e,n,{then:function(){},status:"rejected",reason:yt},si())}finally{W.p=f,S!==null&&A.types!==null&&(S.types=A.types),z.T=S}}function jx(){}function of(e,n,a,o){if(e.tag!==5)throw Error(s(476));var u=Dm(e).queue;wm(e,u,n,X,a===null?jx:function(){return Lm(e),a(o)})}function Dm(e){var n=e.memoizedState;if(n!==null)return n;n={memoizedState:X,baseState:X,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Zi,lastRenderedState:X},next:null};var a={};return n.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Zi,lastRenderedState:a},next:null},e.memoizedState=n,e=e.alternate,e!==null&&(e.memoizedState=n),n}function Lm(e){var n=Dm(e);n.next===null&&(n=e.alternate.memoizedState),vo(e,n.next.queue,{},si())}function lf(){return An(Po)}function Um(){return rn().memoizedState}function Nm(){return rn().memoizedState}function Xx(e){for(var n=e.return;n!==null;){switch(n.tag){case 24:case 3:var a=si();e=Sa(a);var o=Ma(n,e,a);o!==null&&(Zn(o,n,a),ho(o,n,a)),n={cache:zu()},e.payload=n;return}n=n.return}}function Wx(e,n,a){var o=si();a={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},Ll(e)?Pm(n,a):(a=Tu(e,n,a,o),a!==null&&(Zn(a,e,o),zm(a,n,o)))}function Om(e,n,a){var o=si();vo(e,n,a,o)}function vo(e,n,a,o){var u={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(Ll(e))Pm(n,u);else{var f=e.alternate;if(e.lanes===0&&(f===null||f.lanes===0)&&(f=n.lastRenderedReducer,f!==null))try{var S=n.lastRenderedState,A=f(S,a);if(u.hasEagerState=!0,u.eagerState=A,$n(A,S))return fl(e,n,u,0),je===null&&ul(),!1}catch{}finally{}if(a=Tu(e,n,u,o),a!==null)return Zn(a,e,o),zm(a,n,o),!0}return!1}function cf(e,n,a,o){if(o={lane:2,revertLane:Gf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Ll(e)){if(n)throw Error(s(479))}else n=Tu(e,a,o,2),n!==null&&Zn(n,e,2)}function Ll(e){var n=e.alternate;return e===oe||n!==null&&n===oe}function Pm(e,n){Js=El=!0;var a=e.pending;a===null?n.next=n:(n.next=a.next,a.next=n),e.pending=n}function zm(e,n,a){if((a&4194048)!==0){var o=n.lanes;o&=e.pendingLanes,a|=o,n.lanes=a,qr(e,a)}}var xo={readContext:An,use:Rl,useCallback:en,useContext:en,useEffect:en,useImperativeHandle:en,useLayoutEffect:en,useInsertionEffect:en,useMemo:en,useReducer:en,useRef:en,useState:en,useDebugValue:en,useDeferredValue:en,useTransition:en,useSyncExternalStore:en,useId:en,useHostTransitionStatus:en,useFormState:en,useActionState:en,useOptimistic:en,useMemoCache:en,useCacheRefresh:en};xo.useEffectEvent=en;var Im={readContext:An,use:Rl,useCallback:function(e,n){return zn().memoizedState=[e,n===void 0?null:n],e},useContext:An,useEffect:ym,useImperativeHandle:function(e,n,a){a=a!=null?a.concat([e]):null,wl(4194308,4,Em.bind(null,n,e),a)},useLayoutEffect:function(e,n){return wl(4194308,4,e,n)},useInsertionEffect:function(e,n){wl(4,2,e,n)},useMemo:function(e,n){var a=zn();n=n===void 0?null:n;var o=e();if(ps){Pt(!0);try{e()}finally{Pt(!1)}}return a.memoizedState=[o,n],o},useReducer:function(e,n,a){var o=zn();if(a!==void 0){var u=a(n);if(ps){Pt(!0);try{a(n)}finally{Pt(!1)}}}else u=n;return o.memoizedState=o.baseState=u,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:u},o.queue=e,e=e.dispatch=Wx.bind(null,oe,e),[o.memoizedState,e]},useRef:function(e){var n=zn();return e={current:e},n.memoizedState=e},useState:function(e){e=ef(e);var n=e.queue,a=Om.bind(null,oe,n);return n.dispatch=a,[e.memoizedState,a]},useDebugValue:sf,useDeferredValue:function(e,n){var a=zn();return rf(a,e,n)},useTransition:function(){var e=ef(!1);return e=wm.bind(null,oe,e.queue,!0,!1),zn().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,n,a){var o=oe,u=zn();if(Me){if(a===void 0)throw Error(s(407));a=a()}else{if(a=n(),je===null)throw Error(s(349));(ve&127)!==0||am(o,n,a)}u.memoizedState=a;var f={value:a,getSnapshot:n};return u.queue=f,ym(rm.bind(null,o,f,e),[e]),o.flags|=2048,tr(9,{destroy:void 0},sm.bind(null,o,f,a,n),null),a},useId:function(){var e=zn(),n=je.identifierPrefix;if(Me){var a=Ni,o=Ui;a=(o&~(1<<32-Jt(o)-1)).toString(32)+a,n="_"+n+"R_"+a,a=Tl++,0<a&&(n+="H"+a.toString(32)),n+="_"}else a=Fx++,n="_"+n+"r_"+a.toString(32)+"_";return e.memoizedState=n},useHostTransitionStatus:lf,useFormState:mm,useActionState:mm,useOptimistic:function(e){var n=zn();n.memoizedState=n.baseState=e;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=a,n=cf.bind(null,oe,!0,a),a.dispatch=n,[e,n]},useMemoCache:Ju,useCacheRefresh:function(){return zn().memoizedState=Xx.bind(null,oe)},useEffectEvent:function(e){var n=zn(),a={impl:e};return n.memoizedState=a,function(){if((Le&2)!==0)throw Error(s(440));return a.impl.apply(void 0,arguments)}}},uf={readContext:An,use:Rl,useCallback:Am,useContext:An,useEffect:af,useImperativeHandle:Tm,useInsertionEffect:Mm,useLayoutEffect:bm,useMemo:Rm,useReducer:Cl,useRef:xm,useState:function(){return Cl(Zi)},useDebugValue:sf,useDeferredValue:function(e,n){var a=rn();return Cm(a,Fe.memoizedState,e,n)},useTransition:function(){var e=Cl(Zi)[0],n=rn().memoizedState;return[typeof e=="boolean"?e:_o(e),n]},useSyncExternalStore:im,useId:Um,useHostTransitionStatus:lf,useFormState:gm,useActionState:gm,useOptimistic:function(e,n){var a=rn();return cm(a,Fe,e,n)},useMemoCache:Ju,useCacheRefresh:Nm};uf.useEffectEvent=Sm;var Bm={readContext:An,use:Rl,useCallback:Am,useContext:An,useEffect:af,useImperativeHandle:Tm,useInsertionEffect:Mm,useLayoutEffect:bm,useMemo:Rm,useReducer:tf,useRef:xm,useState:function(){return tf(Zi)},useDebugValue:sf,useDeferredValue:function(e,n){var a=rn();return Fe===null?rf(a,e,n):Cm(a,Fe.memoizedState,e,n)},useTransition:function(){var e=tf(Zi)[0],n=rn().memoizedState;return[typeof e=="boolean"?e:_o(e),n]},useSyncExternalStore:im,useId:Um,useHostTransitionStatus:lf,useFormState:vm,useActionState:vm,useOptimistic:function(e,n){var a=rn();return Fe!==null?cm(a,Fe,e,n):(a.baseState=e,[e,a.queue.dispatch])},useMemoCache:Ju,useCacheRefresh:Nm};Bm.useEffectEvent=Sm;function ff(e,n,a,o){n=e.memoizedState,a=a(o,n),a=a==null?n:_({},n,a),e.memoizedState=a,e.lanes===0&&(e.updateQueue.baseState=a)}var hf={enqueueSetState:function(e,n,a){e=e._reactInternals;var o=si(),u=Sa(o);u.payload=n,a!=null&&(u.callback=a),n=Ma(e,u,o),n!==null&&(Zn(n,e,o),ho(n,e,o))},enqueueReplaceState:function(e,n,a){e=e._reactInternals;var o=si(),u=Sa(o);u.tag=1,u.payload=n,a!=null&&(u.callback=a),n=Ma(e,u,o),n!==null&&(Zn(n,e,o),ho(n,e,o))},enqueueForceUpdate:function(e,n){e=e._reactInternals;var a=si(),o=Sa(a);o.tag=2,n!=null&&(o.callback=n),n=Ma(e,o,a),n!==null&&(Zn(n,e,a),ho(n,e,a))}};function Fm(e,n,a,o,u,f,S){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,f,S):n.prototype&&n.prototype.isPureReactComponent?!ao(a,o)||!ao(u,f):!0}function Hm(e,n,a,o){e=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(a,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(a,o),n.state!==e&&hf.enqueueReplaceState(n,n.state,null)}function ms(e,n){var a=n;if("ref"in n){a={};for(var o in n)o!=="ref"&&(a[o]=n[o])}if(e=e.defaultProps){a===n&&(a=_({},a));for(var u in e)a[u]===void 0&&(a[u]=e[u])}return a}function Gm(e){cl(e)}function Vm(e){console.error(e)}function km(e){cl(e)}function Ul(e,n){try{var a=e.onUncaughtError;a(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function jm(e,n,a){try{var o=e.onCaughtError;o(a.value,{componentStack:a.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function df(e,n,a){return a=Sa(a),a.tag=3,a.payload={element:null},a.callback=function(){Ul(e,n)},a}function Xm(e){return e=Sa(e),e.tag=3,e}function Wm(e,n,a,o){var u=a.type.getDerivedStateFromError;if(typeof u=="function"){var f=o.value;e.payload=function(){return u(f)},e.callback=function(){jm(n,a,o)}}var S=a.stateNode;S!==null&&typeof S.componentDidCatch=="function"&&(e.callback=function(){jm(n,a,o),typeof u!="function"&&(Ca===null?Ca=new Set([this]):Ca.add(this));var A=o.stack;this.componentDidCatch(o.value,{componentStack:A!==null?A:""})})}function qx(e,n,a,o,u){if(a.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=a.alternate,n!==null&&Ws(n,a,u,!0),a=ei.current,a!==null){switch(a.tag){case 31:case 13:return pi===null?jl():a.alternate===null&&nn===0&&(nn=3),a.flags&=-257,a.flags|=65536,a.lanes=u,o===xl?a.flags|=16384:(n=a.updateQueue,n===null?a.updateQueue=new Set([o]):n.add(o),Bf(e,o,u)),!1;case 22:return a.flags|=65536,o===xl?a.flags|=16384:(n=a.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},a.updateQueue=n):(a=n.retryQueue,a===null?n.retryQueue=new Set([o]):a.add(o)),Bf(e,o,u)),!1}throw Error(s(435,a.tag))}return Bf(e,o,u),jl(),!1}if(Me)return n=ei.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==Lu&&(e=Error(s(422),{cause:o}),oo(ui(e,a)))):(o!==Lu&&(n=Error(s(423),{cause:o}),oo(ui(n,a))),e=e.current.alternate,e.flags|=65536,u&=-u,e.lanes|=u,o=ui(o,a),u=df(e.stateNode,o,u),Vu(e,u),nn!==4&&(nn=2)),!1;var f=Error(s(520),{cause:o});if(f=ui(f,a),Ro===null?Ro=[f]:Ro.push(f),nn!==4&&(nn=2),n===null)return!0;o=ui(o,a),a=n;do{switch(a.tag){case 3:return a.flags|=65536,e=u&-u,a.lanes|=e,e=df(a.stateNode,o,e),Vu(a,e),!1;case 1:if(n=a.type,f=a.stateNode,(a.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||f!==null&&typeof f.componentDidCatch=="function"&&(Ca===null||!Ca.has(f))))return a.flags|=65536,u&=-u,a.lanes|=u,u=Xm(u),Wm(u,e,a,o),Vu(a,u),!1}a=a.return}while(a!==null);return!1}var pf=Error(s(461)),cn=!1;function Rn(e,n,a,o){n.child=e===null?Kp(n,null,a,o):ds(n,e.child,a,o)}function qm(e,n,a,o,u){a=a.render;var f=n.ref;if("ref"in o){var S={};for(var A in o)A!=="ref"&&(S[A]=o[A])}else S=o;return cs(n),o=Yu(e,n,a,S,f,u),A=Zu(),e!==null&&!cn?(Ku(e,n,u),Ki(e,n,u)):(Me&&A&&wu(n),n.flags|=1,Rn(e,n,o,u),n.child)}function Ym(e,n,a,o,u){if(e===null){var f=a.type;return typeof f=="function"&&!Au(f)&&f.defaultProps===void 0&&a.compare===null?(n.tag=15,n.type=f,Zm(e,n,f,o,u)):(e=dl(a.type,null,o,n,n.mode,u),e.ref=n.ref,e.return=n,n.child=e)}if(f=e.child,!Mf(e,u)){var S=f.memoizedProps;if(a=a.compare,a=a!==null?a:ao,a(S,o)&&e.ref===n.ref)return Ki(e,n,u)}return n.flags|=1,e=ji(f,o),e.ref=n.ref,e.return=n,n.child=e}function Zm(e,n,a,o,u){if(e!==null){var f=e.memoizedProps;if(ao(f,o)&&e.ref===n.ref)if(cn=!1,n.pendingProps=o=f,Mf(e,u))(e.flags&131072)!==0&&(cn=!0);else return n.lanes=e.lanes,Ki(e,n,u)}return mf(e,n,a,o,u)}function Km(e,n,a,o){var u=o.children,f=e!==null?e.memoizedState:null;if(e===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((n.flags&128)!==0){if(f=f!==null?f.baseLanes|a:a,e!==null){for(o=n.child=e.child,u=0;o!==null;)u=u|o.lanes|o.childLanes,o=o.sibling;o=u&~f}else o=0,n.child=null;return Qm(e,n,f,a,o)}if((a&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},e!==null&&_l(n,f!==null?f.cachePool:null),f!==null?$p(n,f):ju(),tm(n);else return o=n.lanes=536870912,Qm(e,n,f!==null?f.baseLanes|a:a,a,o)}else f!==null?(_l(n,f.cachePool),$p(n,f),Ea(),n.memoizedState=null):(e!==null&&_l(n,null),ju(),Ea());return Rn(e,n,u,a),n.child}function yo(e,n){return e!==null&&e.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function Qm(e,n,a,o,u){var f=Bu();return f=f===null?null:{parent:on._currentValue,pool:f},n.memoizedState={baseLanes:a,cachePool:f},e!==null&&_l(n,null),ju(),tm(n),e!==null&&Ws(e,n,o,!0),n.childLanes=u,null}function Nl(e,n){return n=Pl({mode:n.mode,children:n.children},e.mode),n.ref=e.ref,e.child=n,n.return=e,n}function Jm(e,n,a){return ds(n,e.child,null,a),e=Nl(n,n.pendingProps),e.flags|=2,ni(n),n.memoizedState=null,e}function Yx(e,n,a){var o=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,e===null){if(Me){if(o.mode==="hidden")return e=Nl(n,o),n.lanes=536870912,yo(null,e);if(Wu(n),(e=We)?(e=u0(e,di),e=e!==null&&e.data==="&"?e:null,e!==null&&(n.memoizedState={dehydrated:e,treeContext:ga!==null?{id:Ui,overflow:Ni}:null,retryLane:536870912,hydrationErrors:null},a=Pp(e),a.return=n,n.child=a,Tn=n,We=null)):e=null,e===null)throw va(n);return n.lanes=536870912,null}return Nl(n,o)}var f=e.memoizedState;if(f!==null){var S=f.dehydrated;if(Wu(n),u)if(n.flags&256)n.flags&=-257,n=Jm(e,n,a);else if(n.memoizedState!==null)n.child=e.child,n.flags|=128,n=null;else throw Error(s(558));else if(cn||Ws(e,n,a,!1),u=(a&e.childLanes)!==0,cn||u){if(o=je,o!==null&&(S=Li(o,a),S!==0&&S!==f.retryLane))throw f.retryLane=S,ss(e,S),Zn(o,e,S),pf;jl(),n=Jm(e,n,a)}else e=f.treeContext,We=mi(S.nextSibling),Tn=n,Me=!0,_a=null,di=!1,e!==null&&Bp(n,e),n=Nl(n,o),n.flags|=4096;return n}return e=ji(e.child,{mode:o.mode,children:o.children}),e.ref=n.ref,n.child=e,e.return=n,e}function Ol(e,n){var a=n.ref;if(a===null)e!==null&&e.ref!==null&&(n.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(s(284));(e===null||e.ref!==a)&&(n.flags|=4194816)}}function mf(e,n,a,o,u){return cs(n),a=Yu(e,n,a,o,void 0,u),o=Zu(),e!==null&&!cn?(Ku(e,n,u),Ki(e,n,u)):(Me&&o&&wu(n),n.flags|=1,Rn(e,n,a,u),n.child)}function $m(e,n,a,o,u,f){return cs(n),n.updateQueue=null,a=nm(n,o,a,u),em(e),o=Zu(),e!==null&&!cn?(Ku(e,n,f),Ki(e,n,f)):(Me&&o&&wu(n),n.flags|=1,Rn(e,n,a,f),n.child)}function tg(e,n,a,o,u){if(cs(n),n.stateNode===null){var f=Vs,S=a.contextType;typeof S=="object"&&S!==null&&(f=An(S)),f=new a(o,f),n.memoizedState=f.state!==null&&f.state!==void 0?f.state:null,f.updater=hf,n.stateNode=f,f._reactInternals=n,f=n.stateNode,f.props=o,f.state=n.memoizedState,f.refs={},Hu(n),S=a.contextType,f.context=typeof S=="object"&&S!==null?An(S):Vs,f.state=n.memoizedState,S=a.getDerivedStateFromProps,typeof S=="function"&&(ff(n,a,S,o),f.state=n.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof f.getSnapshotBeforeUpdate=="function"||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(S=f.state,typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount(),S!==f.state&&hf.enqueueReplaceState(f,f.state,null),mo(n,o,f,u),po(),f.state=n.memoizedState),typeof f.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(e===null){f=n.stateNode;var A=n.memoizedProps,F=ms(a,A);f.props=F;var it=f.context,pt=a.contextType;S=Vs,typeof pt=="object"&&pt!==null&&(S=An(pt));var yt=a.getDerivedStateFromProps;pt=typeof yt=="function"||typeof f.getSnapshotBeforeUpdate=="function",A=n.pendingProps!==A,pt||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(A||it!==S)&&Hm(n,f,o,S),ya=!1;var rt=n.memoizedState;f.state=rt,mo(n,o,f,u),po(),it=n.memoizedState,A||rt!==it||ya?(typeof yt=="function"&&(ff(n,a,yt,o),it=n.memoizedState),(F=ya||Fm(n,a,F,o,rt,it,S))?(pt||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount()),typeof f.componentDidMount=="function"&&(n.flags|=4194308)):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=it),f.props=o,f.state=it,f.context=S,o=F):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{f=n.stateNode,Gu(e,n),S=n.memoizedProps,pt=ms(a,S),f.props=pt,yt=n.pendingProps,rt=f.context,it=a.contextType,F=Vs,typeof it=="object"&&it!==null&&(F=An(it)),A=a.getDerivedStateFromProps,(it=typeof A=="function"||typeof f.getSnapshotBeforeUpdate=="function")||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(S!==yt||rt!==F)&&Hm(n,f,o,F),ya=!1,rt=n.memoizedState,f.state=rt,mo(n,o,f,u),po();var ct=n.memoizedState;S!==yt||rt!==ct||ya||e!==null&&e.dependencies!==null&&ml(e.dependencies)?(typeof A=="function"&&(ff(n,a,A,o),ct=n.memoizedState),(pt=ya||Fm(n,a,pt,o,rt,ct,F)||e!==null&&e.dependencies!==null&&ml(e.dependencies))?(it||typeof f.UNSAFE_componentWillUpdate!="function"&&typeof f.componentWillUpdate!="function"||(typeof f.componentWillUpdate=="function"&&f.componentWillUpdate(o,ct,F),typeof f.UNSAFE_componentWillUpdate=="function"&&f.UNSAFE_componentWillUpdate(o,ct,F)),typeof f.componentDidUpdate=="function"&&(n.flags|=4),typeof f.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof f.componentDidUpdate!="function"||S===e.memoizedProps&&rt===e.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||S===e.memoizedProps&&rt===e.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=ct),f.props=o,f.state=ct,f.context=F,o=pt):(typeof f.componentDidUpdate!="function"||S===e.memoizedProps&&rt===e.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||S===e.memoizedProps&&rt===e.memoizedState||(n.flags|=1024),o=!1)}return f=o,Ol(e,n),o=(n.flags&128)!==0,f||o?(f=n.stateNode,a=o&&typeof a.getDerivedStateFromError!="function"?null:f.render(),n.flags|=1,e!==null&&o?(n.child=ds(n,e.child,null,u),n.child=ds(n,null,a,u)):Rn(e,n,a,u),n.memoizedState=f.state,e=n.child):e=Ki(e,n,u),e}function eg(e,n,a,o){return os(),n.flags|=256,Rn(e,n,a,o),n.child}var gf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function _f(e){return{baseLanes:e,cachePool:jp()}}function vf(e,n,a){return e=e!==null?e.childLanes&~a:0,n&&(e|=ai),e}function ng(e,n,a){var o=n.pendingProps,u=!1,f=(n.flags&128)!==0,S;if((S=f)||(S=e!==null&&e.memoizedState===null?!1:(sn.current&2)!==0),S&&(u=!0,n.flags&=-129),S=(n.flags&32)!==0,n.flags&=-33,e===null){if(Me){if(u?ba(n):Ea(),(e=We)?(e=u0(e,di),e=e!==null&&e.data!=="&"?e:null,e!==null&&(n.memoizedState={dehydrated:e,treeContext:ga!==null?{id:Ui,overflow:Ni}:null,retryLane:536870912,hydrationErrors:null},a=Pp(e),a.return=n,n.child=a,Tn=n,We=null)):e=null,e===null)throw va(n);return th(e)?n.lanes=32:n.lanes=536870912,null}var A=o.children;return o=o.fallback,u?(Ea(),u=n.mode,A=Pl({mode:"hidden",children:A},u),o=rs(o,u,a,null),A.return=n,o.return=n,A.sibling=o,n.child=A,o=n.child,o.memoizedState=_f(a),o.childLanes=vf(e,S,a),n.memoizedState=gf,yo(null,o)):(ba(n),xf(n,A))}var F=e.memoizedState;if(F!==null&&(A=F.dehydrated,A!==null)){if(f)n.flags&256?(ba(n),n.flags&=-257,n=yf(e,n,a)):n.memoizedState!==null?(Ea(),n.child=e.child,n.flags|=128,n=null):(Ea(),A=o.fallback,u=n.mode,o=Pl({mode:"visible",children:o.children},u),A=rs(A,u,a,null),A.flags|=2,o.return=n,A.return=n,o.sibling=A,n.child=o,ds(n,e.child,null,a),o=n.child,o.memoizedState=_f(a),o.childLanes=vf(e,S,a),n.memoizedState=gf,n=yo(null,o));else if(ba(n),th(A)){if(S=A.nextSibling&&A.nextSibling.dataset,S)var it=S.dgst;S=it,o=Error(s(419)),o.stack="",o.digest=S,oo({value:o,source:null,stack:null}),n=yf(e,n,a)}else if(cn||Ws(e,n,a,!1),S=(a&e.childLanes)!==0,cn||S){if(S=je,S!==null&&(o=Li(S,a),o!==0&&o!==F.retryLane))throw F.retryLane=o,ss(e,o),Zn(S,e,o),pf;$f(A)||jl(),n=yf(e,n,a)}else $f(A)?(n.flags|=192,n.child=e.child,n=null):(e=F.treeContext,We=mi(A.nextSibling),Tn=n,Me=!0,_a=null,di=!1,e!==null&&Bp(n,e),n=xf(n,o.children),n.flags|=4096);return n}return u?(Ea(),A=o.fallback,u=n.mode,F=e.child,it=F.sibling,o=ji(F,{mode:"hidden",children:o.children}),o.subtreeFlags=F.subtreeFlags&65011712,it!==null?A=ji(it,A):(A=rs(A,u,a,null),A.flags|=2),A.return=n,o.return=n,o.sibling=A,n.child=o,yo(null,o),o=n.child,A=e.child.memoizedState,A===null?A=_f(a):(u=A.cachePool,u!==null?(F=on._currentValue,u=u.parent!==F?{parent:F,pool:F}:u):u=jp(),A={baseLanes:A.baseLanes|a,cachePool:u}),o.memoizedState=A,o.childLanes=vf(e,S,a),n.memoizedState=gf,yo(e.child,o)):(ba(n),a=e.child,e=a.sibling,a=ji(a,{mode:"visible",children:o.children}),a.return=n,a.sibling=null,e!==null&&(S=n.deletions,S===null?(n.deletions=[e],n.flags|=16):S.push(e)),n.child=a,n.memoizedState=null,a)}function xf(e,n){return n=Pl({mode:"visible",children:n},e.mode),n.return=e,e.child=n}function Pl(e,n){return e=ti(22,e,null,n),e.lanes=0,e}function yf(e,n,a){return ds(n,e.child,null,a),e=xf(n,n.pendingProps.children),e.flags|=2,n.memoizedState=null,e}function ig(e,n,a){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n),Ou(e.return,n,a)}function Sf(e,n,a,o,u,f){var S=e.memoizedState;S===null?e.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:a,tailMode:u,treeForkCount:f}:(S.isBackwards=n,S.rendering=null,S.renderingStartTime=0,S.last=o,S.tail=a,S.tailMode=u,S.treeForkCount=f)}function ag(e,n,a){var o=n.pendingProps,u=o.revealOrder,f=o.tail;o=o.children;var S=sn.current,A=(S&2)!==0;if(A?(S=S&1|2,n.flags|=128):S&=1,vt(sn,S),Rn(e,n,o,a),o=Me?ro:0,!A&&e!==null&&(e.flags&128)!==0)t:for(e=n.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&ig(e,a,n);else if(e.tag===19)ig(e,a,n);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break t;for(;e.sibling===null;){if(e.return===null||e.return===n)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(u){case"forwards":for(a=n.child,u=null;a!==null;)e=a.alternate,e!==null&&bl(e)===null&&(u=a),a=a.sibling;a=u,a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null),Sf(n,!1,u,a,f,o);break;case"backwards":case"unstable_legacy-backwards":for(a=null,u=n.child,n.child=null;u!==null;){if(e=u.alternate,e!==null&&bl(e)===null){n.child=u;break}e=u.sibling,u.sibling=a,a=u,u=e}Sf(n,!0,a,null,f,o);break;case"together":Sf(n,!1,null,null,void 0,o);break;default:n.memoizedState=null}return n.child}function Ki(e,n,a){if(e!==null&&(n.dependencies=e.dependencies),Ra|=n.lanes,(a&n.childLanes)===0)if(e!==null){if(Ws(e,n,a,!1),(a&n.childLanes)===0)return null}else return null;if(e!==null&&n.child!==e.child)throw Error(s(153));if(n.child!==null){for(e=n.child,a=ji(e,e.pendingProps),n.child=a,a.return=n;e.sibling!==null;)e=e.sibling,a=a.sibling=ji(e,e.pendingProps),a.return=n;a.sibling=null}return n.child}function Mf(e,n){return(e.lanes&n)!==0?!0:(e=e.dependencies,!!(e!==null&&ml(e)))}function Zx(e,n,a){switch(n.tag){case 3:Ft(n,n.stateNode.containerInfo),xa(n,on,e.memoizedState.cache),os();break;case 27:case 5:Yt(n);break;case 4:Ft(n,n.stateNode.containerInfo);break;case 10:xa(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,Wu(n),null;break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?(ba(n),n.flags|=128,null):(a&n.child.childLanes)!==0?ng(e,n,a):(ba(n),e=Ki(e,n,a),e!==null?e.sibling:null);ba(n);break;case 19:var u=(e.flags&128)!==0;if(o=(a&n.childLanes)!==0,o||(Ws(e,n,a,!1),o=(a&n.childLanes)!==0),u){if(o)return ag(e,n,a);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),vt(sn,sn.current),o)break;return null;case 22:return n.lanes=0,Km(e,n,a,n.pendingProps);case 24:xa(n,on,e.memoizedState.cache)}return Ki(e,n,a)}function sg(e,n,a){if(e!==null)if(e.memoizedProps!==n.pendingProps)cn=!0;else{if(!Mf(e,a)&&(n.flags&128)===0)return cn=!1,Zx(e,n,a);cn=(e.flags&131072)!==0}else cn=!1,Me&&(n.flags&1048576)!==0&&Ip(n,ro,n.index);switch(n.lanes=0,n.tag){case 16:t:{var o=n.pendingProps;if(e=fs(n.elementType),n.type=e,typeof e=="function")Au(e)?(o=ms(e,o),n.tag=1,n=tg(null,n,e,o,a)):(n.tag=0,n=mf(null,n,e,o,a));else{if(e!=null){var u=e.$$typeof;if(u===w){n.tag=11,n=qm(null,n,e,o,a);break t}else if(u===I){n.tag=14,n=Ym(null,n,e,o,a);break t}}throw n=ut(e)||e,Error(s(306,n,""))}}return n;case 0:return mf(e,n,n.type,n.pendingProps,a);case 1:return o=n.type,u=ms(o,n.pendingProps),tg(e,n,o,u,a);case 3:t:{if(Ft(n,n.stateNode.containerInfo),e===null)throw Error(s(387));o=n.pendingProps;var f=n.memoizedState;u=f.element,Gu(e,n),mo(n,o,null,a);var S=n.memoizedState;if(o=S.cache,xa(n,on,o),o!==f.cache&&Pu(n,[on],a,!0),po(),o=S.element,f.isDehydrated)if(f={element:o,isDehydrated:!1,cache:S.cache},n.updateQueue.baseState=f,n.memoizedState=f,n.flags&256){n=eg(e,n,o,a);break t}else if(o!==u){u=ui(Error(s(424)),n),oo(u),n=eg(e,n,o,a);break t}else{switch(e=n.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(We=mi(e.firstChild),Tn=n,Me=!0,_a=null,di=!0,a=Kp(n,null,o,a),n.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling}else{if(os(),o===u){n=Ki(e,n,a);break t}Rn(e,n,o,a)}n=n.child}return n;case 26:return Ol(e,n),e===null?(a=g0(n.type,null,n.pendingProps,null))?n.memoizedState=a:Me||(a=n.type,e=n.pendingProps,o=Ql(xt.current).createElement(a),o[$e]=n,o[bn]=e,Cn(o,a,e),q(o),n.stateNode=o):n.memoizedState=g0(n.type,e.memoizedProps,n.pendingProps,e.memoizedState),null;case 27:return Yt(n),e===null&&Me&&(o=n.stateNode=d0(n.type,n.pendingProps,xt.current),Tn=n,di=!0,u=We,Ua(n.type)?(eh=u,We=mi(o.firstChild)):We=u),Rn(e,n,n.pendingProps.children,a),Ol(e,n),e===null&&(n.flags|=4194304),n.child;case 5:return e===null&&Me&&((u=o=We)&&(o=Ty(o,n.type,n.pendingProps,di),o!==null?(n.stateNode=o,Tn=n,We=mi(o.firstChild),di=!1,u=!0):u=!1),u||va(n)),Yt(n),u=n.type,f=n.pendingProps,S=e!==null?e.memoizedProps:null,o=f.children,Kf(u,f)?o=null:S!==null&&Kf(u,S)&&(n.flags|=32),n.memoizedState!==null&&(u=Yu(e,n,Hx,null,null,a),Po._currentValue=u),Ol(e,n),Rn(e,n,o,a),n.child;case 6:return e===null&&Me&&((e=a=We)&&(a=Ay(a,n.pendingProps,di),a!==null?(n.stateNode=a,Tn=n,We=null,e=!0):e=!1),e||va(n)),null;case 13:return ng(e,n,a);case 4:return Ft(n,n.stateNode.containerInfo),o=n.pendingProps,e===null?n.child=ds(n,null,o,a):Rn(e,n,o,a),n.child;case 11:return qm(e,n,n.type,n.pendingProps,a);case 7:return Rn(e,n,n.pendingProps,a),n.child;case 8:return Rn(e,n,n.pendingProps.children,a),n.child;case 12:return Rn(e,n,n.pendingProps.children,a),n.child;case 10:return o=n.pendingProps,xa(n,n.type,o.value),Rn(e,n,o.children,a),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,cs(n),u=An(u),o=o(u),n.flags|=1,Rn(e,n,o,a),n.child;case 14:return Ym(e,n,n.type,n.pendingProps,a);case 15:return Zm(e,n,n.type,n.pendingProps,a);case 19:return ag(e,n,a);case 31:return Yx(e,n,a);case 22:return Km(e,n,a,n.pendingProps);case 24:return cs(n),o=An(on),e===null?(u=Bu(),u===null&&(u=je,f=zu(),u.pooledCache=f,f.refCount++,f!==null&&(u.pooledCacheLanes|=a),u=f),n.memoizedState={parent:o,cache:u},Hu(n),xa(n,on,u)):((e.lanes&a)!==0&&(Gu(e,n),mo(n,null,null,a),po()),u=e.memoizedState,f=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),xa(n,on,o)):(o=f.cache,xa(n,on,o),o!==u.cache&&Pu(n,[on],a,!0))),Rn(e,n,n.pendingProps.children,a),n.child;case 29:throw n.pendingProps}throw Error(s(156,n.tag))}function Qi(e){e.flags|=4}function bf(e,n,a,o,u){if((n=(e.mode&32)!==0)&&(n=!1),n){if(e.flags|=16777216,(u&335544128)===u)if(e.stateNode.complete)e.flags|=8192;else if(Ug())e.flags|=8192;else throw hs=xl,Fu}else e.flags&=-16777217}function rg(e,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!S0(n))if(Ug())e.flags|=8192;else throw hs=xl,Fu}function zl(e,n){n!==null&&(e.flags|=4),e.flags&16384&&(n=e.tag!==22?hn():536870912,e.lanes|=n,ar|=n)}function So(e,n){if(!Me)switch(e.tailMode){case"hidden":n=e.tail;for(var a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?e.tail=null:a.sibling=null;break;case"collapsed":a=e.tail;for(var o=null;a!==null;)a.alternate!==null&&(o=a),a=a.sibling;o===null?n||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null}}function qe(e){var n=e.alternate!==null&&e.alternate.child===e.child,a=0,o=0;if(n)for(var u=e.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=e,u=u.sibling;else for(u=e.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=e,u=u.sibling;return e.subtreeFlags|=o,e.childLanes=a,n}function Kx(e,n,a){var o=n.pendingProps;switch(Du(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return qe(n),null;case 1:return qe(n),null;case 3:return a=n.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),qi(on),Xt(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(e===null||e.child===null)&&(Xs(n)?Qi(n):e===null||e.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Uu())),qe(n),null;case 26:var u=n.type,f=n.memoizedState;return e===null?(Qi(n),f!==null?(qe(n),rg(n,f)):(qe(n),bf(n,u,null,o,a))):f?f!==e.memoizedState?(Qi(n),qe(n),rg(n,f)):(qe(n),n.flags&=-16777217):(e=e.memoizedProps,e!==o&&Qi(n),qe(n),bf(n,u,e,o,a)),null;case 27:if(ze(n),a=xt.current,u=n.type,e!==null&&n.stateNode!=null)e.memoizedProps!==o&&Qi(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return qe(n),null}e=Y.current,Xs(n)?Fp(n):(e=d0(u,o,a),n.stateNode=e,Qi(n))}return qe(n),null;case 5:if(ze(n),u=n.type,e!==null&&n.stateNode!=null)e.memoizedProps!==o&&Qi(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return qe(n),null}if(f=Y.current,Xs(n))Fp(n);else{var S=Ql(xt.current);switch(f){case 1:f=S.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:f=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":f=S.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":f=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":f=S.createElement("div"),f.innerHTML="<script><\/script>",f=f.removeChild(f.firstChild);break;case"select":f=typeof o.is=="string"?S.createElement("select",{is:o.is}):S.createElement("select"),o.multiple?f.multiple=!0:o.size&&(f.size=o.size);break;default:f=typeof o.is=="string"?S.createElement(u,{is:o.is}):S.createElement(u)}}f[$e]=n,f[bn]=o;t:for(S=n.child;S!==null;){if(S.tag===5||S.tag===6)f.appendChild(S.stateNode);else if(S.tag!==4&&S.tag!==27&&S.child!==null){S.child.return=S,S=S.child;continue}if(S===n)break t;for(;S.sibling===null;){if(S.return===null||S.return===n)break t;S=S.return}S.sibling.return=S.return,S=S.sibling}n.stateNode=f;t:switch(Cn(f,u,o),u){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break t;case"img":o=!0;break t;default:o=!1}o&&Qi(n)}}return qe(n),bf(n,n.type,e===null?null:e.memoizedProps,n.pendingProps,a),null;case 6:if(e&&n.stateNode!=null)e.memoizedProps!==o&&Qi(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(s(166));if(e=xt.current,Xs(n)){if(e=n.stateNode,a=n.memoizedProps,o=null,u=Tn,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}e[$e]=n,e=!!(e.nodeValue===a||o!==null&&o.suppressHydrationWarning===!0||n0(e.nodeValue,a)),e||va(n,!0)}else e=Ql(e).createTextNode(o),e[$e]=n,n.stateNode=e}return qe(n),null;case 31:if(a=n.memoizedState,e===null||e.memoizedState!==null){if(o=Xs(n),a!==null){if(e===null){if(!o)throw Error(s(318));if(e=n.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(557));e[$e]=n}else os(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;qe(n),e=!1}else a=Uu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),e=!0;if(!e)return n.flags&256?(ni(n),n):(ni(n),null);if((n.flags&128)!==0)throw Error(s(558))}return qe(n),null;case 13:if(o=n.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(u=Xs(n),o!==null&&o.dehydrated!==null){if(e===null){if(!u)throw Error(s(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(s(317));u[$e]=n}else os(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;qe(n),u=!1}else u=Uu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(ni(n),n):(ni(n),null)}return ni(n),(n.flags&128)!==0?(n.lanes=a,n):(a=o!==null,e=e!==null&&e.memoizedState!==null,a&&(o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool),f=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(f=o.memoizedState.cachePool.pool),f!==u&&(o.flags|=2048)),a!==e&&a&&(n.child.flags|=8192),zl(n,n.updateQueue),qe(n),null);case 4:return Xt(),e===null&&Xf(n.stateNode.containerInfo),qe(n),null;case 10:return qi(n.type),qe(n),null;case 19:if(at(sn),o=n.memoizedState,o===null)return qe(n),null;if(u=(n.flags&128)!==0,f=o.rendering,f===null)if(u)So(o,!1);else{if(nn!==0||e!==null&&(e.flags&128)!==0)for(e=n.child;e!==null;){if(f=bl(e),f!==null){for(n.flags|=128,So(o,!1),e=f.updateQueue,n.updateQueue=e,zl(n,e),n.subtreeFlags=0,e=a,a=n.child;a!==null;)Op(a,e),a=a.sibling;return vt(sn,sn.current&1|2),Me&&Xi(n,o.treeForkCount),n.child}e=e.sibling}o.tail!==null&&dt()>Gl&&(n.flags|=128,u=!0,So(o,!1),n.lanes=4194304)}else{if(!u)if(e=bl(f),e!==null){if(n.flags|=128,u=!0,e=e.updateQueue,n.updateQueue=e,zl(n,e),So(o,!0),o.tail===null&&o.tailMode==="hidden"&&!f.alternate&&!Me)return qe(n),null}else 2*dt()-o.renderingStartTime>Gl&&a!==536870912&&(n.flags|=128,u=!0,So(o,!1),n.lanes=4194304);o.isBackwards?(f.sibling=n.child,n.child=f):(e=o.last,e!==null?e.sibling=f:n.child=f,o.last=f)}return o.tail!==null?(e=o.tail,o.rendering=e,o.tail=e.sibling,o.renderingStartTime=dt(),e.sibling=null,a=sn.current,vt(sn,u?a&1|2:a&1),Me&&Xi(n,o.treeForkCount),e):(qe(n),null);case 22:case 23:return ni(n),Xu(),o=n.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(a&536870912)!==0&&(n.flags&128)===0&&(qe(n),n.subtreeFlags&6&&(n.flags|=8192)):qe(n),a=n.updateQueue,a!==null&&zl(n,a.retryQueue),a=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048),e!==null&&at(us),null;case 24:return a=null,e!==null&&(a=e.memoizedState.cache),n.memoizedState.cache!==a&&(n.flags|=2048),qi(on),qe(n),null;case 25:return null;case 30:return null}throw Error(s(156,n.tag))}function Qx(e,n){switch(Du(n),n.tag){case 1:return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 3:return qi(on),Xt(),e=n.flags,(e&65536)!==0&&(e&128)===0?(n.flags=e&-65537|128,n):null;case 26:case 27:case 5:return ze(n),null;case 31:if(n.memoizedState!==null){if(ni(n),n.alternate===null)throw Error(s(340));os()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 13:if(ni(n),e=n.memoizedState,e!==null&&e.dehydrated!==null){if(n.alternate===null)throw Error(s(340));os()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 19:return at(sn),null;case 4:return Xt(),null;case 10:return qi(n.type),null;case 22:case 23:return ni(n),Xu(),e!==null&&at(us),e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 24:return qi(on),null;case 25:return null;default:return null}}function og(e,n){switch(Du(n),n.tag){case 3:qi(on),Xt();break;case 26:case 27:case 5:ze(n);break;case 4:Xt();break;case 31:n.memoizedState!==null&&ni(n);break;case 13:ni(n);break;case 19:at(sn);break;case 10:qi(n.type);break;case 22:case 23:ni(n),Xu(),e!==null&&at(us);break;case 24:qi(on)}}function Mo(e,n){try{var a=n.updateQueue,o=a!==null?a.lastEffect:null;if(o!==null){var u=o.next;a=u;do{if((a.tag&e)===e){o=void 0;var f=a.create,S=a.inst;o=f(),S.destroy=o}a=a.next}while(a!==u)}}catch(A){Pe(n,n.return,A)}}function Ta(e,n,a){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var f=u.next;o=f;do{if((o.tag&e)===e){var S=o.inst,A=S.destroy;if(A!==void 0){S.destroy=void 0,u=n;var F=a,it=A;try{it()}catch(pt){Pe(u,F,pt)}}}o=o.next}while(o!==f)}}catch(pt){Pe(n,n.return,pt)}}function lg(e){var n=e.updateQueue;if(n!==null){var a=e.stateNode;try{Jp(n,a)}catch(o){Pe(e,e.return,o)}}}function cg(e,n,a){a.props=ms(e.type,e.memoizedProps),a.state=e.memoizedState;try{a.componentWillUnmount()}catch(o){Pe(e,n,o)}}function bo(e,n){try{var a=e.ref;if(a!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:o=e.stateNode;break;default:o=e.stateNode}typeof a=="function"?e.refCleanup=a(o):a.current=o}}catch(u){Pe(e,n,u)}}function Oi(e,n){var a=e.ref,o=e.refCleanup;if(a!==null)if(typeof o=="function")try{o()}catch(u){Pe(e,n,u)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(u){Pe(e,n,u)}else a.current=null}function ug(e){var n=e.type,a=e.memoizedProps,o=e.stateNode;try{t:switch(n){case"button":case"input":case"select":case"textarea":a.autoFocus&&o.focus();break t;case"img":a.src?o.src=a.src:a.srcSet&&(o.srcset=a.srcSet)}}catch(u){Pe(e,e.return,u)}}function Ef(e,n,a){try{var o=e.stateNode;xy(o,e.type,a,n),o[bn]=n}catch(u){Pe(e,e.return,u)}}function fg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Ua(e.type)||e.tag===4}function Tf(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||fg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Ua(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Af(e,n,a){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(e,n):(n=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,n.appendChild(e),a=a._reactRootContainer,a!=null||n.onclick!==null||(n.onclick=Vi));else if(o!==4&&(o===27&&Ua(e.type)&&(a=e.stateNode,n=null),e=e.child,e!==null))for(Af(e,n,a),e=e.sibling;e!==null;)Af(e,n,a),e=e.sibling}function Il(e,n,a){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?a.insertBefore(e,n):a.appendChild(e);else if(o!==4&&(o===27&&Ua(e.type)&&(a=e.stateNode),e=e.child,e!==null))for(Il(e,n,a),e=e.sibling;e!==null;)Il(e,n,a),e=e.sibling}function hg(e){var n=e.stateNode,a=e.memoizedProps;try{for(var o=e.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);Cn(n,o,a),n[$e]=e,n[bn]=a}catch(f){Pe(e,e.return,f)}}var Ji=!1,un=!1,Rf=!1,dg=typeof WeakSet=="function"?WeakSet:Set,yn=null;function Jx(e,n){if(e=e.containerInfo,Yf=ac,e=Tp(e),xu(e)){if("selectionStart"in e)var a={start:e.selectionStart,end:e.selectionEnd};else t:{a=(a=e.ownerDocument)&&a.defaultView||window;var o=a.getSelection&&a.getSelection();if(o&&o.rangeCount!==0){a=o.anchorNode;var u=o.anchorOffset,f=o.focusNode;o=o.focusOffset;try{a.nodeType,f.nodeType}catch{a=null;break t}var S=0,A=-1,F=-1,it=0,pt=0,yt=e,rt=null;e:for(;;){for(var ct;yt!==a||u!==0&&yt.nodeType!==3||(A=S+u),yt!==f||o!==0&&yt.nodeType!==3||(F=S+o),yt.nodeType===3&&(S+=yt.nodeValue.length),(ct=yt.firstChild)!==null;)rt=yt,yt=ct;for(;;){if(yt===e)break e;if(rt===a&&++it===u&&(A=S),rt===f&&++pt===o&&(F=S),(ct=yt.nextSibling)!==null)break;yt=rt,rt=yt.parentNode}yt=ct}a=A===-1||F===-1?null:{start:A,end:F}}else a=null}a=a||{start:0,end:0}}else a=null;for(Zf={focusedElem:e,selectionRange:a},ac=!1,yn=n;yn!==null;)if(n=yn,e=n.child,(n.subtreeFlags&1028)!==0&&e!==null)e.return=n,yn=e;else for(;yn!==null;){switch(n=yn,f=n.alternate,e=n.flags,n.tag){case 0:if((e&4)!==0&&(e=n.updateQueue,e=e!==null?e.events:null,e!==null))for(a=0;a<e.length;a++)u=e[a],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&f!==null){e=void 0,a=n,u=f.memoizedProps,f=f.memoizedState,o=a.stateNode;try{var Gt=ms(a.type,u);e=o.getSnapshotBeforeUpdate(Gt,f),o.__reactInternalSnapshotBeforeUpdate=e}catch(Qt){Pe(a,a.return,Qt)}}break;case 3:if((e&1024)!==0){if(e=n.stateNode.containerInfo,a=e.nodeType,a===9)Jf(e);else if(a===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":Jf(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(s(163))}if(e=n.sibling,e!==null){e.return=n.return,yn=e;break}yn=n.return}}function pg(e,n,a){var o=a.flags;switch(a.tag){case 0:case 11:case 15:ta(e,a),o&4&&Mo(5,a);break;case 1:if(ta(e,a),o&4)if(e=a.stateNode,n===null)try{e.componentDidMount()}catch(S){Pe(a,a.return,S)}else{var u=ms(a.type,n.memoizedProps);n=n.memoizedState;try{e.componentDidUpdate(u,n,e.__reactInternalSnapshotBeforeUpdate)}catch(S){Pe(a,a.return,S)}}o&64&&lg(a),o&512&&bo(a,a.return);break;case 3:if(ta(e,a),o&64&&(e=a.updateQueue,e!==null)){if(n=null,a.child!==null)switch(a.child.tag){case 27:case 5:n=a.child.stateNode;break;case 1:n=a.child.stateNode}try{Jp(e,n)}catch(S){Pe(a,a.return,S)}}break;case 27:n===null&&o&4&&hg(a);case 26:case 5:ta(e,a),n===null&&o&4&&ug(a),o&512&&bo(a,a.return);break;case 12:ta(e,a);break;case 31:ta(e,a),o&4&&_g(e,a);break;case 13:ta(e,a),o&4&&vg(e,a),o&64&&(e=a.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(a=oy.bind(null,a),Ry(e,a))));break;case 22:if(o=a.memoizedState!==null||Ji,!o){n=n!==null&&n.memoizedState!==null||un,u=Ji;var f=un;Ji=o,(un=n)&&!f?ea(e,a,(a.subtreeFlags&8772)!==0):ta(e,a),Ji=u,un=f}break;case 30:break;default:ta(e,a)}}function mg(e){var n=e.alternate;n!==null&&(e.alternate=null,mg(n)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(n=e.stateNode,n!==null&&Kr(n)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Ze=null,Xn=!1;function $i(e,n,a){for(a=a.child;a!==null;)gg(e,n,a),a=a.sibling}function gg(e,n,a){if(jt&&typeof jt.onCommitFiberUnmount=="function")try{jt.onCommitFiberUnmount(Kt,a)}catch{}switch(a.tag){case 26:un||Oi(a,n),$i(e,n,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:un||Oi(a,n);var o=Ze,u=Xn;Ua(a.type)&&(Ze=a.stateNode,Xn=!1),$i(e,n,a),Uo(a.stateNode),Ze=o,Xn=u;break;case 5:un||Oi(a,n);case 6:if(o=Ze,u=Xn,Ze=null,$i(e,n,a),Ze=o,Xn=u,Ze!==null)if(Xn)try{(Ze.nodeType===9?Ze.body:Ze.nodeName==="HTML"?Ze.ownerDocument.body:Ze).removeChild(a.stateNode)}catch(f){Pe(a,n,f)}else try{Ze.removeChild(a.stateNode)}catch(f){Pe(a,n,f)}break;case 18:Ze!==null&&(Xn?(e=Ze,l0(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,a.stateNode),hr(e)):l0(Ze,a.stateNode));break;case 4:o=Ze,u=Xn,Ze=a.stateNode.containerInfo,Xn=!0,$i(e,n,a),Ze=o,Xn=u;break;case 0:case 11:case 14:case 15:Ta(2,a,n),un||Ta(4,a,n),$i(e,n,a);break;case 1:un||(Oi(a,n),o=a.stateNode,typeof o.componentWillUnmount=="function"&&cg(a,n,o)),$i(e,n,a);break;case 21:$i(e,n,a);break;case 22:un=(o=un)||a.memoizedState!==null,$i(e,n,a),un=o;break;default:$i(e,n,a)}}function _g(e,n){if(n.memoizedState===null&&(e=n.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{hr(e)}catch(a){Pe(n,n.return,a)}}}function vg(e,n){if(n.memoizedState===null&&(e=n.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{hr(e)}catch(a){Pe(n,n.return,a)}}function $x(e){switch(e.tag){case 31:case 13:case 19:var n=e.stateNode;return n===null&&(n=e.stateNode=new dg),n;case 22:return e=e.stateNode,n=e._retryCache,n===null&&(n=e._retryCache=new dg),n;default:throw Error(s(435,e.tag))}}function Bl(e,n){var a=$x(e);n.forEach(function(o){if(!a.has(o)){a.add(o);var u=ly.bind(null,e,o);o.then(u,u)}})}function Wn(e,n){var a=n.deletions;if(a!==null)for(var o=0;o<a.length;o++){var u=a[o],f=e,S=n,A=S;t:for(;A!==null;){switch(A.tag){case 27:if(Ua(A.type)){Ze=A.stateNode,Xn=!1;break t}break;case 5:Ze=A.stateNode,Xn=!1;break t;case 3:case 4:Ze=A.stateNode.containerInfo,Xn=!0;break t}A=A.return}if(Ze===null)throw Error(s(160));gg(f,S,u),Ze=null,Xn=!1,f=u.alternate,f!==null&&(f.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)xg(n,e),n=n.sibling}var bi=null;function xg(e,n){var a=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Wn(n,e),qn(e),o&4&&(Ta(3,e,e.return),Mo(3,e),Ta(5,e,e.return));break;case 1:Wn(n,e),qn(e),o&512&&(un||a===null||Oi(a,a.return)),o&64&&Ji&&(e=e.updateQueue,e!==null&&(o=e.callbacks,o!==null&&(a=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=a===null?o:a.concat(o))));break;case 26:var u=bi;if(Wn(n,e),qn(e),o&512&&(un||a===null||Oi(a,a.return)),o&4){var f=a!==null?a.memoizedState:null;if(o=e.memoizedState,a===null)if(o===null)if(e.stateNode===null){t:{o=e.type,a=e.memoizedProps,u=u.ownerDocument||u;e:switch(o){case"title":f=u.getElementsByTagName("title")[0],(!f||f[es]||f[$e]||f.namespaceURI==="http://www.w3.org/2000/svg"||f.hasAttribute("itemprop"))&&(f=u.createElement(o),u.head.insertBefore(f,u.querySelector("head > title"))),Cn(f,o,a),f[$e]=e,q(f),o=f;break t;case"link":var S=x0("link","href",u).get(o+(a.href||""));if(S){for(var A=0;A<S.length;A++)if(f=S[A],f.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&f.getAttribute("rel")===(a.rel==null?null:a.rel)&&f.getAttribute("title")===(a.title==null?null:a.title)&&f.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){S.splice(A,1);break e}}f=u.createElement(o),Cn(f,o,a),u.head.appendChild(f);break;case"meta":if(S=x0("meta","content",u).get(o+(a.content||""))){for(A=0;A<S.length;A++)if(f=S[A],f.getAttribute("content")===(a.content==null?null:""+a.content)&&f.getAttribute("name")===(a.name==null?null:a.name)&&f.getAttribute("property")===(a.property==null?null:a.property)&&f.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&f.getAttribute("charset")===(a.charSet==null?null:a.charSet)){S.splice(A,1);break e}}f=u.createElement(o),Cn(f,o,a),u.head.appendChild(f);break;default:throw Error(s(468,o))}f[$e]=e,q(f),o=f}e.stateNode=o}else y0(u,e.type,e.stateNode);else e.stateNode=v0(u,o,e.memoizedProps);else f!==o?(f===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):f.count--,o===null?y0(u,e.type,e.stateNode):v0(u,o,e.memoizedProps)):o===null&&e.stateNode!==null&&Ef(e,e.memoizedProps,a.memoizedProps)}break;case 27:Wn(n,e),qn(e),o&512&&(un||a===null||Oi(a,a.return)),a!==null&&o&4&&Ef(e,e.memoizedProps,a.memoizedProps);break;case 5:if(Wn(n,e),qn(e),o&512&&(un||a===null||Oi(a,a.return)),e.flags&32){u=e.stateNode;try{kn(u,"")}catch(Gt){Pe(e,e.return,Gt)}}o&4&&e.stateNode!=null&&(u=e.memoizedProps,Ef(e,u,a!==null?a.memoizedProps:u)),o&1024&&(Rf=!0);break;case 6:if(Wn(n,e),qn(e),o&4){if(e.stateNode===null)throw Error(s(162));o=e.memoizedProps,a=e.stateNode;try{a.nodeValue=o}catch(Gt){Pe(e,e.return,Gt)}}break;case 3:if(tc=null,u=bi,bi=Jl(n.containerInfo),Wn(n,e),bi=u,qn(e),o&4&&a!==null&&a.memoizedState.isDehydrated)try{hr(n.containerInfo)}catch(Gt){Pe(e,e.return,Gt)}Rf&&(Rf=!1,yg(e));break;case 4:o=bi,bi=Jl(e.stateNode.containerInfo),Wn(n,e),qn(e),bi=o;break;case 12:Wn(n,e),qn(e);break;case 31:Wn(n,e),qn(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,Bl(e,o)));break;case 13:Wn(n,e),qn(e),e.child.flags&8192&&e.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(Hl=dt()),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,Bl(e,o)));break;case 22:u=e.memoizedState!==null;var F=a!==null&&a.memoizedState!==null,it=Ji,pt=un;if(Ji=it||u,un=pt||F,Wn(n,e),un=pt,Ji=it,qn(e),o&8192)t:for(n=e.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(a===null||F||Ji||un||gs(e)),a=null,n=e;;){if(n.tag===5||n.tag===26){if(a===null){F=a=n;try{if(f=F.stateNode,u)S=f.style,typeof S.setProperty=="function"?S.setProperty("display","none","important"):S.display="none";else{A=F.stateNode;var yt=F.memoizedProps.style,rt=yt!=null&&yt.hasOwnProperty("display")?yt.display:null;A.style.display=rt==null||typeof rt=="boolean"?"":(""+rt).trim()}}catch(Gt){Pe(F,F.return,Gt)}}}else if(n.tag===6){if(a===null){F=n;try{F.stateNode.nodeValue=u?"":F.memoizedProps}catch(Gt){Pe(F,F.return,Gt)}}}else if(n.tag===18){if(a===null){F=n;try{var ct=F.stateNode;u?c0(ct,!0):c0(F.stateNode,!1)}catch(Gt){Pe(F,F.return,Gt)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===e)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break t;for(;n.sibling===null;){if(n.return===null||n.return===e)break t;a===n&&(a=null),n=n.return}a===n&&(a=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=e.updateQueue,o!==null&&(a=o.retryQueue,a!==null&&(o.retryQueue=null,Bl(e,a))));break;case 19:Wn(n,e),qn(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,Bl(e,o)));break;case 30:break;case 21:break;default:Wn(n,e),qn(e)}}function qn(e){var n=e.flags;if(n&2){try{for(var a,o=e.return;o!==null;){if(fg(o)){a=o;break}o=o.return}if(a==null)throw Error(s(160));switch(a.tag){case 27:var u=a.stateNode,f=Tf(e);Il(e,f,u);break;case 5:var S=a.stateNode;a.flags&32&&(kn(S,""),a.flags&=-33);var A=Tf(e);Il(e,A,S);break;case 3:case 4:var F=a.stateNode.containerInfo,it=Tf(e);Af(e,it,F);break;default:throw Error(s(161))}}catch(pt){Pe(e,e.return,pt)}e.flags&=-3}n&4096&&(e.flags&=-4097)}function yg(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var n=e;yg(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),e=e.sibling}}function ta(e,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)pg(e,n.alternate,n),n=n.sibling}function gs(e){for(e=e.child;e!==null;){var n=e;switch(n.tag){case 0:case 11:case 14:case 15:Ta(4,n,n.return),gs(n);break;case 1:Oi(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&cg(n,n.return,a),gs(n);break;case 27:Uo(n.stateNode);case 26:case 5:Oi(n,n.return),gs(n);break;case 22:n.memoizedState===null&&gs(n);break;case 30:gs(n);break;default:gs(n)}e=e.sibling}}function ea(e,n,a){for(a=a&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=e,f=n,S=f.flags;switch(f.tag){case 0:case 11:case 15:ea(u,f,a),Mo(4,f);break;case 1:if(ea(u,f,a),o=f,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(it){Pe(o,o.return,it)}if(o=f,u=o.updateQueue,u!==null){var A=o.stateNode;try{var F=u.shared.hiddenCallbacks;if(F!==null)for(u.shared.hiddenCallbacks=null,u=0;u<F.length;u++)Qp(F[u],A)}catch(it){Pe(o,o.return,it)}}a&&S&64&&lg(f),bo(f,f.return);break;case 27:hg(f);case 26:case 5:ea(u,f,a),a&&o===null&&S&4&&ug(f),bo(f,f.return);break;case 12:ea(u,f,a);break;case 31:ea(u,f,a),a&&S&4&&_g(u,f);break;case 13:ea(u,f,a),a&&S&4&&vg(u,f);break;case 22:f.memoizedState===null&&ea(u,f,a),bo(f,f.return);break;case 30:break;default:ea(u,f,a)}n=n.sibling}}function Cf(e,n){var a=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),e=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(e=n.memoizedState.cachePool.pool),e!==a&&(e!=null&&e.refCount++,a!=null&&lo(a))}function wf(e,n){e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&lo(e))}function Ei(e,n,a,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)Sg(e,n,a,o),n=n.sibling}function Sg(e,n,a,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Ei(e,n,a,o),u&2048&&Mo(9,n);break;case 1:Ei(e,n,a,o);break;case 3:Ei(e,n,a,o),u&2048&&(e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&lo(e)));break;case 12:if(u&2048){Ei(e,n,a,o),e=n.stateNode;try{var f=n.memoizedProps,S=f.id,A=f.onPostCommit;typeof A=="function"&&A(S,n.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(F){Pe(n,n.return,F)}}else Ei(e,n,a,o);break;case 31:Ei(e,n,a,o);break;case 13:Ei(e,n,a,o);break;case 23:break;case 22:f=n.stateNode,S=n.alternate,n.memoizedState!==null?f._visibility&2?Ei(e,n,a,o):Eo(e,n):f._visibility&2?Ei(e,n,a,o):(f._visibility|=2,er(e,n,a,o,(n.subtreeFlags&10256)!==0||!1)),u&2048&&Cf(S,n);break;case 24:Ei(e,n,a,o),u&2048&&wf(n.alternate,n);break;default:Ei(e,n,a,o)}}function er(e,n,a,o,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var f=e,S=n,A=a,F=o,it=S.flags;switch(S.tag){case 0:case 11:case 15:er(f,S,A,F,u),Mo(8,S);break;case 23:break;case 22:var pt=S.stateNode;S.memoizedState!==null?pt._visibility&2?er(f,S,A,F,u):Eo(f,S):(pt._visibility|=2,er(f,S,A,F,u)),u&&it&2048&&Cf(S.alternate,S);break;case 24:er(f,S,A,F,u),u&&it&2048&&wf(S.alternate,S);break;default:er(f,S,A,F,u)}n=n.sibling}}function Eo(e,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var a=e,o=n,u=o.flags;switch(o.tag){case 22:Eo(a,o),u&2048&&Cf(o.alternate,o);break;case 24:Eo(a,o),u&2048&&wf(o.alternate,o);break;default:Eo(a,o)}n=n.sibling}}var To=8192;function nr(e,n,a){if(e.subtreeFlags&To)for(e=e.child;e!==null;)Mg(e,n,a),e=e.sibling}function Mg(e,n,a){switch(e.tag){case 26:nr(e,n,a),e.flags&To&&e.memoizedState!==null&&Fy(a,bi,e.memoizedState,e.memoizedProps);break;case 5:nr(e,n,a);break;case 3:case 4:var o=bi;bi=Jl(e.stateNode.containerInfo),nr(e,n,a),bi=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=To,To=16777216,nr(e,n,a),To=o):nr(e,n,a));break;default:nr(e,n,a)}}function bg(e){var n=e.alternate;if(n!==null&&(e=n.child,e!==null)){n.child=null;do n=e.sibling,e.sibling=null,e=n;while(e!==null)}}function Ao(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];yn=o,Tg(o,e)}bg(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Eg(e),e=e.sibling}function Eg(e){switch(e.tag){case 0:case 11:case 15:Ao(e),e.flags&2048&&Ta(9,e,e.return);break;case 3:Ao(e);break;case 12:Ao(e);break;case 22:var n=e.stateNode;e.memoizedState!==null&&n._visibility&2&&(e.return===null||e.return.tag!==13)?(n._visibility&=-3,Fl(e)):Ao(e);break;default:Ao(e)}}function Fl(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];yn=o,Tg(o,e)}bg(e)}for(e=e.child;e!==null;){switch(n=e,n.tag){case 0:case 11:case 15:Ta(8,n,n.return),Fl(n);break;case 22:a=n.stateNode,a._visibility&2&&(a._visibility&=-3,Fl(n));break;default:Fl(n)}e=e.sibling}}function Tg(e,n){for(;yn!==null;){var a=yn;switch(a.tag){case 0:case 11:case 15:Ta(8,a,n);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var o=a.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:lo(a.memoizedState.cache)}if(o=a.child,o!==null)o.return=a,yn=o;else t:for(a=e;yn!==null;){o=yn;var u=o.sibling,f=o.return;if(mg(o),o===a){yn=null;break t}if(u!==null){u.return=f,yn=u;break t}yn=f}}}var ty={getCacheForType:function(e){var n=An(on),a=n.data.get(e);return a===void 0&&(a=e(),n.data.set(e,a)),a},cacheSignal:function(){return An(on).controller.signal}},ey=typeof WeakMap=="function"?WeakMap:Map,Le=0,je=null,me=null,ve=0,Oe=0,ii=null,Aa=!1,ir=!1,Df=!1,na=0,nn=0,Ra=0,_s=0,Lf=0,ai=0,ar=0,Ro=null,Yn=null,Uf=!1,Hl=0,Ag=0,Gl=1/0,Vl=null,Ca=null,pn=0,wa=null,sr=null,ia=0,Nf=0,Of=null,Rg=null,Co=0,Pf=null;function si(){return(Le&2)!==0&&ve!==0?ve&-ve:z.T!==null?Gf():Yr()}function Cg(){if(ai===0)if((ve&536870912)===0||Me){var e=ht;ht<<=1,(ht&3932160)===0&&(ht=262144),ai=e}else ai=536870912;return e=ei.current,e!==null&&(e.flags|=32),ai}function Zn(e,n,a){(e===je&&(Oe===2||Oe===9)||e.cancelPendingCommit!==null)&&(rr(e,0),Da(e,ve,ai,!1)),Mn(e,a),((Le&2)===0||e!==je)&&(e===je&&((Le&2)===0&&(_s|=a),nn===4&&Da(e,ve,ai,!1)),Pi(e))}function wg(e,n,a){if((Le&6)!==0)throw Error(s(327));var o=!a&&(n&127)===0&&(n&e.expiredLanes)===0||$t(e,n),u=o?ay(e,n):If(e,n,!0),f=o;do{if(u===0){ir&&!o&&Da(e,n,0,!1);break}else{if(a=e.current.alternate,f&&!ny(a)){u=If(e,n,!1),f=!1;continue}if(u===2){if(f=n,e.errorRecoveryDisabledLanes&f)var S=0;else S=e.pendingLanes&-536870913,S=S!==0?S:S&536870912?536870912:0;if(S!==0){n=S;t:{var A=e;u=Ro;var F=A.current.memoizedState.isDehydrated;if(F&&(rr(A,S).flags|=256),S=If(A,S,!1),S!==2){if(Df&&!F){A.errorRecoveryDisabledLanes|=f,_s|=f,u=4;break t}f=Yn,Yn=u,f!==null&&(Yn===null?Yn=f:Yn.push.apply(Yn,f))}u=S}if(f=!1,u!==2)continue}}if(u===1){rr(e,0),Da(e,n,0,!0);break}t:{switch(o=e,f=u,f){case 0:case 1:throw Error(s(345));case 4:if((n&4194048)!==n)break;case 6:Da(o,n,ai,!Aa);break t;case 2:Yn=null;break;case 3:case 5:break;default:throw Error(s(329))}if((n&62914560)===n&&(u=Hl+300-dt(),10<u)){if(Da(o,n,ai,!Aa),Lt(o,0,!0)!==0)break t;ia=n,o.timeoutHandle=r0(Dg.bind(null,o,a,Yn,Vl,Uf,n,ai,_s,ar,Aa,f,"Throttled",-0,0),u);break t}Dg(o,a,Yn,Vl,Uf,n,ai,_s,ar,Aa,f,null,-0,0)}}break}while(!0);Pi(e)}function Dg(e,n,a,o,u,f,S,A,F,it,pt,yt,rt,ct){if(e.timeoutHandle=-1,yt=n.subtreeFlags,yt&8192||(yt&16785408)===16785408){yt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Vi},Mg(n,f,yt);var Gt=(f&62914560)===f?Hl-dt():(f&4194048)===f?Ag-dt():0;if(Gt=Hy(yt,Gt),Gt!==null){ia=f,e.cancelPendingCommit=Gt(Bg.bind(null,e,n,f,a,o,u,S,A,F,pt,yt,null,rt,ct)),Da(e,f,S,!it);return}}Bg(e,n,f,a,o,u,S,A,F)}function ny(e){for(var n=e;;){var a=n.tag;if((a===0||a===11||a===15)&&n.flags&16384&&(a=n.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var o=0;o<a.length;o++){var u=a[o],f=u.getSnapshot;u=u.value;try{if(!$n(f(),u))return!1}catch{return!1}}if(a=n.child,n.subtreeFlags&16384&&a!==null)a.return=n,n=a;else{if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function Da(e,n,a,o){n&=~Lf,n&=~_s,e.suspendedLanes|=n,e.pingedLanes&=~n,o&&(e.warmLanes|=n),o=e.expirationTimes;for(var u=n;0<u;){var f=31-Jt(u),S=1<<f;o[f]=-1,u&=~S}a!==0&&Wr(e,a,n)}function kl(){return(Le&6)===0?(wo(0),!1):!0}function zf(){if(me!==null){if(Oe===0)var e=me.return;else e=me,Wi=ls=null,Qu(e),Ks=null,uo=0,e=me;for(;e!==null;)og(e.alternate,e),e=e.return;me=null}}function rr(e,n){var a=e.timeoutHandle;a!==-1&&(e.timeoutHandle=-1,My(a)),a=e.cancelPendingCommit,a!==null&&(e.cancelPendingCommit=null,a()),ia=0,zf(),je=e,me=a=ji(e.current,null),ve=n,Oe=0,ii=null,Aa=!1,ir=$t(e,n),Df=!1,ar=ai=Lf=_s=Ra=nn=0,Yn=Ro=null,Uf=!1,(n&8)!==0&&(n|=n&32);var o=e.entangledLanes;if(o!==0)for(e=e.entanglements,o&=n;0<o;){var u=31-Jt(o),f=1<<u;n|=e[u],o&=~f}return na=n,ul(),a}function Lg(e,n){oe=null,z.H=xo,n===Zs||n===vl?(n=qp(),Oe=3):n===Fu?(n=qp(),Oe=4):Oe=n===pf?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,ii=n,me===null&&(nn=1,Ul(e,ui(n,e.current)))}function Ug(){var e=ei.current;return e===null?!0:(ve&4194048)===ve?pi===null:(ve&62914560)===ve||(ve&536870912)!==0?e===pi:!1}function Ng(){var e=z.H;return z.H=xo,e===null?xo:e}function Og(){var e=z.A;return z.A=ty,e}function jl(){nn=4,Aa||(ve&4194048)!==ve&&ei.current!==null||(ir=!0),(Ra&134217727)===0&&(_s&134217727)===0||je===null||Da(je,ve,ai,!1)}function If(e,n,a){var o=Le;Le|=2;var u=Ng(),f=Og();(je!==e||ve!==n)&&(Vl=null,rr(e,n)),n=!1;var S=nn;t:do try{if(Oe!==0&&me!==null){var A=me,F=ii;switch(Oe){case 8:zf(),S=6;break t;case 3:case 2:case 9:case 6:ei.current===null&&(n=!0);var it=Oe;if(Oe=0,ii=null,or(e,A,F,it),a&&ir){S=0;break t}break;default:it=Oe,Oe=0,ii=null,or(e,A,F,it)}}iy(),S=nn;break}catch(pt){Lg(e,pt)}while(!0);return n&&e.shellSuspendCounter++,Wi=ls=null,Le=o,z.H=u,z.A=f,me===null&&(je=null,ve=0,ul()),S}function iy(){for(;me!==null;)Pg(me)}function ay(e,n){var a=Le;Le|=2;var o=Ng(),u=Og();je!==e||ve!==n?(Vl=null,Gl=dt()+500,rr(e,n)):ir=$t(e,n);t:do try{if(Oe!==0&&me!==null){n=me;var f=ii;e:switch(Oe){case 1:Oe=0,ii=null,or(e,n,f,1);break;case 2:case 9:if(Xp(f)){Oe=0,ii=null,zg(n);break}n=function(){Oe!==2&&Oe!==9||je!==e||(Oe=7),Pi(e)},f.then(n,n);break t;case 3:Oe=7;break t;case 4:Oe=5;break t;case 7:Xp(f)?(Oe=0,ii=null,zg(n)):(Oe=0,ii=null,or(e,n,f,7));break;case 5:var S=null;switch(me.tag){case 26:S=me.memoizedState;case 5:case 27:var A=me;if(S?S0(S):A.stateNode.complete){Oe=0,ii=null;var F=A.sibling;if(F!==null)me=F;else{var it=A.return;it!==null?(me=it,Xl(it)):me=null}break e}}Oe=0,ii=null,or(e,n,f,5);break;case 6:Oe=0,ii=null,or(e,n,f,6);break;case 8:zf(),nn=6;break t;default:throw Error(s(462))}}sy();break}catch(pt){Lg(e,pt)}while(!0);return Wi=ls=null,z.H=o,z.A=u,Le=a,me!==null?0:(je=null,ve=0,ul(),nn)}function sy(){for(;me!==null&&!T();)Pg(me)}function Pg(e){var n=sg(e.alternate,e,na);e.memoizedProps=e.pendingProps,n===null?Xl(e):me=n}function zg(e){var n=e,a=n.alternate;switch(n.tag){case 15:case 0:n=$m(a,n,n.pendingProps,n.type,void 0,ve);break;case 11:n=$m(a,n,n.pendingProps,n.type.render,n.ref,ve);break;case 5:Qu(n);default:og(a,n),n=me=Op(n,na),n=sg(a,n,na)}e.memoizedProps=e.pendingProps,n===null?Xl(e):me=n}function or(e,n,a,o){Wi=ls=null,Qu(n),Ks=null,uo=0;var u=n.return;try{if(qx(e,u,n,a,ve)){nn=1,Ul(e,ui(a,e.current)),me=null;return}}catch(f){if(u!==null)throw me=u,f;nn=1,Ul(e,ui(a,e.current)),me=null;return}n.flags&32768?(Me||o===1?e=!0:ir||(ve&536870912)!==0?e=!1:(Aa=e=!0,(o===2||o===9||o===3||o===6)&&(o=ei.current,o!==null&&o.tag===13&&(o.flags|=16384))),Ig(n,e)):Xl(n)}function Xl(e){var n=e;do{if((n.flags&32768)!==0){Ig(n,Aa);return}e=n.return;var a=Kx(n.alternate,n,na);if(a!==null){me=a;return}if(n=n.sibling,n!==null){me=n;return}me=n=e}while(n!==null);nn===0&&(nn=5)}function Ig(e,n){do{var a=Qx(e.alternate,e);if(a!==null){a.flags&=32767,me=a;return}if(a=e.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!n&&(e=e.sibling,e!==null)){me=e;return}me=e=a}while(e!==null);nn=6,me=null}function Bg(e,n,a,o,u,f,S,A,F){e.cancelPendingCommit=null;do Wl();while(pn!==0);if((Le&6)!==0)throw Error(s(327));if(n!==null){if(n===e.current)throw Error(s(177));if(f=n.lanes|n.childLanes,f|=Eu,xi(e,a,f,S,A,F),e===je&&(me=je=null,ve=0),sr=n,wa=e,ia=a,Nf=f,Of=u,Rg=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,cy(Ct,function(){return kg(),null})):(e.callbackNode=null,e.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=z.T,z.T=null,u=W.p,W.p=2,S=Le,Le|=4;try{Jx(e,n,a)}finally{Le=S,W.p=u,z.T=o}}pn=1,Fg(),Hg(),Gg()}}function Fg(){if(pn===1){pn=0;var e=wa,n=sr,a=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||a){a=z.T,z.T=null;var o=W.p;W.p=2;var u=Le;Le|=4;try{xg(n,e);var f=Zf,S=Tp(e.containerInfo),A=f.focusedElem,F=f.selectionRange;if(S!==A&&A&&A.ownerDocument&&Ep(A.ownerDocument.documentElement,A)){if(F!==null&&xu(A)){var it=F.start,pt=F.end;if(pt===void 0&&(pt=it),"selectionStart"in A)A.selectionStart=it,A.selectionEnd=Math.min(pt,A.value.length);else{var yt=A.ownerDocument||document,rt=yt&&yt.defaultView||window;if(rt.getSelection){var ct=rt.getSelection(),Gt=A.textContent.length,Qt=Math.min(F.start,Gt),Ge=F.end===void 0?Qt:Math.min(F.end,Gt);!ct.extend&&Qt>Ge&&(S=Ge,Ge=Qt,Qt=S);var Q=bp(A,Qt),V=bp(A,Ge);if(Q&&V&&(ct.rangeCount!==1||ct.anchorNode!==Q.node||ct.anchorOffset!==Q.offset||ct.focusNode!==V.node||ct.focusOffset!==V.offset)){var nt=yt.createRange();nt.setStart(Q.node,Q.offset),ct.removeAllRanges(),Qt>Ge?(ct.addRange(nt),ct.extend(V.node,V.offset)):(nt.setEnd(V.node,V.offset),ct.addRange(nt))}}}}for(yt=[],ct=A;ct=ct.parentNode;)ct.nodeType===1&&yt.push({element:ct,left:ct.scrollLeft,top:ct.scrollTop});for(typeof A.focus=="function"&&A.focus(),A=0;A<yt.length;A++){var gt=yt[A];gt.element.scrollLeft=gt.left,gt.element.scrollTop=gt.top}}ac=!!Yf,Zf=Yf=null}finally{Le=u,W.p=o,z.T=a}}e.current=n,pn=2}}function Hg(){if(pn===2){pn=0;var e=wa,n=sr,a=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||a){a=z.T,z.T=null;var o=W.p;W.p=2;var u=Le;Le|=4;try{pg(e,n.alternate,n)}finally{Le=u,W.p=o,z.T=a}}pn=3}}function Gg(){if(pn===4||pn===3){pn=0,$();var e=wa,n=sr,a=ia,o=Rg;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?pn=5:(pn=0,sr=wa=null,Vg(e,e.pendingLanes));var u=e.pendingLanes;if(u===0&&(Ca=null),Os(a),n=n.stateNode,jt&&typeof jt.onCommitFiberRoot=="function")try{jt.onCommitFiberRoot(Kt,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=z.T,u=W.p,W.p=2,z.T=null;try{for(var f=e.onRecoverableError,S=0;S<o.length;S++){var A=o[S];f(A.value,{componentStack:A.stack})}}finally{z.T=n,W.p=u}}(ia&3)!==0&&Wl(),Pi(e),u=e.pendingLanes,(a&261930)!==0&&(u&42)!==0?e===Pf?Co++:(Co=0,Pf=e):Co=0,wo(0)}}function Vg(e,n){(e.pooledCacheLanes&=n)===0&&(n=e.pooledCache,n!=null&&(e.pooledCache=null,lo(n)))}function Wl(){return Fg(),Hg(),Gg(),kg()}function kg(){if(pn!==5)return!1;var e=wa,n=Nf;Nf=0;var a=Os(ia),o=z.T,u=W.p;try{W.p=32>a?32:a,z.T=null,a=Of,Of=null;var f=wa,S=ia;if(pn=0,sr=wa=null,ia=0,(Le&6)!==0)throw Error(s(331));var A=Le;if(Le|=4,Eg(f.current),Sg(f,f.current,S,a),Le=A,wo(0,!1),jt&&typeof jt.onPostCommitFiberRoot=="function")try{jt.onPostCommitFiberRoot(Kt,f)}catch{}return!0}finally{W.p=u,z.T=o,Vg(e,n)}}function jg(e,n,a){n=ui(a,n),n=df(e.stateNode,n,2),e=Ma(e,n,2),e!==null&&(Mn(e,2),Pi(e))}function Pe(e,n,a){if(e.tag===3)jg(e,e,a);else for(;n!==null;){if(n.tag===3){jg(n,e,a);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Ca===null||!Ca.has(o))){e=ui(a,e),a=Xm(2),o=Ma(n,a,2),o!==null&&(Wm(a,o,n,e),Mn(o,2),Pi(o));break}}n=n.return}}function Bf(e,n,a){var o=e.pingCache;if(o===null){o=e.pingCache=new ey;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(a)||(Df=!0,u.add(a),e=ry.bind(null,e,n,a),n.then(e,e))}function ry(e,n,a){var o=e.pingCache;o!==null&&o.delete(n),e.pingedLanes|=e.suspendedLanes&a,e.warmLanes&=~a,je===e&&(ve&a)===a&&(nn===4||nn===3&&(ve&62914560)===ve&&300>dt()-Hl?(Le&2)===0&&rr(e,0):Lf|=a,ar===ve&&(ar=0)),Pi(e)}function Xg(e,n){n===0&&(n=hn()),e=ss(e,n),e!==null&&(Mn(e,n),Pi(e))}function oy(e){var n=e.memoizedState,a=0;n!==null&&(a=n.retryLane),Xg(e,a)}function ly(e,n){var a=0;switch(e.tag){case 31:case 13:var o=e.stateNode,u=e.memoizedState;u!==null&&(a=u.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(s(314))}o!==null&&o.delete(n),Xg(e,a)}function cy(e,n){return Rt(e,n)}var ql=null,lr=null,Ff=!1,Yl=!1,Hf=!1,La=0;function Pi(e){e!==lr&&e.next===null&&(lr===null?ql=lr=e:lr=lr.next=e),Yl=!0,Ff||(Ff=!0,fy())}function wo(e,n){if(!Hf&&Yl){Hf=!0;do for(var a=!1,o=ql;o!==null;){if(e!==0){var u=o.pendingLanes;if(u===0)var f=0;else{var S=o.suspendedLanes,A=o.pingedLanes;f=(1<<31-Jt(42|e)+1)-1,f&=u&~(S&~A),f=f&201326741?f&201326741|1:f?f|2:0}f!==0&&(a=!0,Zg(o,f))}else f=ve,f=Lt(o,o===je?f:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(f&3)===0||$t(o,f)||(a=!0,Zg(o,f));o=o.next}while(a);Hf=!1}}function uy(){Wg()}function Wg(){Yl=Ff=!1;var e=0;La!==0&&Sy()&&(e=La);for(var n=dt(),a=null,o=ql;o!==null;){var u=o.next,f=qg(o,n);f===0?(o.next=null,a===null?ql=u:a.next=u,u===null&&(lr=a)):(a=o,(e!==0||(f&3)!==0)&&(Yl=!0)),o=u}pn!==0&&pn!==5||wo(e),La!==0&&(La=0)}function qg(e,n){for(var a=e.suspendedLanes,o=e.pingedLanes,u=e.expirationTimes,f=e.pendingLanes&-62914561;0<f;){var S=31-Jt(f),A=1<<S,F=u[S];F===-1?((A&a)===0||(A&o)!==0)&&(u[S]=Ye(A,n)):F<=n&&(e.expiredLanes|=A),f&=~A}if(n=je,a=ve,a=Lt(e,e===n?a:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,a===0||e===n&&(Oe===2||Oe===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&U(o),e.callbackNode=null,e.callbackPriority=0;if((a&3)===0||$t(e,a)){if(n=a&-a,n===e.callbackPriority)return n;switch(o!==null&&U(o),Os(a)){case 2:case 8:a=Bt;break;case 32:a=Ct;break;case 268435456:a=pe;break;default:a=Ct}return o=Yg.bind(null,e),a=Rt(a,o),e.callbackPriority=n,e.callbackNode=a,n}return o!==null&&o!==null&&U(o),e.callbackPriority=2,e.callbackNode=null,2}function Yg(e,n){if(pn!==0&&pn!==5)return e.callbackNode=null,e.callbackPriority=0,null;var a=e.callbackNode;if(Wl()&&e.callbackNode!==a)return null;var o=ve;return o=Lt(e,e===je?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(wg(e,o,n),qg(e,dt()),e.callbackNode!=null&&e.callbackNode===a?Yg.bind(null,e):null)}function Zg(e,n){if(Wl())return null;wg(e,n,!0)}function fy(){by(function(){(Le&6)!==0?Rt(mt,uy):Wg()})}function Gf(){if(La===0){var e=qs;e===0&&(e=wt,wt<<=1,(wt&261888)===0&&(wt=256)),La=e}return La}function Kg(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:nl(""+e)}function Qg(e,n){var a=n.ownerDocument.createElement("input");return a.name=n.name,a.value=n.value,e.id&&a.setAttribute("form",e.id),n.parentNode.insertBefore(a,n),e=new FormData(e),a.parentNode.removeChild(a),e}function hy(e,n,a,o,u){if(n==="submit"&&a&&a.stateNode===u){var f=Kg((u[bn]||null).action),S=o.submitter;S&&(n=(n=S[bn]||null)?Kg(n.formAction):S.getAttribute("formAction"),n!==null&&(f=n,S=null));var A=new rl("action","action",null,o,u);e.push({event:A,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(La!==0){var F=S?Qg(u,S):new FormData(u);of(a,{pending:!0,data:F,method:u.method,action:f},null,F)}}else typeof f=="function"&&(A.preventDefault(),F=S?Qg(u,S):new FormData(u),of(a,{pending:!0,data:F,method:u.method,action:f},f,F))},currentTarget:u}]})}}for(var Vf=0;Vf<bu.length;Vf++){var kf=bu[Vf],dy=kf.toLowerCase(),py=kf[0].toUpperCase()+kf.slice(1);Mi(dy,"on"+py)}Mi(Cp,"onAnimationEnd"),Mi(wp,"onAnimationIteration"),Mi(Dp,"onAnimationStart"),Mi("dblclick","onDoubleClick"),Mi("focusin","onFocus"),Mi("focusout","onBlur"),Mi(Dx,"onTransitionRun"),Mi(Lx,"onTransitionStart"),Mi(Ux,"onTransitionCancel"),Mi(Lp,"onTransitionEnd"),zt("onMouseEnter",["mouseout","mouseover"]),zt("onMouseLeave",["mouseout","mouseover"]),zt("onPointerEnter",["pointerout","pointerover"]),zt("onPointerLeave",["pointerout","pointerover"]),Ot("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Ot("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Ot("onBeforeInput",["compositionend","keypress","textInput","paste"]),Ot("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Ot("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Ot("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Do="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),my=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Do));function Jg(e,n){n=(n&4)!==0;for(var a=0;a<e.length;a++){var o=e[a],u=o.event;o=o.listeners;t:{var f=void 0;if(n)for(var S=o.length-1;0<=S;S--){var A=o[S],F=A.instance,it=A.currentTarget;if(A=A.listener,F!==f&&u.isPropagationStopped())break t;f=A,u.currentTarget=it;try{f(u)}catch(pt){cl(pt)}u.currentTarget=null,f=F}else for(S=0;S<o.length;S++){if(A=o[S],F=A.instance,it=A.currentTarget,A=A.listener,F!==f&&u.isPropagationStopped())break t;f=A,u.currentTarget=it;try{f(u)}catch(pt){cl(pt)}u.currentTarget=null,f=F}}}}function ge(e,n){var a=n[Zr];a===void 0&&(a=n[Zr]=new Set);var o=e+"__bubble";a.has(o)||($g(n,e,2,!1),a.add(o))}function jf(e,n,a){var o=0;n&&(o|=4),$g(a,e,o,n)}var Zl="_reactListening"+Math.random().toString(36).slice(2);function Xf(e){if(!e[Zl]){e[Zl]=!0,Tt.forEach(function(a){a!=="selectionchange"&&(my.has(a)||jf(a,!1,e),jf(a,!0,e))});var n=e.nodeType===9?e:e.ownerDocument;n===null||n[Zl]||(n[Zl]=!0,jf("selectionchange",!1,n))}}function $g(e,n,a,o){switch(C0(n)){case 2:var u=ky;break;case 8:u=jy;break;default:u=rh}a=u.bind(null,n,a,e),u=void 0,!uu||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?e.addEventListener(n,a,{capture:!0,passive:u}):e.addEventListener(n,a,!0):u!==void 0?e.addEventListener(n,a,{passive:u}):e.addEventListener(n,a,!1)}function Wf(e,n,a,o,u){var f=o;if((n&1)===0&&(n&2)===0&&o!==null)t:for(;;){if(o===null)return;var S=o.tag;if(S===3||S===4){var A=o.stateNode.containerInfo;if(A===u)break;if(S===4)for(S=o.return;S!==null;){var F=S.tag;if((F===3||F===4)&&S.stateNode.containerInfo===u)return;S=S.return}for(;A!==null;){if(S=C(A),S===null)return;if(F=S.tag,F===5||F===6||F===26||F===27){o=f=S;continue t}A=A.parentNode}}o=o.return}ap(function(){var it=f,pt=lu(a),yt=[];t:{var rt=Up.get(e);if(rt!==void 0){var ct=rl,Gt=e;switch(e){case"keypress":if(al(a)===0)break t;case"keydown":case"keyup":ct=lx;break;case"focusin":Gt="focus",ct=pu;break;case"focusout":Gt="blur",ct=pu;break;case"beforeblur":case"afterblur":ct=pu;break;case"click":if(a.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ct=op;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ct=Kv;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ct=fx;break;case Cp:case wp:case Dp:ct=$v;break;case Lp:ct=dx;break;case"scroll":case"scrollend":ct=Yv;break;case"wheel":ct=mx;break;case"copy":case"cut":case"paste":ct=ex;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ct=cp;break;case"toggle":case"beforetoggle":ct=_x}var Qt=(n&4)!==0,Ge=!Qt&&(e==="scroll"||e==="scrollend"),Q=Qt?rt!==null?rt+"Capture":null:rt;Qt=[];for(var V=it,nt;V!==null;){var gt=V;if(nt=gt.stateNode,gt=gt.tag,gt!==5&&gt!==26&&gt!==27||nt===null||Q===null||(gt=Qr(V,Q),gt!=null&&Qt.push(Lo(V,gt,nt))),Ge)break;V=V.return}0<Qt.length&&(rt=new ct(rt,Gt,null,a,pt),yt.push({event:rt,listeners:Qt}))}}if((n&7)===0){t:{if(rt=e==="mouseover"||e==="pointerover",ct=e==="mouseout"||e==="pointerout",rt&&a!==ou&&(Gt=a.relatedTarget||a.fromElement)&&(C(Gt)||Gt[Gi]))break t;if((ct||rt)&&(rt=pt.window===pt?pt:(rt=pt.ownerDocument)?rt.defaultView||rt.parentWindow:window,ct?(Gt=a.relatedTarget||a.toElement,ct=it,Gt=Gt?C(Gt):null,Gt!==null&&(Ge=c(Gt),Qt=Gt.tag,Gt!==Ge||Qt!==5&&Qt!==27&&Qt!==6)&&(Gt=null)):(ct=null,Gt=it),ct!==Gt)){if(Qt=op,gt="onMouseLeave",Q="onMouseEnter",V="mouse",(e==="pointerout"||e==="pointerover")&&(Qt=cp,gt="onPointerLeave",Q="onPointerEnter",V="pointer"),Ge=ct==null?rt:ot(ct),nt=Gt==null?rt:ot(Gt),rt=new Qt(gt,V+"leave",ct,a,pt),rt.target=Ge,rt.relatedTarget=nt,gt=null,C(pt)===it&&(Qt=new Qt(Q,V+"enter",Gt,a,pt),Qt.target=nt,Qt.relatedTarget=Ge,gt=Qt),Ge=gt,ct&&Gt)e:{for(Qt=gy,Q=ct,V=Gt,nt=0,gt=Q;gt;gt=Qt(gt))nt++;gt=0;for(var qt=V;qt;qt=Qt(qt))gt++;for(;0<nt-gt;)Q=Qt(Q),nt--;for(;0<gt-nt;)V=Qt(V),gt--;for(;nt--;){if(Q===V||V!==null&&Q===V.alternate){Qt=Q;break e}Q=Qt(Q),V=Qt(V)}Qt=null}else Qt=null;ct!==null&&t0(yt,rt,ct,Qt,!1),Gt!==null&&Ge!==null&&t0(yt,Ge,Gt,Qt,!0)}}t:{if(rt=it?ot(it):window,ct=rt.nodeName&&rt.nodeName.toLowerCase(),ct==="select"||ct==="input"&&rt.type==="file")var Ce=_p;else if(mp(rt))if(vp)Ce=Rx;else{Ce=Tx;var Vt=Ex}else ct=rt.nodeName,!ct||ct.toLowerCase()!=="input"||rt.type!=="checkbox"&&rt.type!=="radio"?it&&ru(it.elementType)&&(Ce=_p):Ce=Ax;if(Ce&&(Ce=Ce(e,it))){gp(yt,Ce,a,pt);break t}Vt&&Vt(e,rt,it),e==="focusout"&&it&&rt.type==="number"&&it.memoizedProps.value!=null&&Dn(rt,"number",rt.value)}switch(Vt=it?ot(it):window,e){case"focusin":(mp(Vt)||Vt.contentEditable==="true")&&(Fs=Vt,yu=it,so=null);break;case"focusout":so=yu=Fs=null;break;case"mousedown":Su=!0;break;case"contextmenu":case"mouseup":case"dragend":Su=!1,Ap(yt,a,pt);break;case"selectionchange":if(wx)break;case"keydown":case"keyup":Ap(yt,a,pt)}var ce;if(gu)t:{switch(e){case"compositionstart":var xe="onCompositionStart";break t;case"compositionend":xe="onCompositionEnd";break t;case"compositionupdate":xe="onCompositionUpdate";break t}xe=void 0}else Bs?dp(e,a)&&(xe="onCompositionEnd"):e==="keydown"&&a.keyCode===229&&(xe="onCompositionStart");xe&&(up&&a.locale!=="ko"&&(Bs||xe!=="onCompositionStart"?xe==="onCompositionEnd"&&Bs&&(ce=sp()):(ma=pt,fu="value"in ma?ma.value:ma.textContent,Bs=!0)),Vt=Kl(it,xe),0<Vt.length&&(xe=new lp(xe,e,null,a,pt),yt.push({event:xe,listeners:Vt}),ce?xe.data=ce:(ce=pp(a),ce!==null&&(xe.data=ce)))),(ce=xx?yx(e,a):Sx(e,a))&&(xe=Kl(it,"onBeforeInput"),0<xe.length&&(Vt=new lp("onBeforeInput","beforeinput",null,a,pt),yt.push({event:Vt,listeners:xe}),Vt.data=ce)),hy(yt,e,it,a,pt)}Jg(yt,n)})}function Lo(e,n,a){return{instance:e,listener:n,currentTarget:a}}function Kl(e,n){for(var a=n+"Capture",o=[];e!==null;){var u=e,f=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||f===null||(u=Qr(e,a),u!=null&&o.unshift(Lo(e,u,f)),u=Qr(e,n),u!=null&&o.push(Lo(e,u,f))),e.tag===3)return o;e=e.return}return[]}function gy(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function t0(e,n,a,o,u){for(var f=n._reactName,S=[];a!==null&&a!==o;){var A=a,F=A.alternate,it=A.stateNode;if(A=A.tag,F!==null&&F===o)break;A!==5&&A!==26&&A!==27||it===null||(F=it,u?(it=Qr(a,f),it!=null&&S.unshift(Lo(a,it,F))):u||(it=Qr(a,f),it!=null&&S.push(Lo(a,it,F)))),a=a.return}S.length!==0&&e.push({event:n,listeners:S})}var _y=/\r\n?/g,vy=/\u0000|\uFFFD/g;function e0(e){return(typeof e=="string"?e:""+e).replace(_y,`
`).replace(vy,"")}function n0(e,n){return n=e0(n),e0(e)===n}function He(e,n,a,o,u,f){switch(a){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||kn(e,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&kn(e,""+o);break;case"className":Xe(e,"class",o);break;case"tabIndex":Xe(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Xe(e,a,o);break;case"style":np(e,o,f);break;case"data":if(n!=="object"){Xe(e,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||a!=="href")){e.removeAttribute(a);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(a);break}o=nl(""+o),e.setAttribute(a,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof f=="function"&&(a==="formAction"?(n!=="input"&&He(e,n,"name",u.name,u,null),He(e,n,"formEncType",u.formEncType,u,null),He(e,n,"formMethod",u.formMethod,u,null),He(e,n,"formTarget",u.formTarget,u,null)):(He(e,n,"encType",u.encType,u,null),He(e,n,"method",u.method,u,null),He(e,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(a);break}o=nl(""+o),e.setAttribute(a,o);break;case"onClick":o!=null&&(e.onclick=Vi);break;case"onScroll":o!=null&&ge("scroll",e);break;case"onScrollEnd":o!=null&&ge("scrollend",e);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));e.innerHTML=a}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}a=nl(""+o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,""+o):e.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,""):e.removeAttribute(a);break;case"capture":case"download":o===!0?e.setAttribute(a,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,o):e.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(a,o):e.removeAttribute(a);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(a):e.setAttribute(a,o);break;case"popover":ge("beforetoggle",e),ge("toggle",e),Se(e,"popover",o);break;case"xlinkActuate":Re(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Re(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Re(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Re(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Re(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Re(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Re(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Re(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Re(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Se(e,"is",o);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=Wv.get(a)||a,Se(e,a,o))}}function qf(e,n,a,o,u,f){switch(a){case"style":np(e,o,f);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));e.innerHTML=a}}break;case"children":typeof o=="string"?kn(e,o):(typeof o=="number"||typeof o=="bigint")&&kn(e,""+o);break;case"onScroll":o!=null&&ge("scroll",e);break;case"onScrollEnd":o!=null&&ge("scrollend",e);break;case"onClick":o!=null&&(e.onclick=Vi);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Ut.hasOwnProperty(a))t:{if(a[0]==="o"&&a[1]==="n"&&(u=a.endsWith("Capture"),n=a.slice(2,u?a.length-7:void 0),f=e[bn]||null,f=f!=null?f[a]:null,typeof f=="function"&&e.removeEventListener(n,f,u),typeof o=="function")){typeof f!="function"&&f!==null&&(a in e?e[a]=null:e.hasAttribute(a)&&e.removeAttribute(a)),e.addEventListener(n,o,u);break t}a in e?e[a]=o:o===!0?e.setAttribute(a,""):Se(e,a,o)}}}function Cn(e,n,a){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ge("error",e),ge("load",e);var o=!1,u=!1,f;for(f in a)if(a.hasOwnProperty(f)){var S=a[f];if(S!=null)switch(f){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:He(e,n,f,S,a,null)}}u&&He(e,n,"srcSet",a.srcSet,a,null),o&&He(e,n,"src",a.src,a,null);return;case"input":ge("invalid",e);var A=f=S=u=null,F=null,it=null;for(o in a)if(a.hasOwnProperty(o)){var pt=a[o];if(pt!=null)switch(o){case"name":u=pt;break;case"type":S=pt;break;case"checked":F=pt;break;case"defaultChecked":it=pt;break;case"value":f=pt;break;case"defaultValue":A=pt;break;case"children":case"dangerouslySetInnerHTML":if(pt!=null)throw Error(s(137,n));break;default:He(e,n,o,pt,a,null)}}Pn(e,f,A,F,it,S,u,!1);return;case"select":ge("invalid",e),o=S=f=null;for(u in a)if(a.hasOwnProperty(u)&&(A=a[u],A!=null))switch(u){case"value":f=A;break;case"defaultValue":S=A;break;case"multiple":o=A;default:He(e,n,u,A,a,null)}n=f,a=S,e.multiple=!!o,n!=null?tn(e,!!o,n,!1):a!=null&&tn(e,!!o,a,!0);return;case"textarea":ge("invalid",e),f=u=o=null;for(S in a)if(a.hasOwnProperty(S)&&(A=a[S],A!=null))switch(S){case"value":o=A;break;case"defaultValue":u=A;break;case"children":f=A;break;case"dangerouslySetInnerHTML":if(A!=null)throw Error(s(91));break;default:He(e,n,S,A,a,null)}Ps(e,o,u,f);return;case"option":for(F in a)if(a.hasOwnProperty(F)&&(o=a[F],o!=null))switch(F){case"selected":e.selected=o&&typeof o!="function"&&typeof o!="symbol";break;default:He(e,n,F,o,a,null)}return;case"dialog":ge("beforetoggle",e),ge("toggle",e),ge("cancel",e),ge("close",e);break;case"iframe":case"object":ge("load",e);break;case"video":case"audio":for(o=0;o<Do.length;o++)ge(Do[o],e);break;case"image":ge("error",e),ge("load",e);break;case"details":ge("toggle",e);break;case"embed":case"source":case"link":ge("error",e),ge("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(it in a)if(a.hasOwnProperty(it)&&(o=a[it],o!=null))switch(it){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:He(e,n,it,o,a,null)}return;default:if(ru(n)){for(pt in a)a.hasOwnProperty(pt)&&(o=a[pt],o!==void 0&&qf(e,n,pt,o,a,void 0));return}}for(A in a)a.hasOwnProperty(A)&&(o=a[A],o!=null&&He(e,n,A,o,a,null))}function xy(e,n,a,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,f=null,S=null,A=null,F=null,it=null,pt=null;for(ct in a){var yt=a[ct];if(a.hasOwnProperty(ct)&&yt!=null)switch(ct){case"checked":break;case"value":break;case"defaultValue":F=yt;default:o.hasOwnProperty(ct)||He(e,n,ct,null,o,yt)}}for(var rt in o){var ct=o[rt];if(yt=a[rt],o.hasOwnProperty(rt)&&(ct!=null||yt!=null))switch(rt){case"type":f=ct;break;case"name":u=ct;break;case"checked":it=ct;break;case"defaultChecked":pt=ct;break;case"value":S=ct;break;case"defaultValue":A=ct;break;case"children":case"dangerouslySetInnerHTML":if(ct!=null)throw Error(s(137,n));break;default:ct!==yt&&He(e,n,rt,ct,o,yt)}}Be(e,S,A,F,it,pt,f,u);return;case"select":ct=S=A=rt=null;for(f in a)if(F=a[f],a.hasOwnProperty(f)&&F!=null)switch(f){case"value":break;case"multiple":ct=F;default:o.hasOwnProperty(f)||He(e,n,f,null,o,F)}for(u in o)if(f=o[u],F=a[u],o.hasOwnProperty(u)&&(f!=null||F!=null))switch(u){case"value":rt=f;break;case"defaultValue":A=f;break;case"multiple":S=f;default:f!==F&&He(e,n,u,f,o,F)}n=A,a=S,o=ct,rt!=null?tn(e,!!a,rt,!1):!!o!=!!a&&(n!=null?tn(e,!!a,n,!0):tn(e,!!a,a?[]:"",!1));return;case"textarea":ct=rt=null;for(A in a)if(u=a[A],a.hasOwnProperty(A)&&u!=null&&!o.hasOwnProperty(A))switch(A){case"value":break;case"children":break;default:He(e,n,A,null,o,u)}for(S in o)if(u=o[S],f=a[S],o.hasOwnProperty(S)&&(u!=null||f!=null))switch(S){case"value":rt=u;break;case"defaultValue":ct=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(s(91));break;default:u!==f&&He(e,n,S,u,o,f)}En(e,rt,ct);return;case"option":for(var Gt in a)if(rt=a[Gt],a.hasOwnProperty(Gt)&&rt!=null&&!o.hasOwnProperty(Gt))switch(Gt){case"selected":e.selected=!1;break;default:He(e,n,Gt,null,o,rt)}for(F in o)if(rt=o[F],ct=a[F],o.hasOwnProperty(F)&&rt!==ct&&(rt!=null||ct!=null))switch(F){case"selected":e.selected=rt&&typeof rt!="function"&&typeof rt!="symbol";break;default:He(e,n,F,rt,o,ct)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var Qt in a)rt=a[Qt],a.hasOwnProperty(Qt)&&rt!=null&&!o.hasOwnProperty(Qt)&&He(e,n,Qt,null,o,rt);for(it in o)if(rt=o[it],ct=a[it],o.hasOwnProperty(it)&&rt!==ct&&(rt!=null||ct!=null))switch(it){case"children":case"dangerouslySetInnerHTML":if(rt!=null)throw Error(s(137,n));break;default:He(e,n,it,rt,o,ct)}return;default:if(ru(n)){for(var Ge in a)rt=a[Ge],a.hasOwnProperty(Ge)&&rt!==void 0&&!o.hasOwnProperty(Ge)&&qf(e,n,Ge,void 0,o,rt);for(pt in o)rt=o[pt],ct=a[pt],!o.hasOwnProperty(pt)||rt===ct||rt===void 0&&ct===void 0||qf(e,n,pt,rt,o,ct);return}}for(var Q in a)rt=a[Q],a.hasOwnProperty(Q)&&rt!=null&&!o.hasOwnProperty(Q)&&He(e,n,Q,null,o,rt);for(yt in o)rt=o[yt],ct=a[yt],!o.hasOwnProperty(yt)||rt===ct||rt==null&&ct==null||He(e,n,yt,rt,o,ct)}function i0(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function yy(){if(typeof performance.getEntriesByType=="function"){for(var e=0,n=0,a=performance.getEntriesByType("resource"),o=0;o<a.length;o++){var u=a[o],f=u.transferSize,S=u.initiatorType,A=u.duration;if(f&&A&&i0(S)){for(S=0,A=u.responseEnd,o+=1;o<a.length;o++){var F=a[o],it=F.startTime;if(it>A)break;var pt=F.transferSize,yt=F.initiatorType;pt&&i0(yt)&&(F=F.responseEnd,S+=pt*(F<A?1:(A-it)/(F-it)))}if(--o,n+=8*(f+S)/(u.duration/1e3),e++,10<e)break}}if(0<e)return n/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Yf=null,Zf=null;function Ql(e){return e.nodeType===9?e:e.ownerDocument}function a0(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function s0(e,n){if(e===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&n==="foreignObject"?0:e}function Kf(e,n){return e==="textarea"||e==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var Qf=null;function Sy(){var e=window.event;return e&&e.type==="popstate"?e===Qf?!1:(Qf=e,!0):(Qf=null,!1)}var r0=typeof setTimeout=="function"?setTimeout:void 0,My=typeof clearTimeout=="function"?clearTimeout:void 0,o0=typeof Promise=="function"?Promise:void 0,by=typeof queueMicrotask=="function"?queueMicrotask:typeof o0<"u"?function(e){return o0.resolve(null).then(e).catch(Ey)}:r0;function Ey(e){setTimeout(function(){throw e})}function Ua(e){return e==="head"}function l0(e,n){var a=n,o=0;do{var u=a.nextSibling;if(e.removeChild(a),u&&u.nodeType===8)if(a=u.data,a==="/$"||a==="/&"){if(o===0){e.removeChild(u),hr(n);return}o--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")o++;else if(a==="html")Uo(e.ownerDocument.documentElement);else if(a==="head"){a=e.ownerDocument.head,Uo(a);for(var f=a.firstChild;f;){var S=f.nextSibling,A=f.nodeName;f[es]||A==="SCRIPT"||A==="STYLE"||A==="LINK"&&f.rel.toLowerCase()==="stylesheet"||a.removeChild(f),f=S}}else a==="body"&&Uo(e.ownerDocument.body);a=u}while(a);hr(n)}function c0(e,n){var a=e;e=0;do{var o=a.nextSibling;if(a.nodeType===1?n?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(n?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),o&&o.nodeType===8)if(a=o.data,a==="/$"){if(e===0)break;e--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||e++;a=o}while(a)}function Jf(e){var n=e.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var a=n;switch(n=n.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":Jf(a),Kr(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}e.removeChild(a)}}function Ty(e,n,a,o){for(;e.nodeType===1;){var u=a;if(e.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[es])switch(n){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(f=e.getAttribute("rel"),f==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(f!==u.rel||e.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||e.getAttribute("title")!==(u.title==null?null:u.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(f=e.getAttribute("src"),(f!==(u.src==null?null:u.src)||e.getAttribute("type")!==(u.type==null?null:u.type)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&f&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(n==="input"&&e.type==="hidden"){var f=u.name==null?null:""+u.name;if(u.type==="hidden"&&e.getAttribute("name")===f)return e}else return e;if(e=mi(e.nextSibling),e===null)break}return null}function Ay(e,n,a){if(n==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!a||(e=mi(e.nextSibling),e===null))return null;return e}function u0(e,n){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=mi(e.nextSibling),e===null))return null;return e}function $f(e){return e.data==="$?"||e.data==="$~"}function th(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function Ry(e,n){var a=e.ownerDocument;if(e.data==="$~")e._reactRetry=n;else if(e.data!=="$?"||a.readyState!=="loading")n();else{var o=function(){n(),a.removeEventListener("DOMContentLoaded",o)};a.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function mi(e){for(;e!=null;e=e.nextSibling){var n=e.nodeType;if(n===1||n===3)break;if(n===8){if(n=e.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return e}var eh=null;function f0(e){e=e.nextSibling;for(var n=0;e;){if(e.nodeType===8){var a=e.data;if(a==="/$"||a==="/&"){if(n===0)return mi(e.nextSibling);n--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||n++}e=e.nextSibling}return null}function h0(e){e=e.previousSibling;for(var n=0;e;){if(e.nodeType===8){var a=e.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(n===0)return e;n--}else a!=="/$"&&a!=="/&"||n++}e=e.previousSibling}return null}function d0(e,n,a){switch(n=Ql(a),e){case"html":if(e=n.documentElement,!e)throw Error(s(452));return e;case"head":if(e=n.head,!e)throw Error(s(453));return e;case"body":if(e=n.body,!e)throw Error(s(454));return e;default:throw Error(s(451))}}function Uo(e){for(var n=e.attributes;n.length;)e.removeAttributeNode(n[0]);Kr(e)}var gi=new Map,p0=new Set;function Jl(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var aa=W.d;W.d={f:Cy,r:wy,D:Dy,C:Ly,L:Uy,m:Ny,X:Py,S:Oy,M:zy};function Cy(){var e=aa.f(),n=kl();return e||n}function wy(e){var n=K(e);n!==null&&n.tag===5&&n.type==="form"?Lm(n):aa.r(e)}var cr=typeof document>"u"?null:document;function m0(e,n,a){var o=cr;if(o&&typeof n=="string"&&n){var u=xn(n);u='link[rel="'+e+'"][href="'+u+'"]',typeof a=="string"&&(u+='[crossorigin="'+a+'"]'),p0.has(u)||(p0.add(u),e={rel:e,crossOrigin:a,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),Cn(n,"link",e),q(n),o.head.appendChild(n)))}}function Dy(e){aa.D(e),m0("dns-prefetch",e,null)}function Ly(e,n){aa.C(e,n),m0("preconnect",e,n)}function Uy(e,n,a){aa.L(e,n,a);var o=cr;if(o&&e&&n){var u='link[rel="preload"][as="'+xn(n)+'"]';n==="image"&&a&&a.imageSrcSet?(u+='[imagesrcset="'+xn(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(u+='[imagesizes="'+xn(a.imageSizes)+'"]')):u+='[href="'+xn(e)+'"]';var f=u;switch(n){case"style":f=ur(e);break;case"script":f=fr(e)}gi.has(f)||(e=_({rel:"preload",href:n==="image"&&a&&a.imageSrcSet?void 0:e,as:n},a),gi.set(f,e),o.querySelector(u)!==null||n==="style"&&o.querySelector(No(f))||n==="script"&&o.querySelector(Oo(f))||(n=o.createElement("link"),Cn(n,"link",e),q(n),o.head.appendChild(n)))}}function Ny(e,n){aa.m(e,n);var a=cr;if(a&&e){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+xn(o)+'"][href="'+xn(e)+'"]',f=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":f=fr(e)}if(!gi.has(f)&&(e=_({rel:"modulepreload",href:e},n),gi.set(f,e),a.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Oo(f)))return}o=a.createElement("link"),Cn(o,"link",e),q(o),a.head.appendChild(o)}}}function Oy(e,n,a){aa.S(e,n,a);var o=cr;if(o&&e){var u=lt(o).hoistableStyles,f=ur(e);n=n||"default";var S=u.get(f);if(!S){var A={loading:0,preload:null};if(S=o.querySelector(No(f)))A.loading=5;else{e=_({rel:"stylesheet",href:e,"data-precedence":n},a),(a=gi.get(f))&&nh(e,a);var F=S=o.createElement("link");q(F),Cn(F,"link",e),F._p=new Promise(function(it,pt){F.onload=it,F.onerror=pt}),F.addEventListener("load",function(){A.loading|=1}),F.addEventListener("error",function(){A.loading|=2}),A.loading|=4,$l(S,n,o)}S={type:"stylesheet",instance:S,count:1,state:A},u.set(f,S)}}}function Py(e,n){aa.X(e,n);var a=cr;if(a&&e){var o=lt(a).hoistableScripts,u=fr(e),f=o.get(u);f||(f=a.querySelector(Oo(u)),f||(e=_({src:e,async:!0},n),(n=gi.get(u))&&ih(e,n),f=a.createElement("script"),q(f),Cn(f,"link",e),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(u,f))}}function zy(e,n){aa.M(e,n);var a=cr;if(a&&e){var o=lt(a).hoistableScripts,u=fr(e),f=o.get(u);f||(f=a.querySelector(Oo(u)),f||(e=_({src:e,async:!0,type:"module"},n),(n=gi.get(u))&&ih(e,n),f=a.createElement("script"),q(f),Cn(f,"link",e),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(u,f))}}function g0(e,n,a,o){var u=(u=xt.current)?Jl(u):null;if(!u)throw Error(s(446));switch(e){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(n=ur(a.href),a=lt(u).hoistableStyles,o=a.get(n),o||(o={type:"style",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){e=ur(a.href);var f=lt(u).hoistableStyles,S=f.get(e);if(S||(u=u.ownerDocument||u,S={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},f.set(e,S),(f=u.querySelector(No(e)))&&!f._p&&(S.instance=f,S.state.loading=5),gi.has(e)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},gi.set(e,a),f||Iy(u,e,a,S.state))),n&&o===null)throw Error(s(528,""));return S}if(n&&o!==null)throw Error(s(529,""));return null;case"script":return n=a.async,a=a.src,typeof a=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=fr(a),a=lt(u).hoistableScripts,o=a.get(n),o||(o={type:"script",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,e))}}function ur(e){return'href="'+xn(e)+'"'}function No(e){return'link[rel="stylesheet"]['+e+"]"}function _0(e){return _({},e,{"data-precedence":e.precedence,precedence:null})}function Iy(e,n,a,o){e.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=e.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),Cn(n,"link",a),q(n),e.head.appendChild(n))}function fr(e){return'[src="'+xn(e)+'"]'}function Oo(e){return"script[async]"+e}function v0(e,n,a){if(n.count++,n.instance===null)switch(n.type){case"style":var o=e.querySelector('style[data-href~="'+xn(a.href)+'"]');if(o)return n.instance=o,q(o),o;var u=_({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),q(o),Cn(o,"style",u),$l(o,a.precedence,e),n.instance=o;case"stylesheet":u=ur(a.href);var f=e.querySelector(No(u));if(f)return n.state.loading|=4,n.instance=f,q(f),f;o=_0(a),(u=gi.get(u))&&nh(o,u),f=(e.ownerDocument||e).createElement("link"),q(f);var S=f;return S._p=new Promise(function(A,F){S.onload=A,S.onerror=F}),Cn(f,"link",o),n.state.loading|=4,$l(f,a.precedence,e),n.instance=f;case"script":return f=fr(a.src),(u=e.querySelector(Oo(f)))?(n.instance=u,q(u),u):(o=a,(u=gi.get(f))&&(o=_({},a),ih(o,u)),e=e.ownerDocument||e,u=e.createElement("script"),q(u),Cn(u,"link",o),e.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(s(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,$l(o,a.precedence,e));return n.instance}function $l(e,n,a){for(var o=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,f=u,S=0;S<o.length;S++){var A=o[S];if(A.dataset.precedence===n)f=A;else if(f!==u)break}f?f.parentNode.insertBefore(e,f.nextSibling):(n=a.nodeType===9?a.head:a,n.insertBefore(e,n.firstChild))}function nh(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.title==null&&(e.title=n.title)}function ih(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.integrity==null&&(e.integrity=n.integrity)}var tc=null;function x0(e,n,a){if(tc===null){var o=new Map,u=tc=new Map;u.set(a,o)}else u=tc,o=u.get(a),o||(o=new Map,u.set(a,o));if(o.has(e))return o;for(o.set(e,null),a=a.getElementsByTagName(e),u=0;u<a.length;u++){var f=a[u];if(!(f[es]||f[$e]||e==="link"&&f.getAttribute("rel")==="stylesheet")&&f.namespaceURI!=="http://www.w3.org/2000/svg"){var S=f.getAttribute(n)||"";S=e+S;var A=o.get(S);A?A.push(f):o.set(S,[f])}}return o}function y0(e,n,a){e=e.ownerDocument||e,e.head.insertBefore(a,n==="title"?e.querySelector("head > title"):null)}function By(e,n,a){if(a===1||n.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;switch(n.rel){case"stylesheet":return e=n.disabled,typeof n.precedence=="string"&&e==null;default:return!0}case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function S0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function Fy(e,n,a,o){if(a.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var u=ur(o.href),f=n.querySelector(No(u));if(f){n=f._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(e.count++,e=ec.bind(e),n.then(e,e)),a.state.loading|=4,a.instance=f,q(f);return}f=n.ownerDocument||n,o=_0(o),(u=gi.get(u))&&nh(o,u),f=f.createElement("link"),q(f);var S=f;S._p=new Promise(function(A,F){S.onload=A,S.onerror=F}),Cn(f,"link",o),a.instance=f}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(a,n),(n=a.state.preload)&&(a.state.loading&3)===0&&(e.count++,a=ec.bind(e),n.addEventListener("load",a),n.addEventListener("error",a))}}var ah=0;function Hy(e,n){return e.stylesheets&&e.count===0&&ic(e,e.stylesheets),0<e.count||0<e.imgCount?function(a){var o=setTimeout(function(){if(e.stylesheets&&ic(e,e.stylesheets),e.unsuspend){var f=e.unsuspend;e.unsuspend=null,f()}},6e4+n);0<e.imgBytes&&ah===0&&(ah=62500*yy());var u=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&ic(e,e.stylesheets),e.unsuspend)){var f=e.unsuspend;e.unsuspend=null,f()}},(e.imgBytes>ah?50:800)+n);return e.unsuspend=a,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(u)}}:null}function ec(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)ic(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var nc=null;function ic(e,n){e.stylesheets=null,e.unsuspend!==null&&(e.count++,nc=new Map,n.forEach(Gy,e),nc=null,ec.call(e))}function Gy(e,n){if(!(n.state.loading&4)){var a=nc.get(e);if(a)var o=a.get(null);else{a=new Map,nc.set(e,a);for(var u=e.querySelectorAll("link[data-precedence],style[data-precedence]"),f=0;f<u.length;f++){var S=u[f];(S.nodeName==="LINK"||S.getAttribute("media")!=="not all")&&(a.set(S.dataset.precedence,S),o=S)}o&&a.set(null,o)}u=n.instance,S=u.getAttribute("data-precedence"),f=a.get(S)||o,f===o&&a.set(null,u),a.set(S,u),this.count++,o=ec.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),f?f.parentNode.insertBefore(u,f.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(u,e.firstChild)),n.state.loading|=4}}var Po={$$typeof:N,Provider:null,Consumer:null,_currentValue:X,_currentValue2:X,_threadCount:0};function Vy(e,n,a,o,u,f,S,A,F){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Te(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Te(0),this.hiddenUpdates=Te(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=f,this.onRecoverableError=S,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=F,this.incompleteTransitions=new Map}function M0(e,n,a,o,u,f,S,A,F,it,pt,yt){return e=new Vy(e,n,a,S,F,it,pt,yt,A),n=1,f===!0&&(n|=24),f=ti(3,null,null,n),e.current=f,f.stateNode=e,n=zu(),n.refCount++,e.pooledCache=n,n.refCount++,f.memoizedState={element:o,isDehydrated:a,cache:n},Hu(f),e}function b0(e){return e?(e=Vs,e):Vs}function E0(e,n,a,o,u,f){u=b0(u),o.context===null?o.context=u:o.pendingContext=u,o=Sa(n),o.payload={element:a},f=f===void 0?null:f,f!==null&&(o.callback=f),a=Ma(e,o,n),a!==null&&(Zn(a,e,n),ho(a,e,n))}function T0(e,n){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var a=e.retryLane;e.retryLane=a!==0&&a<n?a:n}}function sh(e,n){T0(e,n),(e=e.alternate)&&T0(e,n)}function A0(e){if(e.tag===13||e.tag===31){var n=ss(e,67108864);n!==null&&Zn(n,e,67108864),sh(e,67108864)}}function R0(e){if(e.tag===13||e.tag===31){var n=si();n=$a(n);var a=ss(e,n);a!==null&&Zn(a,e,n),sh(e,n)}}var ac=!0;function ky(e,n,a,o){var u=z.T;z.T=null;var f=W.p;try{W.p=2,rh(e,n,a,o)}finally{W.p=f,z.T=u}}function jy(e,n,a,o){var u=z.T;z.T=null;var f=W.p;try{W.p=8,rh(e,n,a,o)}finally{W.p=f,z.T=u}}function rh(e,n,a,o){if(ac){var u=oh(o);if(u===null)Wf(e,n,o,sc,a),w0(e,o);else if(Wy(u,e,n,a,o))o.stopPropagation();else if(w0(e,o),n&4&&-1<Xy.indexOf(e)){for(;u!==null;){var f=K(u);if(f!==null)switch(f.tag){case 3:if(f=f.stateNode,f.current.memoizedState.isDehydrated){var S=Dt(f.pendingLanes);if(S!==0){var A=f;for(A.pendingLanes|=2,A.entangledLanes|=2;S;){var F=1<<31-Jt(S);A.entanglements[1]|=F,S&=~F}Pi(f),(Le&6)===0&&(Gl=dt()+500,wo(0))}}break;case 31:case 13:A=ss(f,2),A!==null&&Zn(A,f,2),kl(),sh(f,2)}if(f=oh(o),f===null&&Wf(e,n,o,sc,a),f===u)break;u=f}u!==null&&o.stopPropagation()}else Wf(e,n,o,null,a)}}function oh(e){return e=lu(e),lh(e)}var sc=null;function lh(e){if(sc=null,e=C(e),e!==null){var n=c(e);if(n===null)e=null;else{var a=n.tag;if(a===13){if(e=h(n),e!==null)return e;e=null}else if(a===31){if(e=d(n),e!==null)return e;e=null}else if(a===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;e=null}else n!==e&&(e=null)}}return sc=e,null}function C0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(St()){case mt:return 2;case Bt:return 8;case Ct:case It:return 32;case pe:return 268435456;default:return 32}default:return 32}}var ch=!1,Na=null,Oa=null,Pa=null,zo=new Map,Io=new Map,za=[],Xy="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function w0(e,n){switch(e){case"focusin":case"focusout":Na=null;break;case"dragenter":case"dragleave":Oa=null;break;case"mouseover":case"mouseout":Pa=null;break;case"pointerover":case"pointerout":zo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Io.delete(n.pointerId)}}function Bo(e,n,a,o,u,f){return e===null||e.nativeEvent!==f?(e={blockedOn:n,domEventName:a,eventSystemFlags:o,nativeEvent:f,targetContainers:[u]},n!==null&&(n=K(n),n!==null&&A0(n)),e):(e.eventSystemFlags|=o,n=e.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),e)}function Wy(e,n,a,o,u){switch(n){case"focusin":return Na=Bo(Na,e,n,a,o,u),!0;case"dragenter":return Oa=Bo(Oa,e,n,a,o,u),!0;case"mouseover":return Pa=Bo(Pa,e,n,a,o,u),!0;case"pointerover":var f=u.pointerId;return zo.set(f,Bo(zo.get(f)||null,e,n,a,o,u)),!0;case"gotpointercapture":return f=u.pointerId,Io.set(f,Bo(Io.get(f)||null,e,n,a,o,u)),!0}return!1}function D0(e){var n=C(e.target);if(n!==null){var a=c(n);if(a!==null){if(n=a.tag,n===13){if(n=h(a),n!==null){e.blockedOn=n,ts(e.priority,function(){R0(a)});return}}else if(n===31){if(n=d(a),n!==null){e.blockedOn=n,ts(e.priority,function(){R0(a)});return}}else if(n===3&&a.stateNode.current.memoizedState.isDehydrated){e.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}e.blockedOn=null}function rc(e){if(e.blockedOn!==null)return!1;for(var n=e.targetContainers;0<n.length;){var a=oh(e.nativeEvent);if(a===null){a=e.nativeEvent;var o=new a.constructor(a.type,a);ou=o,a.target.dispatchEvent(o),ou=null}else return n=K(a),n!==null&&A0(n),e.blockedOn=a,!1;n.shift()}return!0}function L0(e,n,a){rc(e)&&a.delete(n)}function qy(){ch=!1,Na!==null&&rc(Na)&&(Na=null),Oa!==null&&rc(Oa)&&(Oa=null),Pa!==null&&rc(Pa)&&(Pa=null),zo.forEach(L0),Io.forEach(L0)}function oc(e,n){e.blockedOn===n&&(e.blockedOn=null,ch||(ch=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,qy)))}var lc=null;function U0(e){lc!==e&&(lc=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){lc===e&&(lc=null);for(var n=0;n<e.length;n+=3){var a=e[n],o=e[n+1],u=e[n+2];if(typeof o!="function"){if(lh(o||a)===null)continue;break}var f=K(a);f!==null&&(e.splice(n,3),n-=3,of(f,{pending:!0,data:u,method:a.method,action:o},o,u))}}))}function hr(e){function n(F){return oc(F,e)}Na!==null&&oc(Na,e),Oa!==null&&oc(Oa,e),Pa!==null&&oc(Pa,e),zo.forEach(n),Io.forEach(n);for(var a=0;a<za.length;a++){var o=za[a];o.blockedOn===e&&(o.blockedOn=null)}for(;0<za.length&&(a=za[0],a.blockedOn===null);)D0(a),a.blockedOn===null&&za.shift();if(a=(e.ownerDocument||e).$$reactFormReplay,a!=null)for(o=0;o<a.length;o+=3){var u=a[o],f=a[o+1],S=u[bn]||null;if(typeof f=="function")S||U0(a);else if(S){var A=null;if(f&&f.hasAttribute("formAction")){if(u=f,S=f[bn]||null)A=S.formAction;else if(lh(u)!==null)continue}else A=S.action;typeof A=="function"?a[o+1]=A:(a.splice(o,3),o-=3),U0(a)}}}function N0(){function e(f){f.canIntercept&&f.info==="react-transition"&&f.intercept({handler:function(){return new Promise(function(S){return u=S})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),o||setTimeout(a,20)}function a(){if(!o&&!navigation.transition){var f=navigation.currentEntry;f&&f.url!=null&&navigation.navigate(f.url,{state:f.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,u=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(a,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function uh(e){this._internalRoot=e}cc.prototype.render=uh.prototype.render=function(e){var n=this._internalRoot;if(n===null)throw Error(s(409));var a=n.current,o=si();E0(a,o,e,n,null,null)},cc.prototype.unmount=uh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var n=e.containerInfo;E0(e.current,2,null,e,null,null),kl(),n[Gi]=null}};function cc(e){this._internalRoot=e}cc.prototype.unstable_scheduleHydration=function(e){if(e){var n=Yr();e={blockedOn:null,target:e,priority:n};for(var a=0;a<za.length&&n!==0&&n<za[a].priority;a++);za.splice(a,0,e),a===0&&D0(e)}};var O0=t.version;if(O0!=="19.2.8")throw Error(s(527,O0,"19.2.8"));W.findDOMNode=function(e){var n=e._reactInternals;if(n===void 0)throw typeof e.render=="function"?Error(s(188)):(e=Object.keys(e).join(","),Error(s(268,e)));return e=p(n),e=e!==null?g(e):null,e=e===null?null:e.stateNode,e};var Yy={bundleType:0,version:"19.2.8",rendererPackageName:"react-dom",currentDispatcherRef:z,reconcilerVersion:"19.2.8"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var uc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!uc.isDisabled&&uc.supportsFiber)try{Kt=uc.inject(Yy),jt=uc}catch{}}return Ho.createRoot=function(e,n){if(!l(e))throw Error(s(299));var a=!1,o="",u=Gm,f=Vm,S=km;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(f=n.onCaughtError),n.onRecoverableError!==void 0&&(S=n.onRecoverableError)),n=M0(e,1,!1,null,null,a,o,null,u,f,S,N0),e[Gi]=n.current,Xf(e),new uh(n)},Ho.hydrateRoot=function(e,n,a){if(!l(e))throw Error(s(299));var o=!1,u="",f=Gm,S=Vm,A=km,F=null;return a!=null&&(a.unstable_strictMode===!0&&(o=!0),a.identifierPrefix!==void 0&&(u=a.identifierPrefix),a.onUncaughtError!==void 0&&(f=a.onUncaughtError),a.onCaughtError!==void 0&&(S=a.onCaughtError),a.onRecoverableError!==void 0&&(A=a.onRecoverableError),a.formState!==void 0&&(F=a.formState)),n=M0(e,1,!0,n,a??null,o,u,F,f,S,A,N0),n.context=b0(null),a=n.current,o=si(),o=$a(o),u=Sa(o),u.callback=null,Ma(a,u,o),a=o,n.current.lanes=a,Mn(n,a),Pi(n),e[Gi]=n.current,Xf(e),new cc(n)},Ho.version="19.2.8",Ho}var j0;function sS(){if(j0)return dh.exports;j0=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),dh.exports=aS(),dh.exports}var rS=sS();const oS=$_(rS);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Fd="174",Lr={ROTATE:0,DOLLY:1,PAN:2},Cr={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},lS=0,X0=1,cS=2,tv=1,uS=2,ua=3,Ja=0,Fn=1,li=2,Za=0,Ur=1,qa=2,W0=3,q0=4,fS=5,As=100,hS=101,dS=102,pS=103,mS=104,gS=200,_S=201,vS=202,xS=203,Kh=204,Qh=205,yS=206,SS=207,MS=208,bS=209,ES=210,TS=211,AS=212,RS=213,CS=214,Jh=0,$h=1,td=2,Ir=3,ed=4,nd=5,id=6,ad=7,ev=0,wS=1,DS=2,Ka=0,LS=1,US=2,NS=3,nv=4,OS=5,PS=6,zS=7,iv=300,Br=301,Fr=302,sd=303,rd=304,$c=306,Xc=1e3,Ya=1001,od=1002,Di=1003,IS=1004,fc=1005,Ii=1006,_h=1007,Cs=1008,pa=1009,av=1010,sv=1011,Zo=1012,Hd=1013,ws=1014,fa=1015,Qo=1016,Gd=1017,Vd=1018,Hr=1020,rv=35902,ov=1021,lv=1022,wi=1023,cv=1024,uv=1025,Nr=1026,Gr=1027,fv=1028,kd=1029,hv=1030,jd=1031,Xd=1033,Bc=33776,Fc=33777,Hc=33778,Gc=33779,ld=35840,cd=35841,ud=35842,fd=35843,hd=36196,dd=37492,pd=37496,md=37808,gd=37809,_d=37810,vd=37811,xd=37812,yd=37813,Sd=37814,Md=37815,bd=37816,Ed=37817,Td=37818,Ad=37819,Rd=37820,Cd=37821,Vc=36492,wd=36494,Dd=36495,dv=36283,Ld=36284,Ud=36285,Nd=36286,BS=3200,FS=3201,pv=0,HS=1,Xa="",Bn="srgb",Vr="srgb-linear",Wc="linear",Ve="srgb",dr=7680,Y0=519,GS=512,VS=513,kS=514,mv=515,jS=516,XS=517,WS=518,qS=519,Z0=35044,K0="300 es",ha=2e3,qc=2001;class Us{addEventListener(t,i){this._listeners===void 0&&(this._listeners={});const s=this._listeners;s[t]===void 0&&(s[t]=[]),s[t].indexOf(i)===-1&&s[t].push(i)}hasEventListener(t,i){const s=this._listeners;return s===void 0?!1:s[t]!==void 0&&s[t].indexOf(i)!==-1}removeEventListener(t,i){const s=this._listeners;if(s===void 0)return;const l=s[t];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(t){const i=this._listeners;if(i===void 0)return;const s=i[t.type];if(s!==void 0){t.target=this;const l=s.slice(0);for(let c=0,h=l.length;c<h;c++)l[c].call(this,t);t.target=null}}}const Un=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],kc=Math.PI/180,Od=180/Math.PI;function Jo(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0,s=Math.random()*4294967295|0;return(Un[r&255]+Un[r>>8&255]+Un[r>>16&255]+Un[r>>24&255]+"-"+Un[t&255]+Un[t>>8&255]+"-"+Un[t>>16&15|64]+Un[t>>24&255]+"-"+Un[i&63|128]+Un[i>>8&255]+"-"+Un[i>>16&255]+Un[i>>24&255]+Un[s&255]+Un[s>>8&255]+Un[s>>16&255]+Un[s>>24&255]).toLowerCase()}function _e(r,t,i){return Math.max(t,Math.min(i,r))}function YS(r,t){return(r%t+t)%t}function vh(r,t,i){return(1-i)*r+i*t}function Go(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function Kn(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const ZS={DEG2RAD:kc};class se{constructor(t=0,i=0){se.prototype.isVector2=!0,this.x=t,this.y=i}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,i){return this.x=t,this.y=i,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const i=this.x,s=this.y,l=t.elements;return this.x=l[0]*i+l[3]*s+l[6],this.y=l[1]*i+l[4]*s+l[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,i){return this.x=_e(this.x,t.x,i.x),this.y=_e(this.y,t.y,i.y),this}clampScalar(t,i){return this.x=_e(this.x,t,i),this.y=_e(this.y,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(_e(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(t)/i;return Math.acos(_e(s,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,s=this.y-t.y;return i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this}rotateAround(t,i){const s=Math.cos(i),l=Math.sin(i),c=this.x-t.x,h=this.y-t.y;return this.x=c*s-h*l+t.x,this.y=c*l+h*s+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class ue{constructor(t,i,s,l,c,h,d,m,p){ue.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,i,s,l,c,h,d,m,p)}set(t,i,s,l,c,h,d,m,p){const g=this.elements;return g[0]=t,g[1]=l,g[2]=d,g[3]=i,g[4]=c,g[5]=m,g[6]=s,g[7]=h,g[8]=p,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const i=this.elements,s=t.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],this}extractBasis(t,i,s){return t.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),s.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const i=t.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const s=t.elements,l=i.elements,c=this.elements,h=s[0],d=s[3],m=s[6],p=s[1],g=s[4],_=s[7],y=s[2],v=s[5],b=s[8],E=l[0],M=l[3],x=l[6],P=l[1],N=l[4],w=l[7],k=l[2],H=l[5],I=l[8];return c[0]=h*E+d*P+m*k,c[3]=h*M+d*N+m*H,c[6]=h*x+d*w+m*I,c[1]=p*E+g*P+_*k,c[4]=p*M+g*N+_*H,c[7]=p*x+g*w+_*I,c[2]=y*E+v*P+b*k,c[5]=y*M+v*N+b*H,c[8]=y*x+v*w+b*I,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[3]*=t,i[6]*=t,i[1]*=t,i[4]*=t,i[7]*=t,i[2]*=t,i[5]*=t,i[8]*=t,this}determinant(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],h=t[4],d=t[5],m=t[6],p=t[7],g=t[8];return i*h*g-i*d*p-s*c*g+s*d*m+l*c*p-l*h*m}invert(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],h=t[4],d=t[5],m=t[6],p=t[7],g=t[8],_=g*h-d*p,y=d*m-g*c,v=p*c-h*m,b=i*_+s*y+l*v;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/b;return t[0]=_*E,t[1]=(l*p-g*s)*E,t[2]=(d*s-l*h)*E,t[3]=y*E,t[4]=(g*i-l*m)*E,t[5]=(l*c-d*i)*E,t[6]=v*E,t[7]=(s*m-p*i)*E,t[8]=(h*i-s*c)*E,this}transpose(){let t;const i=this.elements;return t=i[1],i[1]=i[3],i[3]=t,t=i[2],i[2]=i[6],i[6]=t,t=i[5],i[5]=i[7],i[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const i=this.elements;return t[0]=i[0],t[1]=i[3],t[2]=i[6],t[3]=i[1],t[4]=i[4],t[5]=i[7],t[6]=i[2],t[7]=i[5],t[8]=i[8],this}setUvTransform(t,i,s,l,c,h,d){const m=Math.cos(c),p=Math.sin(c);return this.set(s*m,s*p,-s*(m*h+p*d)+h+t,-l*p,l*m,-l*(-p*h+m*d)+d+i,0,0,1),this}scale(t,i){return this.premultiply(xh.makeScale(t,i)),this}rotate(t){return this.premultiply(xh.makeRotation(-t)),this}translate(t,i){return this.premultiply(xh.makeTranslation(t,i)),this}makeTranslation(t,i){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,i,0,0,1),this}makeRotation(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,-s,0,s,i,0,0,0,1),this}makeScale(t,i){return this.set(t,0,0,0,i,0,0,0,1),this}equals(t){const i=this.elements,s=t.elements;for(let l=0;l<9;l++)if(i[l]!==s[l])return!1;return!0}fromArray(t,i=0){for(let s=0;s<9;s++)this.elements[s]=t[s+i];return this}toArray(t=[],i=0){const s=this.elements;return t[i]=s[0],t[i+1]=s[1],t[i+2]=s[2],t[i+3]=s[3],t[i+4]=s[4],t[i+5]=s[5],t[i+6]=s[6],t[i+7]=s[7],t[i+8]=s[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const xh=new ue;function gv(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function Ko(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function KS(){const r=Ko("canvas");return r.style.display="block",r}const Q0={};function Es(r){r in Q0||(Q0[r]=!0,console.warn(r))}function QS(r,t,i){return new Promise(function(s,l){function c(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:l();break;case r.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:s()}}setTimeout(c,i)})}function JS(r){const t=r.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function $S(r){const t=r.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}const J0=new ue().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),$0=new ue().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function t1(){const r={enabled:!0,workingColorSpace:Vr,spaces:{},convert:function(l,c,h){return this.enabled===!1||c===h||!c||!h||(this.spaces[c].transfer===Ve&&(l.r=da(l.r),l.g=da(l.g),l.b=da(l.b)),this.spaces[c].primaries!==this.spaces[h].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[h].fromXYZ)),this.spaces[h].transfer===Ve&&(l.r=Or(l.r),l.g=Or(l.g),l.b=Or(l.b))),l},fromWorkingColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},toWorkingColorSpace:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===Xa?Wc:this.spaces[l].transfer},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,h){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[h].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace}},t=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],s=[.3127,.329];return r.define({[Vr]:{primaries:t,whitePoint:s,transfer:Wc,toXYZ:J0,fromXYZ:$0,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:Bn},outputColorSpaceConfig:{drawingBufferColorSpace:Bn}},[Bn]:{primaries:t,whitePoint:s,transfer:Ve,toXYZ:J0,fromXYZ:$0,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:Bn}}}),r}const De=t1();function da(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function Or(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let pr;class e1{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let i;if(t instanceof HTMLCanvasElement)i=t;else{pr===void 0&&(pr=Ko("canvas")),pr.width=t.width,pr.height=t.height;const s=pr.getContext("2d");t instanceof ImageData?s.putImageData(t,0,0):s.drawImage(t,0,0,t.width,t.height),i=pr}return i.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const i=Ko("canvas");i.width=t.width,i.height=t.height;const s=i.getContext("2d");s.drawImage(t,0,0,t.width,t.height);const l=s.getImageData(0,0,t.width,t.height),c=l.data;for(let h=0;h<c.length;h++)c[h]=da(c[h]/255)*255;return s.putImageData(l,0,0),i}else if(t.data){const i=t.data.slice(0);for(let s=0;s<i.length;s++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[s]=Math.floor(da(i[s]/255)*255):i[s]=da(i[s]);return{data:i,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let n1=0;class Wd{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:n1++}),this.uuid=Jo(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const s={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let h=0,d=l.length;h<d;h++)l[h].isDataTexture?c.push(yh(l[h].image)):c.push(yh(l[h]))}else c=yh(l);s.url=c}return i||(t.images[this.uuid]=s),s}}function yh(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?e1.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let i1=0;class Hn extends Us{constructor(t=Hn.DEFAULT_IMAGE,i=Hn.DEFAULT_MAPPING,s=Ya,l=Ya,c=Ii,h=Cs,d=wi,m=pa,p=Hn.DEFAULT_ANISOTROPY,g=Xa){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:i1++}),this.uuid=Jo(),this.name="",this.source=new Wd(t),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=s,this.wrapT=l,this.magFilter=c,this.minFilter=h,this.anisotropy=p,this.format=d,this.internalFormat=null,this.type=m,this.offset=new se(0,0),this.repeat=new se(1,1),this.center=new se(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ue,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const s={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(s.userData=this.userData),i||(t.textures[this.uuid]=s),s}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==iv)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Xc:t.x=t.x-Math.floor(t.x);break;case Ya:t.x=t.x<0?0:1;break;case od:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Xc:t.y=t.y-Math.floor(t.y);break;case Ya:t.y=t.y<0?0:1;break;case od:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Hn.DEFAULT_IMAGE=null;Hn.DEFAULT_MAPPING=iv;Hn.DEFAULT_ANISOTROPY=1;class an{constructor(t=0,i=0,s=0,l=1){an.prototype.isVector4=!0,this.x=t,this.y=i,this.z=s,this.w=l}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,i,s,l){return this.x=t,this.y=i,this.z=s,this.w=l,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this.w=t.w+i.w,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this.w+=t.w*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this.w=t.w-i.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const i=this.x,s=this.y,l=this.z,c=this.w,h=t.elements;return this.x=h[0]*i+h[4]*s+h[8]*l+h[12]*c,this.y=h[1]*i+h[5]*s+h[9]*l+h[13]*c,this.z=h[2]*i+h[6]*s+h[10]*l+h[14]*c,this.w=h[3]*i+h[7]*s+h[11]*l+h[15]*c,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const i=Math.sqrt(1-t.w*t.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/i,this.y=t.y/i,this.z=t.z/i),this}setAxisAngleFromRotationMatrix(t){let i,s,l,c;const m=t.elements,p=m[0],g=m[4],_=m[8],y=m[1],v=m[5],b=m[9],E=m[2],M=m[6],x=m[10];if(Math.abs(g-y)<.01&&Math.abs(_-E)<.01&&Math.abs(b-M)<.01){if(Math.abs(g+y)<.1&&Math.abs(_+E)<.1&&Math.abs(b+M)<.1&&Math.abs(p+v+x-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const N=(p+1)/2,w=(v+1)/2,k=(x+1)/2,H=(g+y)/4,I=(_+E)/4,j=(b+M)/4;return N>w&&N>k?N<.01?(s=0,l=.707106781,c=.707106781):(s=Math.sqrt(N),l=H/s,c=I/s):w>k?w<.01?(s=.707106781,l=0,c=.707106781):(l=Math.sqrt(w),s=H/l,c=j/l):k<.01?(s=.707106781,l=.707106781,c=0):(c=Math.sqrt(k),s=I/c,l=j/c),this.set(s,l,c,i),this}let P=Math.sqrt((M-b)*(M-b)+(_-E)*(_-E)+(y-g)*(y-g));return Math.abs(P)<.001&&(P=1),this.x=(M-b)/P,this.y=(_-E)/P,this.z=(y-g)/P,this.w=Math.acos((p+v+x-1)/2),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,i){return this.x=_e(this.x,t.x,i.x),this.y=_e(this.y,t.y,i.y),this.z=_e(this.z,t.z,i.z),this.w=_e(this.w,t.w,i.w),this}clampScalar(t,i){return this.x=_e(this.x,t,i),this.y=_e(this.y,t,i),this.z=_e(this.z,t,i),this.w=_e(this.w,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(_e(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this.w+=(t.w-this.w)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this.z=t.z+(i.z-t.z)*s,this.w=t.w+(i.w-t.w)*s,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this.w=t[i+3],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t[i+3]=this.w,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this.w=t.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class a1 extends Us{constructor(t=1,i=1,s={}){super(),this.isRenderTarget=!0,this.width=t,this.height=i,this.depth=1,this.scissor=new an(0,0,t,i),this.scissorTest=!1,this.viewport=new an(0,0,t,i);const l={width:t,height:i,depth:1};s=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ii,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},s);const c=new Hn(l,s.mapping,s.wrapS,s.wrapT,s.magFilter,s.minFilter,s.format,s.type,s.anisotropy,s.colorSpace);c.flipY=!1,c.generateMipmaps=s.generateMipmaps,c.internalFormat=s.internalFormat,this.textures=[];const h=s.count;for(let d=0;d<h;d++)this.textures[d]=c.clone(),this.textures[d].isRenderTargetTexture=!0,this.textures[d].renderTarget=this;this.depthBuffer=s.depthBuffer,this.stencilBuffer=s.stencilBuffer,this.resolveDepthBuffer=s.resolveDepthBuffer,this.resolveStencilBuffer=s.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=s.depthTexture,this.samples=s.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,i,s=1){if(this.width!==t||this.height!==i||this.depth!==s){this.width=t,this.height=i,this.depth=s;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=t,this.textures[l].image.height=i,this.textures[l].image.depth=s;this.dispose()}this.viewport.set(0,0,t,i),this.scissor.set(0,0,t,i)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let i=0,s=t.textures.length;i<s;i++){this.textures[i]=t.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},t.textures[i].image);this.textures[i].source=new Wd(l)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ds extends a1{constructor(t=1,i=1,s={}){super(t,i,s),this.isWebGLRenderTarget=!0}}class _v extends Hn{constructor(t=null,i=1,s=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:i,height:s,depth:l},this.magFilter=Di,this.minFilter=Di,this.wrapR=Ya,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class s1 extends Hn{constructor(t=null,i=1,s=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:i,height:s,depth:l},this.magFilter=Di,this.minFilter=Di,this.wrapR=Ya,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Ls{constructor(t=0,i=0,s=0,l=1){this.isQuaternion=!0,this._x=t,this._y=i,this._z=s,this._w=l}static slerpFlat(t,i,s,l,c,h,d){let m=s[l+0],p=s[l+1],g=s[l+2],_=s[l+3];const y=c[h+0],v=c[h+1],b=c[h+2],E=c[h+3];if(d===0){t[i+0]=m,t[i+1]=p,t[i+2]=g,t[i+3]=_;return}if(d===1){t[i+0]=y,t[i+1]=v,t[i+2]=b,t[i+3]=E;return}if(_!==E||m!==y||p!==v||g!==b){let M=1-d;const x=m*y+p*v+g*b+_*E,P=x>=0?1:-1,N=1-x*x;if(N>Number.EPSILON){const k=Math.sqrt(N),H=Math.atan2(k,x*P);M=Math.sin(M*H)/k,d=Math.sin(d*H)/k}const w=d*P;if(m=m*M+y*w,p=p*M+v*w,g=g*M+b*w,_=_*M+E*w,M===1-d){const k=1/Math.sqrt(m*m+p*p+g*g+_*_);m*=k,p*=k,g*=k,_*=k}}t[i]=m,t[i+1]=p,t[i+2]=g,t[i+3]=_}static multiplyQuaternionsFlat(t,i,s,l,c,h){const d=s[l],m=s[l+1],p=s[l+2],g=s[l+3],_=c[h],y=c[h+1],v=c[h+2],b=c[h+3];return t[i]=d*b+g*_+m*v-p*y,t[i+1]=m*b+g*y+p*_-d*v,t[i+2]=p*b+g*v+d*y-m*_,t[i+3]=g*b-d*_-m*y-p*v,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,i,s,l){return this._x=t,this._y=i,this._z=s,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,i=!0){const s=t._x,l=t._y,c=t._z,h=t._order,d=Math.cos,m=Math.sin,p=d(s/2),g=d(l/2),_=d(c/2),y=m(s/2),v=m(l/2),b=m(c/2);switch(h){case"XYZ":this._x=y*g*_+p*v*b,this._y=p*v*_-y*g*b,this._z=p*g*b+y*v*_,this._w=p*g*_-y*v*b;break;case"YXZ":this._x=y*g*_+p*v*b,this._y=p*v*_-y*g*b,this._z=p*g*b-y*v*_,this._w=p*g*_+y*v*b;break;case"ZXY":this._x=y*g*_-p*v*b,this._y=p*v*_+y*g*b,this._z=p*g*b+y*v*_,this._w=p*g*_-y*v*b;break;case"ZYX":this._x=y*g*_-p*v*b,this._y=p*v*_+y*g*b,this._z=p*g*b-y*v*_,this._w=p*g*_+y*v*b;break;case"YZX":this._x=y*g*_+p*v*b,this._y=p*v*_+y*g*b,this._z=p*g*b-y*v*_,this._w=p*g*_-y*v*b;break;case"XZY":this._x=y*g*_-p*v*b,this._y=p*v*_-y*g*b,this._z=p*g*b+y*v*_,this._w=p*g*_+y*v*b;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+h)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,i){const s=i/2,l=Math.sin(s);return this._x=t.x*l,this._y=t.y*l,this._z=t.z*l,this._w=Math.cos(s),this._onChangeCallback(),this}setFromRotationMatrix(t){const i=t.elements,s=i[0],l=i[4],c=i[8],h=i[1],d=i[5],m=i[9],p=i[2],g=i[6],_=i[10],y=s+d+_;if(y>0){const v=.5/Math.sqrt(y+1);this._w=.25/v,this._x=(g-m)*v,this._y=(c-p)*v,this._z=(h-l)*v}else if(s>d&&s>_){const v=2*Math.sqrt(1+s-d-_);this._w=(g-m)/v,this._x=.25*v,this._y=(l+h)/v,this._z=(c+p)/v}else if(d>_){const v=2*Math.sqrt(1+d-s-_);this._w=(c-p)/v,this._x=(l+h)/v,this._y=.25*v,this._z=(m+g)/v}else{const v=2*Math.sqrt(1+_-s-d);this._w=(h-l)/v,this._x=(c+p)/v,this._y=(m+g)/v,this._z=.25*v}return this._onChangeCallback(),this}setFromUnitVectors(t,i){let s=t.dot(i)+1;return s<Number.EPSILON?(s=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=s):(this._x=0,this._y=-t.z,this._z=t.y,this._w=s)):(this._x=t.y*i.z-t.z*i.y,this._y=t.z*i.x-t.x*i.z,this._z=t.x*i.y-t.y*i.x,this._w=s),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(_e(this.dot(t),-1,1)))}rotateTowards(t,i){const s=this.angleTo(t);if(s===0)return this;const l=Math.min(1,i/s);return this.slerp(t,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,i){const s=t._x,l=t._y,c=t._z,h=t._w,d=i._x,m=i._y,p=i._z,g=i._w;return this._x=s*g+h*d+l*p-c*m,this._y=l*g+h*m+c*d-s*p,this._z=c*g+h*p+s*m-l*d,this._w=h*g-s*d-l*m-c*p,this._onChangeCallback(),this}slerp(t,i){if(i===0)return this;if(i===1)return this.copy(t);const s=this._x,l=this._y,c=this._z,h=this._w;let d=h*t._w+s*t._x+l*t._y+c*t._z;if(d<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,d=-d):this.copy(t),d>=1)return this._w=h,this._x=s,this._y=l,this._z=c,this;const m=1-d*d;if(m<=Number.EPSILON){const v=1-i;return this._w=v*h+i*this._w,this._x=v*s+i*this._x,this._y=v*l+i*this._y,this._z=v*c+i*this._z,this.normalize(),this}const p=Math.sqrt(m),g=Math.atan2(p,d),_=Math.sin((1-i)*g)/p,y=Math.sin(i*g)/p;return this._w=h*_+this._w*y,this._x=s*_+this._x*y,this._y=l*_+this._y*y,this._z=c*_+this._z*y,this._onChangeCallback(),this}slerpQuaternions(t,i,s){return this.copy(t).slerp(i,s)}random(){const t=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),s=Math.random(),l=Math.sqrt(1-s),c=Math.sqrt(s);return this.set(l*Math.sin(t),l*Math.cos(t),c*Math.sin(i),c*Math.cos(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,i=0){return this._x=t[i],this._y=t[i+1],this._z=t[i+2],this._w=t[i+3],this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._w,t}fromBufferAttribute(t,i){return this._x=t.getX(i),this._y=t.getY(i),this._z=t.getZ(i),this._w=t.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class J{constructor(t=0,i=0,s=0){J.prototype.isVector3=!0,this.x=t,this.y=i,this.z=s}set(t,i,s){return s===void 0&&(s=this.z),this.x=t,this.y=i,this.z=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,i){return this.x=t.x*i.x,this.y=t.y*i.y,this.z=t.z*i.z,this}applyEuler(t){return this.applyQuaternion(t_.setFromEuler(t))}applyAxisAngle(t,i){return this.applyQuaternion(t_.setFromAxisAngle(t,i))}applyMatrix3(t){const i=this.x,s=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[3]*s+c[6]*l,this.y=c[1]*i+c[4]*s+c[7]*l,this.z=c[2]*i+c[5]*s+c[8]*l,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const i=this.x,s=this.y,l=this.z,c=t.elements,h=1/(c[3]*i+c[7]*s+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*s+c[8]*l+c[12])*h,this.y=(c[1]*i+c[5]*s+c[9]*l+c[13])*h,this.z=(c[2]*i+c[6]*s+c[10]*l+c[14])*h,this}applyQuaternion(t){const i=this.x,s=this.y,l=this.z,c=t.x,h=t.y,d=t.z,m=t.w,p=2*(h*l-d*s),g=2*(d*i-c*l),_=2*(c*s-h*i);return this.x=i+m*p+h*_-d*g,this.y=s+m*g+d*p-c*_,this.z=l+m*_+c*g-h*p,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const i=this.x,s=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[4]*s+c[8]*l,this.y=c[1]*i+c[5]*s+c[9]*l,this.z=c[2]*i+c[6]*s+c[10]*l,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,i){return this.x=_e(this.x,t.x,i.x),this.y=_e(this.y,t.y,i.y),this.z=_e(this.z,t.z,i.z),this}clampScalar(t,i){return this.x=_e(this.x,t,i),this.y=_e(this.y,t,i),this.z=_e(this.z,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(_e(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this.z=t.z+(i.z-t.z)*s,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,i){const s=t.x,l=t.y,c=t.z,h=i.x,d=i.y,m=i.z;return this.x=l*m-c*d,this.y=c*h-s*m,this.z=s*d-l*h,this}projectOnVector(t){const i=t.lengthSq();if(i===0)return this.set(0,0,0);const s=t.dot(this)/i;return this.copy(t).multiplyScalar(s)}projectOnPlane(t){return Sh.copy(this).projectOnVector(t),this.sub(Sh)}reflect(t){return this.sub(Sh.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(t)/i;return Math.acos(_e(s,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,s=this.y-t.y,l=this.z-t.z;return i*i+s*s+l*l}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,i,s){const l=Math.sin(i)*t;return this.x=l*Math.sin(s),this.y=Math.cos(i)*t,this.z=l*Math.cos(s),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,i,s){return this.x=t*Math.sin(i),this.y=s,this.z=t*Math.cos(i),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(t){const i=this.setFromMatrixColumn(t,0).length(),s=this.setFromMatrixColumn(t,1).length(),l=this.setFromMatrixColumn(t,2).length();return this.x=i,this.y=s,this.z=l,this}setFromMatrixColumn(t,i){return this.fromArray(t.elements,i*4)}setFromMatrix3Column(t,i){return this.fromArray(t.elements,i*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,i=Math.random()*2-1,s=Math.sqrt(1-i*i);return this.x=s*Math.cos(t),this.y=i,this.z=s*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Sh=new J,t_=new Ls;class $o{constructor(t=new J(1/0,1/0,1/0),i=new J(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=i}set(t,i){return this.min.copy(t),this.max.copy(i),this}setFromArray(t){this.makeEmpty();for(let i=0,s=t.length;i<s;i+=3)this.expandByPoint(Ti.fromArray(t,i));return this}setFromBufferAttribute(t){this.makeEmpty();for(let i=0,s=t.count;i<s;i++)this.expandByPoint(Ti.fromBufferAttribute(t,i));return this}setFromPoints(t){this.makeEmpty();for(let i=0,s=t.length;i<s;i++)this.expandByPoint(t[i]);return this}setFromCenterAndSize(t,i){const s=Ti.copy(i).multiplyScalar(.5);return this.min.copy(t).sub(s),this.max.copy(t).add(s),this}setFromObject(t,i=!1){return this.makeEmpty(),this.expandByObject(t,i)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,i=!1){t.updateWorldMatrix(!1,!1);const s=t.geometry;if(s!==void 0){const c=s.getAttribute("position");if(i===!0&&c!==void 0&&t.isInstancedMesh!==!0)for(let h=0,d=c.count;h<d;h++)t.isMesh===!0?t.getVertexPosition(h,Ti):Ti.fromBufferAttribute(c,h),Ti.applyMatrix4(t.matrixWorld),this.expandByPoint(Ti);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),hc.copy(t.boundingBox)):(s.boundingBox===null&&s.computeBoundingBox(),hc.copy(s.boundingBox)),hc.applyMatrix4(t.matrixWorld),this.union(hc)}const l=t.children;for(let c=0,h=l.length;c<h;c++)this.expandByObject(l[c],i);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,i){return i.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Ti),Ti.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let i,s;return t.normal.x>0?(i=t.normal.x*this.min.x,s=t.normal.x*this.max.x):(i=t.normal.x*this.max.x,s=t.normal.x*this.min.x),t.normal.y>0?(i+=t.normal.y*this.min.y,s+=t.normal.y*this.max.y):(i+=t.normal.y*this.max.y,s+=t.normal.y*this.min.y),t.normal.z>0?(i+=t.normal.z*this.min.z,s+=t.normal.z*this.max.z):(i+=t.normal.z*this.max.z,s+=t.normal.z*this.min.z),i<=-t.constant&&s>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Vo),dc.subVectors(this.max,Vo),mr.subVectors(t.a,Vo),gr.subVectors(t.b,Vo),_r.subVectors(t.c,Vo),Ba.subVectors(gr,mr),Fa.subVectors(_r,gr),vs.subVectors(mr,_r);let i=[0,-Ba.z,Ba.y,0,-Fa.z,Fa.y,0,-vs.z,vs.y,Ba.z,0,-Ba.x,Fa.z,0,-Fa.x,vs.z,0,-vs.x,-Ba.y,Ba.x,0,-Fa.y,Fa.x,0,-vs.y,vs.x,0];return!Mh(i,mr,gr,_r,dc)||(i=[1,0,0,0,1,0,0,0,1],!Mh(i,mr,gr,_r,dc))?!1:(pc.crossVectors(Ba,Fa),i=[pc.x,pc.y,pc.z],Mh(i,mr,gr,_r,dc))}clampPoint(t,i){return i.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Ti).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Ti).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(sa[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),sa[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),sa[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),sa[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),sa[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),sa[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),sa[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),sa[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(sa),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const sa=[new J,new J,new J,new J,new J,new J,new J,new J],Ti=new J,hc=new $o,mr=new J,gr=new J,_r=new J,Ba=new J,Fa=new J,vs=new J,Vo=new J,dc=new J,pc=new J,xs=new J;function Mh(r,t,i,s,l){for(let c=0,h=r.length-3;c<=h;c+=3){xs.fromArray(r,c);const d=l.x*Math.abs(xs.x)+l.y*Math.abs(xs.y)+l.z*Math.abs(xs.z),m=t.dot(xs),p=i.dot(xs),g=s.dot(xs);if(Math.max(-Math.max(m,p,g),Math.min(m,p,g))>d)return!1}return!0}const r1=new $o,ko=new J,bh=new J;class tl{constructor(t=new J,i=-1){this.isSphere=!0,this.center=t,this.radius=i}set(t,i){return this.center.copy(t),this.radius=i,this}setFromPoints(t,i){const s=this.center;i!==void 0?s.copy(i):r1.setFromPoints(t).getCenter(s);let l=0;for(let c=0,h=t.length;c<h;c++)l=Math.max(l,s.distanceToSquared(t[c]));return this.radius=Math.sqrt(l),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const i=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=i*i}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,i){const s=this.center.distanceToSquared(t);return i.copy(t),s>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ko.subVectors(t,this.center);const i=ko.lengthSq();if(i>this.radius*this.radius){const s=Math.sqrt(i),l=(s-this.radius)*.5;this.center.addScaledVector(ko,l/s),this.radius+=l}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(bh.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ko.copy(t.center).add(bh)),this.expandByPoint(ko.copy(t.center).sub(bh))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const ra=new J,Eh=new J,mc=new J,Ha=new J,Th=new J,gc=new J,Ah=new J;class tu{constructor(t=new J,i=new J(0,0,-1)){this.origin=t,this.direction=i}set(t,i){return this.origin.copy(t),this.direction.copy(i),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,i){return i.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ra)),this}closestPointToPoint(t,i){i.subVectors(t,this.origin);const s=i.dot(this.direction);return s<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,s)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const i=ra.subVectors(t,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(t):(ra.copy(this.origin).addScaledVector(this.direction,i),ra.distanceToSquared(t))}distanceSqToSegment(t,i,s,l){Eh.copy(t).add(i).multiplyScalar(.5),mc.copy(i).sub(t).normalize(),Ha.copy(this.origin).sub(Eh);const c=t.distanceTo(i)*.5,h=-this.direction.dot(mc),d=Ha.dot(this.direction),m=-Ha.dot(mc),p=Ha.lengthSq(),g=Math.abs(1-h*h);let _,y,v,b;if(g>0)if(_=h*m-d,y=h*d-m,b=c*g,_>=0)if(y>=-b)if(y<=b){const E=1/g;_*=E,y*=E,v=_*(_+h*y+2*d)+y*(h*_+y+2*m)+p}else y=c,_=Math.max(0,-(h*y+d)),v=-_*_+y*(y+2*m)+p;else y=-c,_=Math.max(0,-(h*y+d)),v=-_*_+y*(y+2*m)+p;else y<=-b?(_=Math.max(0,-(-h*c+d)),y=_>0?-c:Math.min(Math.max(-c,-m),c),v=-_*_+y*(y+2*m)+p):y<=b?(_=0,y=Math.min(Math.max(-c,-m),c),v=y*(y+2*m)+p):(_=Math.max(0,-(h*c+d)),y=_>0?c:Math.min(Math.max(-c,-m),c),v=-_*_+y*(y+2*m)+p);else y=h>0?-c:c,_=Math.max(0,-(h*y+d)),v=-_*_+y*(y+2*m)+p;return s&&s.copy(this.origin).addScaledVector(this.direction,_),l&&l.copy(Eh).addScaledVector(mc,y),v}intersectSphere(t,i){ra.subVectors(t.center,this.origin);const s=ra.dot(this.direction),l=ra.dot(ra)-s*s,c=t.radius*t.radius;if(l>c)return null;const h=Math.sqrt(c-l),d=s-h,m=s+h;return m<0?null:d<0?this.at(m,i):this.at(d,i)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const i=t.normal.dot(this.direction);if(i===0)return t.distanceToPoint(this.origin)===0?0:null;const s=-(this.origin.dot(t.normal)+t.constant)/i;return s>=0?s:null}intersectPlane(t,i){const s=this.distanceToPlane(t);return s===null?null:this.at(s,i)}intersectsPlane(t){const i=t.distanceToPoint(this.origin);return i===0||t.normal.dot(this.direction)*i<0}intersectBox(t,i){let s,l,c,h,d,m;const p=1/this.direction.x,g=1/this.direction.y,_=1/this.direction.z,y=this.origin;return p>=0?(s=(t.min.x-y.x)*p,l=(t.max.x-y.x)*p):(s=(t.max.x-y.x)*p,l=(t.min.x-y.x)*p),g>=0?(c=(t.min.y-y.y)*g,h=(t.max.y-y.y)*g):(c=(t.max.y-y.y)*g,h=(t.min.y-y.y)*g),s>h||c>l||((c>s||isNaN(s))&&(s=c),(h<l||isNaN(l))&&(l=h),_>=0?(d=(t.min.z-y.z)*_,m=(t.max.z-y.z)*_):(d=(t.max.z-y.z)*_,m=(t.min.z-y.z)*_),s>m||d>l)||((d>s||s!==s)&&(s=d),(m<l||l!==l)&&(l=m),l<0)?null:this.at(s>=0?s:l,i)}intersectsBox(t){return this.intersectBox(t,ra)!==null}intersectTriangle(t,i,s,l,c){Th.subVectors(i,t),gc.subVectors(s,t),Ah.crossVectors(Th,gc);let h=this.direction.dot(Ah),d;if(h>0){if(l)return null;d=1}else if(h<0)d=-1,h=-h;else return null;Ha.subVectors(this.origin,t);const m=d*this.direction.dot(gc.crossVectors(Ha,gc));if(m<0)return null;const p=d*this.direction.dot(Th.cross(Ha));if(p<0||m+p>h)return null;const g=-d*Ha.dot(Ah);return g<0?null:this.at(g/h,c)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ke{constructor(t,i,s,l,c,h,d,m,p,g,_,y,v,b,E,M){Ke.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,i,s,l,c,h,d,m,p,g,_,y,v,b,E,M)}set(t,i,s,l,c,h,d,m,p,g,_,y,v,b,E,M){const x=this.elements;return x[0]=t,x[4]=i,x[8]=s,x[12]=l,x[1]=c,x[5]=h,x[9]=d,x[13]=m,x[2]=p,x[6]=g,x[10]=_,x[14]=y,x[3]=v,x[7]=b,x[11]=E,x[15]=M,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ke().fromArray(this.elements)}copy(t){const i=this.elements,s=t.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],i[9]=s[9],i[10]=s[10],i[11]=s[11],i[12]=s[12],i[13]=s[13],i[14]=s[14],i[15]=s[15],this}copyPosition(t){const i=this.elements,s=t.elements;return i[12]=s[12],i[13]=s[13],i[14]=s[14],this}setFromMatrix3(t){const i=t.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(t,i,s){return t.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),s.setFromMatrixColumn(this,2),this}makeBasis(t,i,s){return this.set(t.x,i.x,s.x,0,t.y,i.y,s.y,0,t.z,i.z,s.z,0,0,0,0,1),this}extractRotation(t){const i=this.elements,s=t.elements,l=1/vr.setFromMatrixColumn(t,0).length(),c=1/vr.setFromMatrixColumn(t,1).length(),h=1/vr.setFromMatrixColumn(t,2).length();return i[0]=s[0]*l,i[1]=s[1]*l,i[2]=s[2]*l,i[3]=0,i[4]=s[4]*c,i[5]=s[5]*c,i[6]=s[6]*c,i[7]=0,i[8]=s[8]*h,i[9]=s[9]*h,i[10]=s[10]*h,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(t){const i=this.elements,s=t.x,l=t.y,c=t.z,h=Math.cos(s),d=Math.sin(s),m=Math.cos(l),p=Math.sin(l),g=Math.cos(c),_=Math.sin(c);if(t.order==="XYZ"){const y=h*g,v=h*_,b=d*g,E=d*_;i[0]=m*g,i[4]=-m*_,i[8]=p,i[1]=v+b*p,i[5]=y-E*p,i[9]=-d*m,i[2]=E-y*p,i[6]=b+v*p,i[10]=h*m}else if(t.order==="YXZ"){const y=m*g,v=m*_,b=p*g,E=p*_;i[0]=y+E*d,i[4]=b*d-v,i[8]=h*p,i[1]=h*_,i[5]=h*g,i[9]=-d,i[2]=v*d-b,i[6]=E+y*d,i[10]=h*m}else if(t.order==="ZXY"){const y=m*g,v=m*_,b=p*g,E=p*_;i[0]=y-E*d,i[4]=-h*_,i[8]=b+v*d,i[1]=v+b*d,i[5]=h*g,i[9]=E-y*d,i[2]=-h*p,i[6]=d,i[10]=h*m}else if(t.order==="ZYX"){const y=h*g,v=h*_,b=d*g,E=d*_;i[0]=m*g,i[4]=b*p-v,i[8]=y*p+E,i[1]=m*_,i[5]=E*p+y,i[9]=v*p-b,i[2]=-p,i[6]=d*m,i[10]=h*m}else if(t.order==="YZX"){const y=h*m,v=h*p,b=d*m,E=d*p;i[0]=m*g,i[4]=E-y*_,i[8]=b*_+v,i[1]=_,i[5]=h*g,i[9]=-d*g,i[2]=-p*g,i[6]=v*_+b,i[10]=y-E*_}else if(t.order==="XZY"){const y=h*m,v=h*p,b=d*m,E=d*p;i[0]=m*g,i[4]=-_,i[8]=p*g,i[1]=y*_+E,i[5]=h*g,i[9]=v*_-b,i[2]=b*_-v,i[6]=d*g,i[10]=E*_+y}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(t){return this.compose(o1,t,l1)}lookAt(t,i,s){const l=this.elements;return ri.subVectors(t,i),ri.lengthSq()===0&&(ri.z=1),ri.normalize(),Ga.crossVectors(s,ri),Ga.lengthSq()===0&&(Math.abs(s.z)===1?ri.x+=1e-4:ri.z+=1e-4,ri.normalize(),Ga.crossVectors(s,ri)),Ga.normalize(),_c.crossVectors(ri,Ga),l[0]=Ga.x,l[4]=_c.x,l[8]=ri.x,l[1]=Ga.y,l[5]=_c.y,l[9]=ri.y,l[2]=Ga.z,l[6]=_c.z,l[10]=ri.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const s=t.elements,l=i.elements,c=this.elements,h=s[0],d=s[4],m=s[8],p=s[12],g=s[1],_=s[5],y=s[9],v=s[13],b=s[2],E=s[6],M=s[10],x=s[14],P=s[3],N=s[7],w=s[11],k=s[15],H=l[0],I=l[4],j=l[8],L=l[12],R=l[1],B=l[5],tt=l[9],et=l[13],ut=l[2],ft=l[6],z=l[10],W=l[14],X=l[3],_t=l[7],Et=l[11],O=l[15];return c[0]=h*H+d*R+m*ut+p*X,c[4]=h*I+d*B+m*ft+p*_t,c[8]=h*j+d*tt+m*z+p*Et,c[12]=h*L+d*et+m*W+p*O,c[1]=g*H+_*R+y*ut+v*X,c[5]=g*I+_*B+y*ft+v*_t,c[9]=g*j+_*tt+y*z+v*Et,c[13]=g*L+_*et+y*W+v*O,c[2]=b*H+E*R+M*ut+x*X,c[6]=b*I+E*B+M*ft+x*_t,c[10]=b*j+E*tt+M*z+x*Et,c[14]=b*L+E*et+M*W+x*O,c[3]=P*H+N*R+w*ut+k*X,c[7]=P*I+N*B+w*ft+k*_t,c[11]=P*j+N*tt+w*z+k*Et,c[15]=P*L+N*et+w*W+k*O,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[4]*=t,i[8]*=t,i[12]*=t,i[1]*=t,i[5]*=t,i[9]*=t,i[13]*=t,i[2]*=t,i[6]*=t,i[10]*=t,i[14]*=t,i[3]*=t,i[7]*=t,i[11]*=t,i[15]*=t,this}determinant(){const t=this.elements,i=t[0],s=t[4],l=t[8],c=t[12],h=t[1],d=t[5],m=t[9],p=t[13],g=t[2],_=t[6],y=t[10],v=t[14],b=t[3],E=t[7],M=t[11],x=t[15];return b*(+c*m*_-l*p*_-c*d*y+s*p*y+l*d*v-s*m*v)+E*(+i*m*v-i*p*y+c*h*y-l*h*v+l*p*g-c*m*g)+M*(+i*p*_-i*d*v-c*h*_+s*h*v+c*d*g-s*p*g)+x*(-l*d*g-i*m*_+i*d*y+l*h*_-s*h*y+s*m*g)}transpose(){const t=this.elements;let i;return i=t[1],t[1]=t[4],t[4]=i,i=t[2],t[2]=t[8],t[8]=i,i=t[6],t[6]=t[9],t[9]=i,i=t[3],t[3]=t[12],t[12]=i,i=t[7],t[7]=t[13],t[13]=i,i=t[11],t[11]=t[14],t[14]=i,this}setPosition(t,i,s){const l=this.elements;return t.isVector3?(l[12]=t.x,l[13]=t.y,l[14]=t.z):(l[12]=t,l[13]=i,l[14]=s),this}invert(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],h=t[4],d=t[5],m=t[6],p=t[7],g=t[8],_=t[9],y=t[10],v=t[11],b=t[12],E=t[13],M=t[14],x=t[15],P=_*M*p-E*y*p+E*m*v-d*M*v-_*m*x+d*y*x,N=b*y*p-g*M*p-b*m*v+h*M*v+g*m*x-h*y*x,w=g*E*p-b*_*p+b*d*v-h*E*v-g*d*x+h*_*x,k=b*_*m-g*E*m-b*d*y+h*E*y+g*d*M-h*_*M,H=i*P+s*N+l*w+c*k;if(H===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const I=1/H;return t[0]=P*I,t[1]=(E*y*c-_*M*c-E*l*v+s*M*v+_*l*x-s*y*x)*I,t[2]=(d*M*c-E*m*c+E*l*p-s*M*p-d*l*x+s*m*x)*I,t[3]=(_*m*c-d*y*c-_*l*p+s*y*p+d*l*v-s*m*v)*I,t[4]=N*I,t[5]=(g*M*c-b*y*c+b*l*v-i*M*v-g*l*x+i*y*x)*I,t[6]=(b*m*c-h*M*c-b*l*p+i*M*p+h*l*x-i*m*x)*I,t[7]=(h*y*c-g*m*c+g*l*p-i*y*p-h*l*v+i*m*v)*I,t[8]=w*I,t[9]=(b*_*c-g*E*c-b*s*v+i*E*v+g*s*x-i*_*x)*I,t[10]=(h*E*c-b*d*c+b*s*p-i*E*p-h*s*x+i*d*x)*I,t[11]=(g*d*c-h*_*c-g*s*p+i*_*p+h*s*v-i*d*v)*I,t[12]=k*I,t[13]=(g*E*l-b*_*l+b*s*y-i*E*y-g*s*M+i*_*M)*I,t[14]=(b*d*l-h*E*l-b*s*m+i*E*m+h*s*M-i*d*M)*I,t[15]=(h*_*l-g*d*l+g*s*m-i*_*m-h*s*y+i*d*y)*I,this}scale(t){const i=this.elements,s=t.x,l=t.y,c=t.z;return i[0]*=s,i[4]*=l,i[8]*=c,i[1]*=s,i[5]*=l,i[9]*=c,i[2]*=s,i[6]*=l,i[10]*=c,i[3]*=s,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const t=this.elements,i=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],s=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],l=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(i,s,l))}makeTranslation(t,i,s){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,i,0,0,1,s,0,0,0,1),this}makeRotationX(t){const i=Math.cos(t),s=Math.sin(t);return this.set(1,0,0,0,0,i,-s,0,0,s,i,0,0,0,0,1),this}makeRotationY(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,0,s,0,0,1,0,0,-s,0,i,0,0,0,0,1),this}makeRotationZ(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,-s,0,0,s,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,i){const s=Math.cos(i),l=Math.sin(i),c=1-s,h=t.x,d=t.y,m=t.z,p=c*h,g=c*d;return this.set(p*h+s,p*d-l*m,p*m+l*d,0,p*d+l*m,g*d+s,g*m-l*h,0,p*m-l*d,g*m+l*h,c*m*m+s,0,0,0,0,1),this}makeScale(t,i,s){return this.set(t,0,0,0,0,i,0,0,0,0,s,0,0,0,0,1),this}makeShear(t,i,s,l,c,h){return this.set(1,s,c,0,t,1,h,0,i,l,1,0,0,0,0,1),this}compose(t,i,s){const l=this.elements,c=i._x,h=i._y,d=i._z,m=i._w,p=c+c,g=h+h,_=d+d,y=c*p,v=c*g,b=c*_,E=h*g,M=h*_,x=d*_,P=m*p,N=m*g,w=m*_,k=s.x,H=s.y,I=s.z;return l[0]=(1-(E+x))*k,l[1]=(v+w)*k,l[2]=(b-N)*k,l[3]=0,l[4]=(v-w)*H,l[5]=(1-(y+x))*H,l[6]=(M+P)*H,l[7]=0,l[8]=(b+N)*I,l[9]=(M-P)*I,l[10]=(1-(y+E))*I,l[11]=0,l[12]=t.x,l[13]=t.y,l[14]=t.z,l[15]=1,this}decompose(t,i,s){const l=this.elements;let c=vr.set(l[0],l[1],l[2]).length();const h=vr.set(l[4],l[5],l[6]).length(),d=vr.set(l[8],l[9],l[10]).length();this.determinant()<0&&(c=-c),t.x=l[12],t.y=l[13],t.z=l[14],Ai.copy(this);const p=1/c,g=1/h,_=1/d;return Ai.elements[0]*=p,Ai.elements[1]*=p,Ai.elements[2]*=p,Ai.elements[4]*=g,Ai.elements[5]*=g,Ai.elements[6]*=g,Ai.elements[8]*=_,Ai.elements[9]*=_,Ai.elements[10]*=_,i.setFromRotationMatrix(Ai),s.x=c,s.y=h,s.z=d,this}makePerspective(t,i,s,l,c,h,d=ha){const m=this.elements,p=2*c/(i-t),g=2*c/(s-l),_=(i+t)/(i-t),y=(s+l)/(s-l);let v,b;if(d===ha)v=-(h+c)/(h-c),b=-2*h*c/(h-c);else if(d===qc)v=-h/(h-c),b=-h*c/(h-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+d);return m[0]=p,m[4]=0,m[8]=_,m[12]=0,m[1]=0,m[5]=g,m[9]=y,m[13]=0,m[2]=0,m[6]=0,m[10]=v,m[14]=b,m[3]=0,m[7]=0,m[11]=-1,m[15]=0,this}makeOrthographic(t,i,s,l,c,h,d=ha){const m=this.elements,p=1/(i-t),g=1/(s-l),_=1/(h-c),y=(i+t)*p,v=(s+l)*g;let b,E;if(d===ha)b=(h+c)*_,E=-2*_;else if(d===qc)b=c*_,E=-1*_;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+d);return m[0]=2*p,m[4]=0,m[8]=0,m[12]=-y,m[1]=0,m[5]=2*g,m[9]=0,m[13]=-v,m[2]=0,m[6]=0,m[10]=E,m[14]=-b,m[3]=0,m[7]=0,m[11]=0,m[15]=1,this}equals(t){const i=this.elements,s=t.elements;for(let l=0;l<16;l++)if(i[l]!==s[l])return!1;return!0}fromArray(t,i=0){for(let s=0;s<16;s++)this.elements[s]=t[s+i];return this}toArray(t=[],i=0){const s=this.elements;return t[i]=s[0],t[i+1]=s[1],t[i+2]=s[2],t[i+3]=s[3],t[i+4]=s[4],t[i+5]=s[5],t[i+6]=s[6],t[i+7]=s[7],t[i+8]=s[8],t[i+9]=s[9],t[i+10]=s[10],t[i+11]=s[11],t[i+12]=s[12],t[i+13]=s[13],t[i+14]=s[14],t[i+15]=s[15],t}}const vr=new J,Ai=new Ke,o1=new J(0,0,0),l1=new J(1,1,1),Ga=new J,_c=new J,ri=new J,e_=new Ke,n_=new Ls;class Fi{constructor(t=0,i=0,s=0,l=Fi.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=i,this._z=s,this._order=l}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,i,s,l=this._order){return this._x=t,this._y=i,this._z=s,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,i=this._order,s=!0){const l=t.elements,c=l[0],h=l[4],d=l[8],m=l[1],p=l[5],g=l[9],_=l[2],y=l[6],v=l[10];switch(i){case"XYZ":this._y=Math.asin(_e(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-g,v),this._z=Math.atan2(-h,c)):(this._x=Math.atan2(y,p),this._z=0);break;case"YXZ":this._x=Math.asin(-_e(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(d,v),this._z=Math.atan2(m,p)):(this._y=Math.atan2(-_,c),this._z=0);break;case"ZXY":this._x=Math.asin(_e(y,-1,1)),Math.abs(y)<.9999999?(this._y=Math.atan2(-_,v),this._z=Math.atan2(-h,p)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-_e(_,-1,1)),Math.abs(_)<.9999999?(this._x=Math.atan2(y,v),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-h,p));break;case"YZX":this._z=Math.asin(_e(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-g,p),this._y=Math.atan2(-_,c)):(this._x=0,this._y=Math.atan2(d,v));break;case"XZY":this._z=Math.asin(-_e(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(y,p),this._y=Math.atan2(d,c)):(this._x=Math.atan2(-g,v),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,s===!0&&this._onChangeCallback(),this}setFromQuaternion(t,i,s){return e_.makeRotationFromQuaternion(t),this.setFromRotationMatrix(e_,i,s)}setFromVector3(t,i=this._order){return this.set(t.x,t.y,t.z,i)}reorder(t){return n_.setFromEuler(this),this.setFromQuaternion(n_,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Fi.DEFAULT_ORDER="XYZ";let vv=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},c1=0;const i_=new J,xr=new Ls,oa=new Ke,vc=new J,jo=new J,u1=new J,f1=new Ls,a_=new J(1,0,0),s_=new J(0,1,0),r_=new J(0,0,1),o_={type:"added"},h1={type:"removed"},yr={type:"childadded",child:null},Rh={type:"childremoved",child:null};class gn extends Us{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:c1++}),this.uuid=Jo(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=gn.DEFAULT_UP.clone();const t=new J,i=new Fi,s=new Ls,l=new J(1,1,1);function c(){s.setFromEuler(i,!1)}function h(){i.setFromQuaternion(s,void 0,!1)}i._onChange(c),s._onChange(h),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:s},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new Ke},normalMatrix:{value:new ue}}),this.matrix=new Ke,this.matrixWorld=new Ke,this.matrixAutoUpdate=gn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=gn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new vv,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,i){this.quaternion.setFromAxisAngle(t,i)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,i){return xr.setFromAxisAngle(t,i),this.quaternion.multiply(xr),this}rotateOnWorldAxis(t,i){return xr.setFromAxisAngle(t,i),this.quaternion.premultiply(xr),this}rotateX(t){return this.rotateOnAxis(a_,t)}rotateY(t){return this.rotateOnAxis(s_,t)}rotateZ(t){return this.rotateOnAxis(r_,t)}translateOnAxis(t,i){return i_.copy(t).applyQuaternion(this.quaternion),this.position.add(i_.multiplyScalar(i)),this}translateX(t){return this.translateOnAxis(a_,t)}translateY(t){return this.translateOnAxis(s_,t)}translateZ(t){return this.translateOnAxis(r_,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(oa.copy(this.matrixWorld).invert())}lookAt(t,i,s){t.isVector3?vc.copy(t):vc.set(t,i,s);const l=this.parent;this.updateWorldMatrix(!0,!1),jo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?oa.lookAt(jo,vc,this.up):oa.lookAt(vc,jo,this.up),this.quaternion.setFromRotationMatrix(oa),l&&(oa.extractRotation(l.matrixWorld),xr.setFromRotationMatrix(oa),this.quaternion.premultiply(xr.invert()))}add(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(o_),yr.child=t,this.dispatchEvent(yr),yr.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let s=0;s<arguments.length;s++)this.remove(arguments[s]);return this}const i=this.children.indexOf(t);return i!==-1&&(t.parent=null,this.children.splice(i,1),t.dispatchEvent(h1),Rh.child=t,this.dispatchEvent(Rh),Rh.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),oa.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),oa.multiply(t.parent.matrixWorld)),t.applyMatrix4(oa),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(o_),yr.child=t,this.dispatchEvent(yr),yr.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,i){if(this[t]===i)return this;for(let s=0,l=this.children.length;s<l;s++){const h=this.children[s].getObjectByProperty(t,i);if(h!==void 0)return h}}getObjectsByProperty(t,i,s=[]){this[t]===i&&s.push(this);const l=this.children;for(let c=0,h=l.length;c<h;c++)l[c].getObjectsByProperty(t,i,s);return s}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jo,t,u1),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jo,f1,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return t.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(t){t(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverseVisible(t)}traverseAncestors(t){const i=this.parent;i!==null&&(t(i),i.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].updateMatrixWorld(t)}updateWorldMatrix(t,i){const s=this.parent;if(t===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),i===!0){const l=this.children;for(let c=0,h=l.length;c<h;c++)l[c].updateWorldMatrix(!1,!0)}}toJSON(t){const i=t===void 0||typeof t=="string",s={};i&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},s.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.visibility=this._visibility,l.active=this._active,l.bounds=this._bounds.map(d=>({boxInitialized:d.boxInitialized,boxMin:d.box.min.toArray(),boxMax:d.box.max.toArray(),sphereInitialized:d.sphereInitialized,sphereRadius:d.sphere.radius,sphereCenter:d.sphere.center.toArray()})),l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.geometryCount=this._geometryCount,l.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(l.boundingSphere={center:l.boundingSphere.center.toArray(),radius:l.boundingSphere.radius}),this.boundingBox!==null&&(l.boundingBox={min:l.boundingBox.min.toArray(),max:l.boundingBox.max.toArray()}));function c(d,m){return d[m.uuid]===void 0&&(d[m.uuid]=m.toJSON(t)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(t.geometries,this.geometry);const d=this.geometry.parameters;if(d!==void 0&&d.shapes!==void 0){const m=d.shapes;if(Array.isArray(m))for(let p=0,g=m.length;p<g;p++){const _=m[p];c(t.shapes,_)}else c(t.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(t.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const d=[];for(let m=0,p=this.material.length;m<p;m++)d.push(c(t.materials,this.material[m]));l.material=d}else l.material=c(t.materials,this.material);if(this.children.length>0){l.children=[];for(let d=0;d<this.children.length;d++)l.children.push(this.children[d].toJSON(t).object)}if(this.animations.length>0){l.animations=[];for(let d=0;d<this.animations.length;d++){const m=this.animations[d];l.animations.push(c(t.animations,m))}}if(i){const d=h(t.geometries),m=h(t.materials),p=h(t.textures),g=h(t.images),_=h(t.shapes),y=h(t.skeletons),v=h(t.animations),b=h(t.nodes);d.length>0&&(s.geometries=d),m.length>0&&(s.materials=m),p.length>0&&(s.textures=p),g.length>0&&(s.images=g),_.length>0&&(s.shapes=_),y.length>0&&(s.skeletons=y),v.length>0&&(s.animations=v),b.length>0&&(s.nodes=b)}return s.object=l,s;function h(d){const m=[];for(const p in d){const g=d[p];delete g.metadata,m.push(g)}return m}}clone(t){return new this.constructor().copy(this,t)}copy(t,i=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),i===!0)for(let s=0;s<t.children.length;s++){const l=t.children[s];this.add(l.clone())}return this}}gn.DEFAULT_UP=new J(0,1,0);gn.DEFAULT_MATRIX_AUTO_UPDATE=!0;gn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Ri=new J,la=new J,Ch=new J,ca=new J,Sr=new J,Mr=new J,l_=new J,wh=new J,Dh=new J,Lh=new J,Uh=new an,Nh=new an,Oh=new an;class Ci{constructor(t=new J,i=new J,s=new J){this.a=t,this.b=i,this.c=s}static getNormal(t,i,s,l){l.subVectors(s,i),Ri.subVectors(t,i),l.cross(Ri);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(t,i,s,l,c){Ri.subVectors(l,i),la.subVectors(s,i),Ch.subVectors(t,i);const h=Ri.dot(Ri),d=Ri.dot(la),m=Ri.dot(Ch),p=la.dot(la),g=la.dot(Ch),_=h*p-d*d;if(_===0)return c.set(0,0,0),null;const y=1/_,v=(p*m-d*g)*y,b=(h*g-d*m)*y;return c.set(1-v-b,b,v)}static containsPoint(t,i,s,l){return this.getBarycoord(t,i,s,l,ca)===null?!1:ca.x>=0&&ca.y>=0&&ca.x+ca.y<=1}static getInterpolation(t,i,s,l,c,h,d,m){return this.getBarycoord(t,i,s,l,ca)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,ca.x),m.addScaledVector(h,ca.y),m.addScaledVector(d,ca.z),m)}static getInterpolatedAttribute(t,i,s,l,c,h){return Uh.setScalar(0),Nh.setScalar(0),Oh.setScalar(0),Uh.fromBufferAttribute(t,i),Nh.fromBufferAttribute(t,s),Oh.fromBufferAttribute(t,l),h.setScalar(0),h.addScaledVector(Uh,c.x),h.addScaledVector(Nh,c.y),h.addScaledVector(Oh,c.z),h}static isFrontFacing(t,i,s,l){return Ri.subVectors(s,i),la.subVectors(t,i),Ri.cross(la).dot(l)<0}set(t,i,s){return this.a.copy(t),this.b.copy(i),this.c.copy(s),this}setFromPointsAndIndices(t,i,s,l){return this.a.copy(t[i]),this.b.copy(t[s]),this.c.copy(t[l]),this}setFromAttributeAndIndices(t,i,s,l){return this.a.fromBufferAttribute(t,i),this.b.fromBufferAttribute(t,s),this.c.fromBufferAttribute(t,l),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Ri.subVectors(this.c,this.b),la.subVectors(this.a,this.b),Ri.cross(la).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ci.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,i){return Ci.getBarycoord(t,this.a,this.b,this.c,i)}getInterpolation(t,i,s,l,c){return Ci.getInterpolation(t,this.a,this.b,this.c,i,s,l,c)}containsPoint(t){return Ci.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ci.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,i){const s=this.a,l=this.b,c=this.c;let h,d;Sr.subVectors(l,s),Mr.subVectors(c,s),wh.subVectors(t,s);const m=Sr.dot(wh),p=Mr.dot(wh);if(m<=0&&p<=0)return i.copy(s);Dh.subVectors(t,l);const g=Sr.dot(Dh),_=Mr.dot(Dh);if(g>=0&&_<=g)return i.copy(l);const y=m*_-g*p;if(y<=0&&m>=0&&g<=0)return h=m/(m-g),i.copy(s).addScaledVector(Sr,h);Lh.subVectors(t,c);const v=Sr.dot(Lh),b=Mr.dot(Lh);if(b>=0&&v<=b)return i.copy(c);const E=v*p-m*b;if(E<=0&&p>=0&&b<=0)return d=p/(p-b),i.copy(s).addScaledVector(Mr,d);const M=g*b-v*_;if(M<=0&&_-g>=0&&v-b>=0)return l_.subVectors(c,l),d=(_-g)/(_-g+(v-b)),i.copy(l).addScaledVector(l_,d);const x=1/(M+E+y);return h=E*x,d=y*x,i.copy(s).addScaledVector(Sr,h).addScaledVector(Mr,d)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const xv={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Va={h:0,s:0,l:0},xc={h:0,s:0,l:0};function Ph(r,t,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?r+(t-r)*6*i:i<1/2?t:i<2/3?r+(t-r)*6*(2/3-i):r}class be{constructor(t,i,s){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,i,s)}set(t,i,s){if(i===void 0&&s===void 0){const l=t;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(t,i,s);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,i=Bn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,De.toWorkingColorSpace(this,i),this}setRGB(t,i,s,l=De.workingColorSpace){return this.r=t,this.g=i,this.b=s,De.toWorkingColorSpace(this,l),this}setHSL(t,i,s,l=De.workingColorSpace){if(t=YS(t,1),i=_e(i,0,1),s=_e(s,0,1),i===0)this.r=this.g=this.b=s;else{const c=s<=.5?s*(1+i):s+i-s*i,h=2*s-c;this.r=Ph(h,c,t+1/3),this.g=Ph(h,c,t),this.b=Ph(h,c,t-1/3)}return De.toWorkingColorSpace(this,l),this}setStyle(t,i=Bn){function s(c){c!==void 0&&parseFloat(c)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(t)){let c;const h=l[1],d=l[2];switch(h){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return s(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return s(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return s(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(t)){const c=l[1],h=c.length;if(h===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(h===6)return this.setHex(parseInt(c,16),i);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,i);return this}setColorName(t,i=Bn){const s=xv[t.toLowerCase()];return s!==void 0?this.setHex(s,i):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=da(t.r),this.g=da(t.g),this.b=da(t.b),this}copyLinearToSRGB(t){return this.r=Or(t.r),this.g=Or(t.g),this.b=Or(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Bn){return De.fromWorkingColorSpace(Nn.copy(this),t),Math.round(_e(Nn.r*255,0,255))*65536+Math.round(_e(Nn.g*255,0,255))*256+Math.round(_e(Nn.b*255,0,255))}getHexString(t=Bn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,i=De.workingColorSpace){De.fromWorkingColorSpace(Nn.copy(this),i);const s=Nn.r,l=Nn.g,c=Nn.b,h=Math.max(s,l,c),d=Math.min(s,l,c);let m,p;const g=(d+h)/2;if(d===h)m=0,p=0;else{const _=h-d;switch(p=g<=.5?_/(h+d):_/(2-h-d),h){case s:m=(l-c)/_+(l<c?6:0);break;case l:m=(c-s)/_+2;break;case c:m=(s-l)/_+4;break}m/=6}return t.h=m,t.s=p,t.l=g,t}getRGB(t,i=De.workingColorSpace){return De.fromWorkingColorSpace(Nn.copy(this),i),t.r=Nn.r,t.g=Nn.g,t.b=Nn.b,t}getStyle(t=Bn){De.fromWorkingColorSpace(Nn.copy(this),t);const i=Nn.r,s=Nn.g,l=Nn.b;return t!==Bn?`color(${t} ${i.toFixed(3)} ${s.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(s*255)},${Math.round(l*255)})`}offsetHSL(t,i,s){return this.getHSL(Va),this.setHSL(Va.h+t,Va.s+i,Va.l+s)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,i){return this.r=t.r+i.r,this.g=t.g+i.g,this.b=t.b+i.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,i){return this.r+=(t.r-this.r)*i,this.g+=(t.g-this.g)*i,this.b+=(t.b-this.b)*i,this}lerpColors(t,i,s){return this.r=t.r+(i.r-t.r)*s,this.g=t.g+(i.g-t.g)*s,this.b=t.b+(i.b-t.b)*s,this}lerpHSL(t,i){this.getHSL(Va),t.getHSL(xc);const s=vh(Va.h,xc.h,i),l=vh(Va.s,xc.s,i),c=vh(Va.l,xc.l,i);return this.setHSL(s,l,c),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const i=this.r,s=this.g,l=this.b,c=t.elements;return this.r=c[0]*i+c[3]*s+c[6]*l,this.g=c[1]*i+c[4]*s+c[7]*l,this.b=c[2]*i+c[5]*s+c[8]*l,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,i=0){return this.r=t[i],this.g=t[i+1],this.b=t[i+2],this}toArray(t=[],i=0){return t[i]=this.r,t[i+1]=this.g,t[i+2]=this.b,t}fromBufferAttribute(t,i){return this.r=t.getX(i),this.g=t.getY(i),this.b=t.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Nn=new be;be.NAMES=xv;let d1=0;class Ns extends Us{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:d1++}),this.uuid=Jo(),this.name="",this.type="Material",this.blending=Ur,this.side=Ja,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Kh,this.blendDst=Qh,this.blendEquation=As,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new be(0,0,0),this.blendAlpha=0,this.depthFunc=Ir,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Y0,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=dr,this.stencilZFail=dr,this.stencilZPass=dr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const i in t){const s=t[i];if(s===void 0){console.warn(`THREE.Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){console.warn(`THREE.Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(s):l&&l.isVector3&&s&&s.isVector3?l.copy(s):this[i]=s}}toJSON(t){const i=t===void 0||typeof t=="string";i&&(t={textures:{},images:{}});const s={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.color&&this.color.isColor&&(s.color=this.color.getHex()),this.roughness!==void 0&&(s.roughness=this.roughness),this.metalness!==void 0&&(s.metalness=this.metalness),this.sheen!==void 0&&(s.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(s.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(s.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(s.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(s.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(s.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(s.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(s.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(s.shininess=this.shininess),this.clearcoat!==void 0&&(s.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(s.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(s.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(s.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(s.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,s.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(s.dispersion=this.dispersion),this.iridescence!==void 0&&(s.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(s.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(s.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(s.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(s.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(s.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(s.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(s.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(s.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(s.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(s.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(s.lightMap=this.lightMap.toJSON(t).uuid,s.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(s.aoMap=this.aoMap.toJSON(t).uuid,s.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(s.bumpMap=this.bumpMap.toJSON(t).uuid,s.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(s.normalMap=this.normalMap.toJSON(t).uuid,s.normalMapType=this.normalMapType,s.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(s.displacementMap=this.displacementMap.toJSON(t).uuid,s.displacementScale=this.displacementScale,s.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(s.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(s.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(s.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(s.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(s.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(s.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(s.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(s.combine=this.combine)),this.envMapRotation!==void 0&&(s.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(s.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(s.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(s.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(s.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(s.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(s.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(s.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(s.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(s.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(s.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(s.size=this.size),this.shadowSide!==null&&(s.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(s.sizeAttenuation=this.sizeAttenuation),this.blending!==Ur&&(s.blending=this.blending),this.side!==Ja&&(s.side=this.side),this.vertexColors===!0&&(s.vertexColors=!0),this.opacity<1&&(s.opacity=this.opacity),this.transparent===!0&&(s.transparent=!0),this.blendSrc!==Kh&&(s.blendSrc=this.blendSrc),this.blendDst!==Qh&&(s.blendDst=this.blendDst),this.blendEquation!==As&&(s.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(s.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(s.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(s.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(s.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(s.blendAlpha=this.blendAlpha),this.depthFunc!==Ir&&(s.depthFunc=this.depthFunc),this.depthTest===!1&&(s.depthTest=this.depthTest),this.depthWrite===!1&&(s.depthWrite=this.depthWrite),this.colorWrite===!1&&(s.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(s.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Y0&&(s.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(s.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(s.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==dr&&(s.stencilFail=this.stencilFail),this.stencilZFail!==dr&&(s.stencilZFail=this.stencilZFail),this.stencilZPass!==dr&&(s.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(s.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(s.rotation=this.rotation),this.polygonOffset===!0&&(s.polygonOffset=!0),this.polygonOffsetFactor!==0&&(s.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(s.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(s.linewidth=this.linewidth),this.dashSize!==void 0&&(s.dashSize=this.dashSize),this.gapSize!==void 0&&(s.gapSize=this.gapSize),this.scale!==void 0&&(s.scale=this.scale),this.dithering===!0&&(s.dithering=!0),this.alphaTest>0&&(s.alphaTest=this.alphaTest),this.alphaHash===!0&&(s.alphaHash=!0),this.alphaToCoverage===!0&&(s.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(s.premultipliedAlpha=!0),this.forceSinglePass===!0&&(s.forceSinglePass=!0),this.wireframe===!0&&(s.wireframe=!0),this.wireframeLinewidth>1&&(s.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(s.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(s.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(s.flatShading=!0),this.visible===!1&&(s.visible=!1),this.toneMapped===!1&&(s.toneMapped=!1),this.fog===!1&&(s.fog=!1),Object.keys(this.userData).length>0&&(s.userData=this.userData);function l(c){const h=[];for(const d in c){const m=c[d];delete m.metadata,h.push(m)}return h}if(i){const c=l(t.textures),h=l(t.images);c.length>0&&(s.textures=c),h.length>0&&(s.images=h)}return s}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const i=t.clippingPlanes;let s=null;if(i!==null){const l=i.length;s=new Array(l);for(let c=0;c!==l;++c)s[c]=i[c].clone()}return this.clippingPlanes=s,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class Yc extends Ns{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new be(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Fi,this.combine=ev,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const fn=new J,yc=new se;let p1=0;class Jn{constructor(t,i,s=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:p1++}),this.name="",this.array=t,this.itemSize=i,this.count=t!==void 0?t.length/i:0,this.normalized=s,this.usage=Z0,this.updateRanges=[],this.gpuType=fa,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,i){this.updateRanges.push({start:t,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,i,s){t*=this.itemSize,s*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[t+l]=i.array[s+l];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let i=0,s=this.count;i<s;i++)yc.fromBufferAttribute(this,i),yc.applyMatrix3(t),this.setXY(i,yc.x,yc.y);else if(this.itemSize===3)for(let i=0,s=this.count;i<s;i++)fn.fromBufferAttribute(this,i),fn.applyMatrix3(t),this.setXYZ(i,fn.x,fn.y,fn.z);return this}applyMatrix4(t){for(let i=0,s=this.count;i<s;i++)fn.fromBufferAttribute(this,i),fn.applyMatrix4(t),this.setXYZ(i,fn.x,fn.y,fn.z);return this}applyNormalMatrix(t){for(let i=0,s=this.count;i<s;i++)fn.fromBufferAttribute(this,i),fn.applyNormalMatrix(t),this.setXYZ(i,fn.x,fn.y,fn.z);return this}transformDirection(t){for(let i=0,s=this.count;i<s;i++)fn.fromBufferAttribute(this,i),fn.transformDirection(t),this.setXYZ(i,fn.x,fn.y,fn.z);return this}set(t,i=0){return this.array.set(t,i),this}getComponent(t,i){let s=this.array[t*this.itemSize+i];return this.normalized&&(s=Go(s,this.array)),s}setComponent(t,i,s){return this.normalized&&(s=Kn(s,this.array)),this.array[t*this.itemSize+i]=s,this}getX(t){let i=this.array[t*this.itemSize];return this.normalized&&(i=Go(i,this.array)),i}setX(t,i){return this.normalized&&(i=Kn(i,this.array)),this.array[t*this.itemSize]=i,this}getY(t){let i=this.array[t*this.itemSize+1];return this.normalized&&(i=Go(i,this.array)),i}setY(t,i){return this.normalized&&(i=Kn(i,this.array)),this.array[t*this.itemSize+1]=i,this}getZ(t){let i=this.array[t*this.itemSize+2];return this.normalized&&(i=Go(i,this.array)),i}setZ(t,i){return this.normalized&&(i=Kn(i,this.array)),this.array[t*this.itemSize+2]=i,this}getW(t){let i=this.array[t*this.itemSize+3];return this.normalized&&(i=Go(i,this.array)),i}setW(t,i){return this.normalized&&(i=Kn(i,this.array)),this.array[t*this.itemSize+3]=i,this}setXY(t,i,s){return t*=this.itemSize,this.normalized&&(i=Kn(i,this.array),s=Kn(s,this.array)),this.array[t+0]=i,this.array[t+1]=s,this}setXYZ(t,i,s,l){return t*=this.itemSize,this.normalized&&(i=Kn(i,this.array),s=Kn(s,this.array),l=Kn(l,this.array)),this.array[t+0]=i,this.array[t+1]=s,this.array[t+2]=l,this}setXYZW(t,i,s,l,c){return t*=this.itemSize,this.normalized&&(i=Kn(i,this.array),s=Kn(s,this.array),l=Kn(l,this.array),c=Kn(c,this.array)),this.array[t+0]=i,this.array[t+1]=s,this.array[t+2]=l,this.array[t+3]=c,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Z0&&(t.usage=this.usage),t}}class yv extends Jn{constructor(t,i,s){super(new Uint16Array(t),i,s)}}class Sv extends Jn{constructor(t,i,s){super(new Uint32Array(t),i,s)}}class wn extends Jn{constructor(t,i,s){super(new Float32Array(t),i,s)}}let m1=0;const _i=new Ke,zh=new gn,br=new J,oi=new $o,Xo=new $o,Sn=new J;class Gn extends Us{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:m1++}),this.uuid=Jo(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(gv(t)?Sv:yv)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,i){return this.attributes[t]=i,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,i,s=0){this.groups.push({start:t,count:i,materialIndex:s})}clearGroups(){this.groups=[]}setDrawRange(t,i){this.drawRange.start=t,this.drawRange.count=i}applyMatrix4(t){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(t),i.needsUpdate=!0);const s=this.attributes.normal;if(s!==void 0){const c=new ue().getNormalMatrix(t);s.applyNormalMatrix(c),s.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(t),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return _i.makeRotationFromQuaternion(t),this.applyMatrix4(_i),this}rotateX(t){return _i.makeRotationX(t),this.applyMatrix4(_i),this}rotateY(t){return _i.makeRotationY(t),this.applyMatrix4(_i),this}rotateZ(t){return _i.makeRotationZ(t),this.applyMatrix4(_i),this}translate(t,i,s){return _i.makeTranslation(t,i,s),this.applyMatrix4(_i),this}scale(t,i,s){return _i.makeScale(t,i,s),this.applyMatrix4(_i),this}lookAt(t){return zh.lookAt(t),zh.updateMatrix(),this.applyMatrix4(zh.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(br).negate(),this.translate(br.x,br.y,br.z),this}setFromPoints(t){const i=this.getAttribute("position");if(i===void 0){const s=[];for(let l=0,c=t.length;l<c;l++){const h=t[l];s.push(h.x,h.y,h.z||0)}this.setAttribute("position",new wn(s,3))}else{const s=Math.min(t.length,i.count);for(let l=0;l<s;l++){const c=t[l];i.setXYZ(l,c.x,c.y,c.z||0)}t.length>i.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new $o);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new J(-1/0,-1/0,-1/0),new J(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),i)for(let s=0,l=i.length;s<l;s++){const c=i[s];oi.setFromBufferAttribute(c),this.morphTargetsRelative?(Sn.addVectors(this.boundingBox.min,oi.min),this.boundingBox.expandByPoint(Sn),Sn.addVectors(this.boundingBox.max,oi.max),this.boundingBox.expandByPoint(Sn)):(this.boundingBox.expandByPoint(oi.min),this.boundingBox.expandByPoint(oi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new tl);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new J,1/0);return}if(t){const s=this.boundingSphere.center;if(oi.setFromBufferAttribute(t),i)for(let c=0,h=i.length;c<h;c++){const d=i[c];Xo.setFromBufferAttribute(d),this.morphTargetsRelative?(Sn.addVectors(oi.min,Xo.min),oi.expandByPoint(Sn),Sn.addVectors(oi.max,Xo.max),oi.expandByPoint(Sn)):(oi.expandByPoint(Xo.min),oi.expandByPoint(Xo.max))}oi.getCenter(s);let l=0;for(let c=0,h=t.count;c<h;c++)Sn.fromBufferAttribute(t,c),l=Math.max(l,s.distanceToSquared(Sn));if(i)for(let c=0,h=i.length;c<h;c++){const d=i[c],m=this.morphTargetsRelative;for(let p=0,g=d.count;p<g;p++)Sn.fromBufferAttribute(d,p),m&&(br.fromBufferAttribute(t,p),Sn.add(br)),l=Math.max(l,s.distanceToSquared(Sn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,i=this.attributes;if(t===null||i.position===void 0||i.normal===void 0||i.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const s=i.position,l=i.normal,c=i.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Jn(new Float32Array(4*s.count),4));const h=this.getAttribute("tangent"),d=[],m=[];for(let j=0;j<s.count;j++)d[j]=new J,m[j]=new J;const p=new J,g=new J,_=new J,y=new se,v=new se,b=new se,E=new J,M=new J;function x(j,L,R){p.fromBufferAttribute(s,j),g.fromBufferAttribute(s,L),_.fromBufferAttribute(s,R),y.fromBufferAttribute(c,j),v.fromBufferAttribute(c,L),b.fromBufferAttribute(c,R),g.sub(p),_.sub(p),v.sub(y),b.sub(y);const B=1/(v.x*b.y-b.x*v.y);isFinite(B)&&(E.copy(g).multiplyScalar(b.y).addScaledVector(_,-v.y).multiplyScalar(B),M.copy(_).multiplyScalar(v.x).addScaledVector(g,-b.x).multiplyScalar(B),d[j].add(E),d[L].add(E),d[R].add(E),m[j].add(M),m[L].add(M),m[R].add(M))}let P=this.groups;P.length===0&&(P=[{start:0,count:t.count}]);for(let j=0,L=P.length;j<L;++j){const R=P[j],B=R.start,tt=R.count;for(let et=B,ut=B+tt;et<ut;et+=3)x(t.getX(et+0),t.getX(et+1),t.getX(et+2))}const N=new J,w=new J,k=new J,H=new J;function I(j){k.fromBufferAttribute(l,j),H.copy(k);const L=d[j];N.copy(L),N.sub(k.multiplyScalar(k.dot(L))).normalize(),w.crossVectors(H,L);const B=w.dot(m[j])<0?-1:1;h.setXYZW(j,N.x,N.y,N.z,B)}for(let j=0,L=P.length;j<L;++j){const R=P[j],B=R.start,tt=R.count;for(let et=B,ut=B+tt;et<ut;et+=3)I(t.getX(et+0)),I(t.getX(et+1)),I(t.getX(et+2))}}computeVertexNormals(){const t=this.index,i=this.getAttribute("position");if(i!==void 0){let s=this.getAttribute("normal");if(s===void 0)s=new Jn(new Float32Array(i.count*3),3),this.setAttribute("normal",s);else for(let y=0,v=s.count;y<v;y++)s.setXYZ(y,0,0,0);const l=new J,c=new J,h=new J,d=new J,m=new J,p=new J,g=new J,_=new J;if(t)for(let y=0,v=t.count;y<v;y+=3){const b=t.getX(y+0),E=t.getX(y+1),M=t.getX(y+2);l.fromBufferAttribute(i,b),c.fromBufferAttribute(i,E),h.fromBufferAttribute(i,M),g.subVectors(h,c),_.subVectors(l,c),g.cross(_),d.fromBufferAttribute(s,b),m.fromBufferAttribute(s,E),p.fromBufferAttribute(s,M),d.add(g),m.add(g),p.add(g),s.setXYZ(b,d.x,d.y,d.z),s.setXYZ(E,m.x,m.y,m.z),s.setXYZ(M,p.x,p.y,p.z)}else for(let y=0,v=i.count;y<v;y+=3)l.fromBufferAttribute(i,y+0),c.fromBufferAttribute(i,y+1),h.fromBufferAttribute(i,y+2),g.subVectors(h,c),_.subVectors(l,c),g.cross(_),s.setXYZ(y+0,g.x,g.y,g.z),s.setXYZ(y+1,g.x,g.y,g.z),s.setXYZ(y+2,g.x,g.y,g.z);this.normalizeNormals(),s.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let i=0,s=t.count;i<s;i++)Sn.fromBufferAttribute(t,i),Sn.normalize(),t.setXYZ(i,Sn.x,Sn.y,Sn.z)}toNonIndexed(){function t(d,m){const p=d.array,g=d.itemSize,_=d.normalized,y=new p.constructor(m.length*g);let v=0,b=0;for(let E=0,M=m.length;E<M;E++){d.isInterleavedBufferAttribute?v=m[E]*d.data.stride+d.offset:v=m[E]*g;for(let x=0;x<g;x++)y[b++]=p[v++]}return new Jn(y,g,_)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new Gn,s=this.index.array,l=this.attributes;for(const d in l){const m=l[d],p=t(m,s);i.setAttribute(d,p)}const c=this.morphAttributes;for(const d in c){const m=[],p=c[d];for(let g=0,_=p.length;g<_;g++){const y=p[g],v=t(y,s);m.push(v)}i.morphAttributes[d]=m}i.morphTargetsRelative=this.morphTargetsRelative;const h=this.groups;for(let d=0,m=h.length;d<m;d++){const p=h[d];i.addGroup(p.start,p.count,p.materialIndex)}return i}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const m=this.parameters;for(const p in m)m[p]!==void 0&&(t[p]=m[p]);return t}t.data={attributes:{}};const i=this.index;i!==null&&(t.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const s=this.attributes;for(const m in s){const p=s[m];t.data.attributes[m]=p.toJSON(t.data)}const l={};let c=!1;for(const m in this.morphAttributes){const p=this.morphAttributes[m],g=[];for(let _=0,y=p.length;_<y;_++){const v=p[_];g.push(v.toJSON(t.data))}g.length>0&&(l[m]=g,c=!0)}c&&(t.data.morphAttributes=l,t.data.morphTargetsRelative=this.morphTargetsRelative);const h=this.groups;h.length>0&&(t.data.groups=JSON.parse(JSON.stringify(h)));const d=this.boundingSphere;return d!==null&&(t.data.boundingSphere={center:d.center.toArray(),radius:d.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=t.name;const s=t.index;s!==null&&this.setIndex(s.clone(i));const l=t.attributes;for(const p in l){const g=l[p];this.setAttribute(p,g.clone(i))}const c=t.morphAttributes;for(const p in c){const g=[],_=c[p];for(let y=0,v=_.length;y<v;y++)g.push(_[y].clone(i));this.morphAttributes[p]=g}this.morphTargetsRelative=t.morphTargetsRelative;const h=t.groups;for(let p=0,g=h.length;p<g;p++){const _=h[p];this.addGroup(_.start,_.count,_.materialIndex)}const d=t.boundingBox;d!==null&&(this.boundingBox=d.clone());const m=t.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const c_=new Ke,ys=new tu,Sc=new tl,u_=new J,Mc=new J,bc=new J,Ec=new J,Ih=new J,Tc=new J,f_=new J,Ac=new J;class Qe extends gn{constructor(t=new Gn,i=new Yc){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,h=l.length;c<h;c++){const d=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=c}}}}getVertexPosition(t,i){const s=this.geometry,l=s.attributes.position,c=s.morphAttributes.position,h=s.morphTargetsRelative;i.fromBufferAttribute(l,t);const d=this.morphTargetInfluences;if(c&&d){Tc.set(0,0,0);for(let m=0,p=c.length;m<p;m++){const g=d[m],_=c[m];g!==0&&(Ih.fromBufferAttribute(_,t),h?Tc.addScaledVector(Ih,g):Tc.addScaledVector(Ih.sub(i),g))}i.add(Tc)}return i}raycast(t,i){const s=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(s.boundingSphere===null&&s.computeBoundingSphere(),Sc.copy(s.boundingSphere),Sc.applyMatrix4(c),ys.copy(t.ray).recast(t.near),!(Sc.containsPoint(ys.origin)===!1&&(ys.intersectSphere(Sc,u_)===null||ys.origin.distanceToSquared(u_)>(t.far-t.near)**2))&&(c_.copy(c).invert(),ys.copy(t.ray).applyMatrix4(c_),!(s.boundingBox!==null&&ys.intersectsBox(s.boundingBox)===!1)&&this._computeIntersections(t,i,ys)))}_computeIntersections(t,i,s){let l;const c=this.geometry,h=this.material,d=c.index,m=c.attributes.position,p=c.attributes.uv,g=c.attributes.uv1,_=c.attributes.normal,y=c.groups,v=c.drawRange;if(d!==null)if(Array.isArray(h))for(let b=0,E=y.length;b<E;b++){const M=y[b],x=h[M.materialIndex],P=Math.max(M.start,v.start),N=Math.min(d.count,Math.min(M.start+M.count,v.start+v.count));for(let w=P,k=N;w<k;w+=3){const H=d.getX(w),I=d.getX(w+1),j=d.getX(w+2);l=Rc(this,x,t,s,p,g,_,H,I,j),l&&(l.faceIndex=Math.floor(w/3),l.face.materialIndex=M.materialIndex,i.push(l))}}else{const b=Math.max(0,v.start),E=Math.min(d.count,v.start+v.count);for(let M=b,x=E;M<x;M+=3){const P=d.getX(M),N=d.getX(M+1),w=d.getX(M+2);l=Rc(this,h,t,s,p,g,_,P,N,w),l&&(l.faceIndex=Math.floor(M/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(h))for(let b=0,E=y.length;b<E;b++){const M=y[b],x=h[M.materialIndex],P=Math.max(M.start,v.start),N=Math.min(m.count,Math.min(M.start+M.count,v.start+v.count));for(let w=P,k=N;w<k;w+=3){const H=w,I=w+1,j=w+2;l=Rc(this,x,t,s,p,g,_,H,I,j),l&&(l.faceIndex=Math.floor(w/3),l.face.materialIndex=M.materialIndex,i.push(l))}}else{const b=Math.max(0,v.start),E=Math.min(m.count,v.start+v.count);for(let M=b,x=E;M<x;M+=3){const P=M,N=M+1,w=M+2;l=Rc(this,h,t,s,p,g,_,P,N,w),l&&(l.faceIndex=Math.floor(M/3),i.push(l))}}}}function g1(r,t,i,s,l,c,h,d){let m;if(t.side===Fn?m=s.intersectTriangle(h,c,l,!0,d):m=s.intersectTriangle(l,c,h,t.side===Ja,d),m===null)return null;Ac.copy(d),Ac.applyMatrix4(r.matrixWorld);const p=i.ray.origin.distanceTo(Ac);return p<i.near||p>i.far?null:{distance:p,point:Ac.clone(),object:r}}function Rc(r,t,i,s,l,c,h,d,m,p){r.getVertexPosition(d,Mc),r.getVertexPosition(m,bc),r.getVertexPosition(p,Ec);const g=g1(r,t,i,s,Mc,bc,Ec,f_);if(g){const _=new J;Ci.getBarycoord(f_,Mc,bc,Ec,_),l&&(g.uv=Ci.getInterpolatedAttribute(l,d,m,p,_,new se)),c&&(g.uv1=Ci.getInterpolatedAttribute(c,d,m,p,_,new se)),h&&(g.normal=Ci.getInterpolatedAttribute(h,d,m,p,_,new J),g.normal.dot(s.direction)>0&&g.normal.multiplyScalar(-1));const y={a:d,b:m,c:p,normal:new J,materialIndex:0};Ci.getNormal(Mc,bc,Ec,y.normal),g.face=y,g.barycoord=_}return g}class Qa extends Gn{constructor(t=1,i=1,s=1,l=1,c=1,h=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:i,depth:s,widthSegments:l,heightSegments:c,depthSegments:h};const d=this;l=Math.floor(l),c=Math.floor(c),h=Math.floor(h);const m=[],p=[],g=[],_=[];let y=0,v=0;b("z","y","x",-1,-1,s,i,t,h,c,0),b("z","y","x",1,-1,s,i,-t,h,c,1),b("x","z","y",1,1,t,s,i,l,h,2),b("x","z","y",1,-1,t,s,-i,l,h,3),b("x","y","z",1,-1,t,i,s,l,c,4),b("x","y","z",-1,-1,t,i,-s,l,c,5),this.setIndex(m),this.setAttribute("position",new wn(p,3)),this.setAttribute("normal",new wn(g,3)),this.setAttribute("uv",new wn(_,2));function b(E,M,x,P,N,w,k,H,I,j,L){const R=w/I,B=k/j,tt=w/2,et=k/2,ut=H/2,ft=I+1,z=j+1;let W=0,X=0;const _t=new J;for(let Et=0;Et<z;Et++){const O=Et*B-et;for(let at=0;at<ft;at++){const vt=at*R-tt;_t[E]=vt*P,_t[M]=O*N,_t[x]=ut,p.push(_t.x,_t.y,_t.z),_t[E]=0,_t[M]=0,_t[x]=H>0?1:-1,g.push(_t.x,_t.y,_t.z),_.push(at/I),_.push(1-Et/j),W+=1}}for(let Et=0;Et<j;Et++)for(let O=0;O<I;O++){const at=y+O+ft*Et,vt=y+O+ft*(Et+1),Y=y+(O+1)+ft*(Et+1),st=y+(O+1)+ft*Et;m.push(at,vt,st),m.push(vt,Y,st),X+=6}d.addGroup(v,X,L),v+=X,y+=W}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Qa(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function kr(r){const t={};for(const i in r){t[i]={};for(const s in r[i]){const l=r[i][s];l&&(l.isColor||l.isMatrix3||l.isMatrix4||l.isVector2||l.isVector3||l.isVector4||l.isTexture||l.isQuaternion)?l.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[i][s]=null):t[i][s]=l.clone():Array.isArray(l)?t[i][s]=l.slice():t[i][s]=l}}return t}function In(r){const t={};for(let i=0;i<r.length;i++){const s=kr(r[i]);for(const l in s)t[l]=s[l]}return t}function _1(r){const t=[];for(let i=0;i<r.length;i++)t.push(r[i].clone());return t}function Mv(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:De.workingColorSpace}const v1={clone:kr,merge:In};var x1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,y1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Hi extends Ns{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=x1,this.fragmentShader=y1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=kr(t.uniforms),this.uniformsGroups=_1(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const i=super.toJSON(t);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const h=this.uniforms[l].value;h&&h.isTexture?i.uniforms[l]={type:"t",value:h.toJSON(t).uuid}:h&&h.isColor?i.uniforms[l]={type:"c",value:h.getHex()}:h&&h.isVector2?i.uniforms[l]={type:"v2",value:h.toArray()}:h&&h.isVector3?i.uniforms[l]={type:"v3",value:h.toArray()}:h&&h.isVector4?i.uniforms[l]={type:"v4",value:h.toArray()}:h&&h.isMatrix3?i.uniforms[l]={type:"m3",value:h.toArray()}:h&&h.isMatrix4?i.uniforms[l]={type:"m4",value:h.toArray()}:i.uniforms[l]={value:h}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const s={};for(const l in this.extensions)this.extensions[l]===!0&&(s[l]=!0);return Object.keys(s).length>0&&(i.extensions=s),i}}class bv extends gn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ke,this.projectionMatrix=new Ke,this.projectionMatrixInverse=new Ke,this.coordinateSystem=ha}copy(t,i){return super.copy(t,i),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,i){super.updateWorldMatrix(t,i),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const ka=new J,h_=new se,d_=new se;class vi extends bv{constructor(t=50,i=1,s=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=s,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const i=.5*this.getFilmHeight()/t;this.fov=Od*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(kc*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Od*2*Math.atan(Math.tan(kc*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,i,s){ka.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(ka.x,ka.y).multiplyScalar(-t/ka.z),ka.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),s.set(ka.x,ka.y).multiplyScalar(-t/ka.z)}getViewSize(t,i){return this.getViewBounds(t,h_,d_),i.subVectors(d_,h_)}setViewOffset(t,i,s,l,c,h){this.aspect=t/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let i=t*Math.tan(kc*.5*this.fov)/this.zoom,s=2*i,l=this.aspect*s,c=-.5*l;const h=this.view;if(this.view!==null&&this.view.enabled){const m=h.fullWidth,p=h.fullHeight;c+=h.offsetX*l/m,i-=h.offsetY*s/p,l*=h.width/m,s*=h.height/p}const d=this.filmOffset;d!==0&&(c+=t*d/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-s,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}const Er=-90,Tr=1;class S1 extends gn{constructor(t,i,s){super(),this.type="CubeCamera",this.renderTarget=s,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new vi(Er,Tr,t,i);l.layers=this.layers,this.add(l);const c=new vi(Er,Tr,t,i);c.layers=this.layers,this.add(c);const h=new vi(Er,Tr,t,i);h.layers=this.layers,this.add(h);const d=new vi(Er,Tr,t,i);d.layers=this.layers,this.add(d);const m=new vi(Er,Tr,t,i);m.layers=this.layers,this.add(m);const p=new vi(Er,Tr,t,i);p.layers=this.layers,this.add(p)}updateCoordinateSystem(){const t=this.coordinateSystem,i=this.children.concat(),[s,l,c,h,d,m]=i;for(const p of i)this.remove(p);if(t===ha)s.up.set(0,1,0),s.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),h.up.set(0,0,1),h.lookAt(0,-1,0),d.up.set(0,1,0),d.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(t===qc)s.up.set(0,-1,0),s.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),h.up.set(0,0,-1),h.lookAt(0,-1,0),d.up.set(0,-1,0),d.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const p of i)this.add(p),p.updateMatrixWorld()}update(t,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:s,activeMipmapLevel:l}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[c,h,d,m,p,g]=this.children,_=t.getRenderTarget(),y=t.getActiveCubeFace(),v=t.getActiveMipmapLevel(),b=t.xr.enabled;t.xr.enabled=!1;const E=s.texture.generateMipmaps;s.texture.generateMipmaps=!1,t.setRenderTarget(s,0,l),t.render(i,c),t.setRenderTarget(s,1,l),t.render(i,h),t.setRenderTarget(s,2,l),t.render(i,d),t.setRenderTarget(s,3,l),t.render(i,m),t.setRenderTarget(s,4,l),t.render(i,p),s.texture.generateMipmaps=E,t.setRenderTarget(s,5,l),t.render(i,g),t.setRenderTarget(_,y,v),t.xr.enabled=b,s.texture.needsPMREMUpdate=!0}}class Ev extends Hn{constructor(t,i,s,l,c,h,d,m,p,g){t=t!==void 0?t:[],i=i!==void 0?i:Br,super(t,i,s,l,c,h,d,m,p,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class M1 extends Ds{constructor(t=1,i={}){super(t,t,i),this.isWebGLCubeRenderTarget=!0;const s={width:t,height:t,depth:1},l=[s,s,s,s,s,s];this.texture=new Ev(l,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=i.generateMipmaps!==void 0?i.generateMipmaps:!1,this.texture.minFilter=i.minFilter!==void 0?i.minFilter:Ii}fromEquirectangularTexture(t,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const s={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new Qa(5,5,5),c=new Hi({name:"CubemapFromEquirect",uniforms:kr(s.uniforms),vertexShader:s.vertexShader,fragmentShader:s.fragmentShader,side:Fn,blending:Za});c.uniforms.tEquirect.value=i;const h=new Qe(l,c),d=i.minFilter;return i.minFilter===Cs&&(i.minFilter=Ii),new S1(1,10,this).update(t,h),i.minFilter=d,h.geometry.dispose(),h.material.dispose(),this}clear(t,i,s,l){const c=t.getRenderTarget();for(let h=0;h<6;h++)t.setRenderTarget(this,h),t.clear(i,s,l);t.setRenderTarget(c)}}class qo extends gn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const b1={type:"move"};class Bh{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new qo,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new qo,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new J,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new J),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new qo,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new J,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new J),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const i=this._hand;if(i)for(const s of t.hand.values())this._getHandJoint(i,s)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,i,s){let l=null,c=null,h=null;const d=this._targetRay,m=this._grip,p=this._hand;if(t&&i.session.visibilityState!=="visible-blurred"){if(p&&t.hand){h=!0;for(const E of t.hand.values()){const M=i.getJointPose(E,s),x=this._getHandJoint(p,E);M!==null&&(x.matrix.fromArray(M.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=M.radius),x.visible=M!==null}const g=p.joints["index-finger-tip"],_=p.joints["thumb-tip"],y=g.position.distanceTo(_.position),v=.02,b=.005;p.inputState.pinching&&y>v+b?(p.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!p.inputState.pinching&&y<=v-b&&(p.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else m!==null&&t.gripSpace&&(c=i.getPose(t.gripSpace,s),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1));d!==null&&(l=i.getPose(t.targetRaySpace,s),l===null&&c!==null&&(l=c),l!==null&&(d.matrix.fromArray(l.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,l.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(l.linearVelocity)):d.hasLinearVelocity=!1,l.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(l.angularVelocity)):d.hasAngularVelocity=!1,this.dispatchEvent(b1)))}return d!==null&&(d.visible=l!==null),m!==null&&(m.visible=c!==null),p!==null&&(p.visible=h!==null),this}_getHandJoint(t,i){if(t.joints[i.jointName]===void 0){const s=new qo;s.matrixAutoUpdate=!1,s.visible=!1,t.joints[i.jointName]=s,t.add(s)}return t.joints[i.jointName]}}class E1 extends gn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Fi,this.environmentIntensity=1,this.environmentRotation=new Fi,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,i){return super.copy(t,i),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const i=super.toJSON(t);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const Fh=new J,T1=new J,A1=new ue;class ja{constructor(t=new J(1,0,0),i=0){this.isPlane=!0,this.normal=t,this.constant=i}set(t,i){return this.normal.copy(t),this.constant=i,this}setComponents(t,i,s,l){return this.normal.set(t,i,s),this.constant=l,this}setFromNormalAndCoplanarPoint(t,i){return this.normal.copy(t),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(t,i,s){const l=Fh.subVectors(s,i).cross(T1.subVectors(t,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,i){return i.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,i){const s=t.delta(Fh),l=this.normal.dot(s);if(l===0)return this.distanceToPoint(t.start)===0?i.copy(t.start):null;const c=-(t.start.dot(this.normal)+this.constant)/l;return c<0||c>1?null:i.copy(t.start).addScaledVector(s,c)}intersectsLine(t){const i=this.distanceToPoint(t.start),s=this.distanceToPoint(t.end);return i<0&&s>0||s<0&&i>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,i){const s=i||A1.getNormalMatrix(t),l=this.coplanarPoint(Fh).applyMatrix4(t),c=this.normal.applyMatrix3(s).normalize();return this.constant=-l.dot(c),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Ss=new tl,Cc=new J;class qd{constructor(t=new ja,i=new ja,s=new ja,l=new ja,c=new ja,h=new ja){this.planes=[t,i,s,l,c,h]}set(t,i,s,l,c,h){const d=this.planes;return d[0].copy(t),d[1].copy(i),d[2].copy(s),d[3].copy(l),d[4].copy(c),d[5].copy(h),this}copy(t){const i=this.planes;for(let s=0;s<6;s++)i[s].copy(t.planes[s]);return this}setFromProjectionMatrix(t,i=ha){const s=this.planes,l=t.elements,c=l[0],h=l[1],d=l[2],m=l[3],p=l[4],g=l[5],_=l[6],y=l[7],v=l[8],b=l[9],E=l[10],M=l[11],x=l[12],P=l[13],N=l[14],w=l[15];if(s[0].setComponents(m-c,y-p,M-v,w-x).normalize(),s[1].setComponents(m+c,y+p,M+v,w+x).normalize(),s[2].setComponents(m+h,y+g,M+b,w+P).normalize(),s[3].setComponents(m-h,y-g,M-b,w-P).normalize(),s[4].setComponents(m-d,y-_,M-E,w-N).normalize(),i===ha)s[5].setComponents(m+d,y+_,M+E,w+N).normalize();else if(i===qc)s[5].setComponents(d,_,E,N).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ss.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const i=t.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),Ss.copy(i.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ss)}intersectsSprite(t){return Ss.center.set(0,0,0),Ss.radius=.7071067811865476,Ss.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ss)}intersectsSphere(t){const i=this.planes,s=t.center,l=-t.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(s)<l)return!1;return!0}intersectsBox(t){const i=this.planes;for(let s=0;s<6;s++){const l=i[s];if(Cc.x=l.normal.x>0?t.max.x:t.min.x,Cc.y=l.normal.y>0?t.max.y:t.min.y,Cc.z=l.normal.z>0?t.max.z:t.min.z,l.distanceToPoint(Cc)<0)return!1}return!0}containsPoint(t){const i=this.planes;for(let s=0;s<6;s++)if(i[s].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Pd extends Ns{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new be(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Zc=new J,Kc=new J,p_=new Ke,Wo=new tu,wc=new tl,Hh=new J,m_=new J;class g_ extends gn{constructor(t=new Gn,i=new Pd){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const i=t.attributes.position,s=[0];for(let l=1,c=i.count;l<c;l++)Zc.fromBufferAttribute(i,l-1),Kc.fromBufferAttribute(i,l),s[l]=s[l-1],s[l]+=Zc.distanceTo(Kc);t.setAttribute("lineDistance",new wn(s,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,i){const s=this.geometry,l=this.matrixWorld,c=t.params.Line.threshold,h=s.drawRange;if(s.boundingSphere===null&&s.computeBoundingSphere(),wc.copy(s.boundingSphere),wc.applyMatrix4(l),wc.radius+=c,t.ray.intersectsSphere(wc)===!1)return;p_.copy(l).invert(),Wo.copy(t.ray).applyMatrix4(p_);const d=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=d*d,p=this.isLineSegments?2:1,g=s.index,y=s.attributes.position;if(g!==null){const v=Math.max(0,h.start),b=Math.min(g.count,h.start+h.count);for(let E=v,M=b-1;E<M;E+=p){const x=g.getX(E),P=g.getX(E+1),N=Dc(this,t,Wo,m,x,P,E);N&&i.push(N)}if(this.isLineLoop){const E=g.getX(b-1),M=g.getX(v),x=Dc(this,t,Wo,m,E,M,b-1);x&&i.push(x)}}else{const v=Math.max(0,h.start),b=Math.min(y.count,h.start+h.count);for(let E=v,M=b-1;E<M;E+=p){const x=Dc(this,t,Wo,m,E,E+1,E);x&&i.push(x)}if(this.isLineLoop){const E=Dc(this,t,Wo,m,b-1,v,b-1);E&&i.push(E)}}}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,h=l.length;c<h;c++){const d=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=c}}}}}function Dc(r,t,i,s,l,c,h){const d=r.geometry.attributes.position;if(Zc.fromBufferAttribute(d,l),Kc.fromBufferAttribute(d,c),i.distanceSqToSegment(Zc,Kc,Hh,m_)>s)return;Hh.applyMatrix4(r.matrixWorld);const p=t.ray.origin.distanceTo(Hh);if(!(p<t.near||p>t.far))return{distance:p,point:m_.clone().applyMatrix4(r.matrixWorld),index:h,face:null,faceIndex:null,barycoord:null,object:r}}class Tv extends Ns{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new be(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const __=new Ke,zd=new tu,Lc=new tl,Uc=new J;class R1 extends gn{constructor(t=new Gn,i=new Tv){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,i){const s=this.geometry,l=this.matrixWorld,c=t.params.Points.threshold,h=s.drawRange;if(s.boundingSphere===null&&s.computeBoundingSphere(),Lc.copy(s.boundingSphere),Lc.applyMatrix4(l),Lc.radius+=c,t.ray.intersectsSphere(Lc)===!1)return;__.copy(l).invert(),zd.copy(t.ray).applyMatrix4(__);const d=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=d*d,p=s.index,_=s.attributes.position;if(p!==null){const y=Math.max(0,h.start),v=Math.min(p.count,h.start+h.count);for(let b=y,E=v;b<E;b++){const M=p.getX(b);Uc.fromBufferAttribute(_,M),v_(Uc,M,m,l,t,i,this)}}else{const y=Math.max(0,h.start),v=Math.min(_.count,h.start+h.count);for(let b=y,E=v;b<E;b++)Uc.fromBufferAttribute(_,b),v_(Uc,b,m,l,t,i,this)}}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,h=l.length;c<h;c++){const d=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=c}}}}}function v_(r,t,i,s,l,c,h){const d=zd.distanceSqToPoint(r);if(d<i){const m=new J;zd.closestPointToPoint(r,m),m.applyMatrix4(s);const p=l.ray.origin.distanceTo(m);if(p<l.near||p>l.far)return;c.push({distance:p,distanceToRay:Math.sqrt(d),point:m,index:t,face:null,faceIndex:null,barycoord:null,object:h})}}class Av extends Hn{constructor(t,i,s,l,c,h,d,m,p,g=Nr){if(g!==Nr&&g!==Gr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");s===void 0&&g===Nr&&(s=ws),s===void 0&&g===Gr&&(s=Hr),super(null,l,c,h,d,m,g,s,p),this.isDepthTexture=!0,this.image={width:t,height:i},this.magFilter=d!==void 0?d:Di,this.minFilter=m!==void 0?m:Di,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Wd(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const i=super.toJSON(t);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class wr extends Gn{constructor(t=1,i=1,s=1,l=32,c=1,h=!1,d=0,m=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:i,height:s,radialSegments:l,heightSegments:c,openEnded:h,thetaStart:d,thetaLength:m};const p=this;l=Math.floor(l),c=Math.floor(c);const g=[],_=[],y=[],v=[];let b=0;const E=[],M=s/2;let x=0;P(),h===!1&&(t>0&&N(!0),i>0&&N(!1)),this.setIndex(g),this.setAttribute("position",new wn(_,3)),this.setAttribute("normal",new wn(y,3)),this.setAttribute("uv",new wn(v,2));function P(){const w=new J,k=new J;let H=0;const I=(i-t)/s;for(let j=0;j<=c;j++){const L=[],R=j/c,B=R*(i-t)+t;for(let tt=0;tt<=l;tt++){const et=tt/l,ut=et*m+d,ft=Math.sin(ut),z=Math.cos(ut);k.x=B*ft,k.y=-R*s+M,k.z=B*z,_.push(k.x,k.y,k.z),w.set(ft,I,z).normalize(),y.push(w.x,w.y,w.z),v.push(et,1-R),L.push(b++)}E.push(L)}for(let j=0;j<l;j++)for(let L=0;L<c;L++){const R=E[L][j],B=E[L+1][j],tt=E[L+1][j+1],et=E[L][j+1];(t>0||L!==0)&&(g.push(R,B,et),H+=3),(i>0||L!==c-1)&&(g.push(B,tt,et),H+=3)}p.addGroup(x,H,0),x+=H}function N(w){const k=b,H=new se,I=new J;let j=0;const L=w===!0?t:i,R=w===!0?1:-1;for(let tt=1;tt<=l;tt++)_.push(0,M*R,0),y.push(0,R,0),v.push(.5,.5),b++;const B=b;for(let tt=0;tt<=l;tt++){const ut=tt/l*m+d,ft=Math.cos(ut),z=Math.sin(ut);I.x=L*z,I.y=M*R,I.z=L*ft,_.push(I.x,I.y,I.z),y.push(0,R,0),H.x=ft*.5+.5,H.y=z*.5*R+.5,v.push(H.x,H.y),b++}for(let tt=0;tt<l;tt++){const et=k+tt,ut=B+tt;w===!0?g.push(ut,ut+1,et):g.push(ut+1,ut,et),j+=3}p.addGroup(x,j,w===!0?1:2),x+=j}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new wr(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class eu extends Gn{constructor(t=1,i=1,s=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:i,widthSegments:s,heightSegments:l};const c=t/2,h=i/2,d=Math.floor(s),m=Math.floor(l),p=d+1,g=m+1,_=t/d,y=i/m,v=[],b=[],E=[],M=[];for(let x=0;x<g;x++){const P=x*y-h;for(let N=0;N<p;N++){const w=N*_-c;b.push(w,-P,0),E.push(0,0,1),M.push(N/d),M.push(1-x/m)}}for(let x=0;x<m;x++)for(let P=0;P<d;P++){const N=P+p*x,w=P+p*(x+1),k=P+1+p*(x+1),H=P+1+p*x;v.push(N,w,H),v.push(w,k,H)}this.setIndex(v),this.setAttribute("position",new wn(b,3)),this.setAttribute("normal",new wn(E,3)),this.setAttribute("uv",new wn(M,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new eu(t.width,t.height,t.widthSegments,t.heightSegments)}}class Qc extends Gn{constructor(t=.5,i=1,s=32,l=1,c=0,h=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:i,thetaSegments:s,phiSegments:l,thetaStart:c,thetaLength:h},s=Math.max(3,s),l=Math.max(1,l);const d=[],m=[],p=[],g=[];let _=t;const y=(i-t)/l,v=new J,b=new se;for(let E=0;E<=l;E++){for(let M=0;M<=s;M++){const x=c+M/s*h;v.x=_*Math.cos(x),v.y=_*Math.sin(x),m.push(v.x,v.y,v.z),p.push(0,0,1),b.x=(v.x/i+1)/2,b.y=(v.y/i+1)/2,g.push(b.x,b.y)}_+=y}for(let E=0;E<l;E++){const M=E*(s+1);for(let x=0;x<s;x++){const P=x+M,N=P,w=P+s+1,k=P+s+2,H=P+1;d.push(N,w,H),d.push(w,k,H)}}this.setIndex(d),this.setAttribute("position",new wn(m,3)),this.setAttribute("normal",new wn(p,3)),this.setAttribute("uv",new wn(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Qc(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Pr extends Gn{constructor(t=1,i=32,s=16,l=0,c=Math.PI*2,h=0,d=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:i,heightSegments:s,phiStart:l,phiLength:c,thetaStart:h,thetaLength:d},i=Math.max(3,Math.floor(i)),s=Math.max(2,Math.floor(s));const m=Math.min(h+d,Math.PI);let p=0;const g=[],_=new J,y=new J,v=[],b=[],E=[],M=[];for(let x=0;x<=s;x++){const P=[],N=x/s;let w=0;x===0&&h===0?w=.5/i:x===s&&m===Math.PI&&(w=-.5/i);for(let k=0;k<=i;k++){const H=k/i;_.x=-t*Math.cos(l+H*c)*Math.sin(h+N*d),_.y=t*Math.cos(h+N*d),_.z=t*Math.sin(l+H*c)*Math.sin(h+N*d),b.push(_.x,_.y,_.z),y.copy(_).normalize(),E.push(y.x,y.y,y.z),M.push(H+w,1-N),P.push(p++)}g.push(P)}for(let x=0;x<s;x++)for(let P=0;P<i;P++){const N=g[x][P+1],w=g[x][P],k=g[x+1][P],H=g[x+1][P+1];(x!==0||h>0)&&v.push(N,w,H),(x!==s-1||m<Math.PI)&&v.push(w,k,H)}this.setIndex(v),this.setAttribute("position",new wn(b,3)),this.setAttribute("normal",new wn(E,3)),this.setAttribute("uv",new wn(M,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Pr(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class Rr extends Ns{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new be(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new be(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=pv,this.normalScale=new se(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Fi,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class C1 extends Ns{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=BS,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class w1 extends Ns{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const x_={enabled:!1,files:{},add:function(r,t){this.enabled!==!1&&(this.files[r]=t)},get:function(r){if(this.enabled!==!1)return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}};class D1{constructor(t,i,s){const l=this;let c=!1,h=0,d=0,m;const p=[];this.onStart=void 0,this.onLoad=t,this.onProgress=i,this.onError=s,this.itemStart=function(g){d++,c===!1&&l.onStart!==void 0&&l.onStart(g,h,d),c=!0},this.itemEnd=function(g){h++,l.onProgress!==void 0&&l.onProgress(g,h,d),h===d&&(c=!1,l.onLoad!==void 0&&l.onLoad())},this.itemError=function(g){l.onError!==void 0&&l.onError(g)},this.resolveURL=function(g){return m?m(g):g},this.setURLModifier=function(g){return m=g,this},this.addHandler=function(g,_){return p.push(g,_),this},this.removeHandler=function(g){const _=p.indexOf(g);return _!==-1&&p.splice(_,2),this},this.getHandler=function(g){for(let _=0,y=p.length;_<y;_+=2){const v=p[_],b=p[_+1];if(v.global&&(v.lastIndex=0),v.test(g))return b}return null}}}const L1=new D1;class Yd{constructor(t){this.manager=t!==void 0?t:L1,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,i){const s=this;return new Promise(function(l,c){s.load(t,l,i,c)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}}Yd.DEFAULT_MATERIAL_NAME="__DEFAULT";class U1 extends Yd{constructor(t){super(t)}load(t,i,s,l){this.path!==void 0&&(t=this.path+t),t=this.manager.resolveURL(t);const c=this,h=x_.get(t);if(h!==void 0)return c.manager.itemStart(t),setTimeout(function(){i&&i(h),c.manager.itemEnd(t)},0),h;const d=Ko("img");function m(){g(),x_.add(t,this),i&&i(this),c.manager.itemEnd(t)}function p(_){g(),l&&l(_),c.manager.itemError(t),c.manager.itemEnd(t)}function g(){d.removeEventListener("load",m,!1),d.removeEventListener("error",p,!1)}return d.addEventListener("load",m,!1),d.addEventListener("error",p,!1),t.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(d.crossOrigin=this.crossOrigin),c.manager.itemStart(t),d.src=t,d}}class N1 extends Yd{constructor(t){super(t)}load(t,i,s,l){const c=new Hn,h=new U1(this.manager);return h.setCrossOrigin(this.crossOrigin),h.setPath(this.path),h.load(t,function(d){c.image=d,c.needsUpdate=!0,i!==void 0&&i(c)},s,l),c}}class Zd extends gn{constructor(t,i=1){super(),this.isLight=!0,this.type="Light",this.color=new be(t),this.intensity=i}dispose(){}copy(t,i){return super.copy(t,i),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const i=super.toJSON(t);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,this.groundColor!==void 0&&(i.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(i.object.distance=this.distance),this.angle!==void 0&&(i.object.angle=this.angle),this.decay!==void 0&&(i.object.decay=this.decay),this.penumbra!==void 0&&(i.object.penumbra=this.penumbra),this.shadow!==void 0&&(i.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(i.object.target=this.target.uuid),i}}class O1 extends Zd{constructor(t,i,s){super(t,s),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(gn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new be(i)}copy(t,i){return super.copy(t,i),this.groundColor.copy(t.groundColor),this}}const Gh=new Ke,y_=new J,S_=new J;class P1{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new se(512,512),this.map=null,this.mapPass=null,this.matrix=new Ke,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new qd,this._frameExtents=new se(1,1),this._viewportCount=1,this._viewports=[new an(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const i=this.camera,s=this.matrix;y_.setFromMatrixPosition(t.matrixWorld),i.position.copy(y_),S_.setFromMatrixPosition(t.target.matrixWorld),i.lookAt(S_),i.updateMatrixWorld(),Gh.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Gh),s.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),s.multiply(Gh)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class Rv extends bv{constructor(t=-1,i=1,s=1,l=-1,c=.1,h=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=i,this.top=s,this.bottom=l,this.near=c,this.far=h,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,i,s,l,c,h){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),s=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=s-t,h=s+t,d=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const p=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=p*this.view.offsetX,h=c+p*this.view.width,d-=g*this.view.offsetY,m=d-g*this.view.height}this.projectionMatrix.makeOrthographic(c,h,d,m,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class z1 extends P1{constructor(){super(new Rv(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class M_ extends Zd{constructor(t,i){super(t,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(gn.DEFAULT_UP),this.updateMatrix(),this.target=new gn,this.shadow=new z1}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class I1 extends Zd{constructor(t,i){super(t,i),this.isAmbientLight=!0,this.type="AmbientLight"}}class B1 extends vi{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t,this.index=0}}class b_{constructor(t=1,i=0,s=0){this.radius=t,this.phi=i,this.theta=s}set(t,i,s){return this.radius=t,this.phi=i,this.theta=s,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=_e(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,i,s){return this.radius=Math.sqrt(t*t+i*i+s*s),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,s),this.phi=Math.acos(_e(i/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class F1 extends Us{constructor(t,i=null){super(),this.object=t,this.domElement=i,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(){}disconnect(){}dispose(){}update(){}}function E_(r,t,i,s){const l=H1(s);switch(i){case ov:return r*t;case cv:return r*t;case uv:return r*t*2;case fv:return r*t/l.components*l.byteLength;case kd:return r*t/l.components*l.byteLength;case hv:return r*t*2/l.components*l.byteLength;case jd:return r*t*2/l.components*l.byteLength;case lv:return r*t*3/l.components*l.byteLength;case wi:return r*t*4/l.components*l.byteLength;case Xd:return r*t*4/l.components*l.byteLength;case Bc:case Fc:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case Hc:case Gc:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case cd:case fd:return Math.max(r,16)*Math.max(t,8)/4;case ld:case ud:return Math.max(r,8)*Math.max(t,8)/2;case hd:case dd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case pd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case md:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case gd:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case _d:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case vd:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case xd:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case yd:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case Sd:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case Md:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case bd:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case Ed:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case Td:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case Ad:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case Rd:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case Cd:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case Vc:case wd:case Dd:return Math.ceil(r/4)*Math.ceil(t/4)*16;case dv:case Ld:return Math.ceil(r/4)*Math.ceil(t/4)*8;case Ud:case Nd:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function H1(r){switch(r){case pa:case av:return{byteLength:1,components:1};case Zo:case sv:case Qo:return{byteLength:2,components:1};case Gd:case Vd:return{byteLength:2,components:4};case ws:case Hd:case fa:return{byteLength:4,components:1};case rv:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Fd}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Fd);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Cv(){let r=null,t=!1,i=null,s=null;function l(c,h){i(c,h),s=r.requestAnimationFrame(l)}return{start:function(){t!==!0&&i!==null&&(s=r.requestAnimationFrame(l),t=!0)},stop:function(){r.cancelAnimationFrame(s),t=!1},setAnimationLoop:function(c){i=c},setContext:function(c){r=c}}}function G1(r){const t=new WeakMap;function i(d,m){const p=d.array,g=d.usage,_=p.byteLength,y=r.createBuffer();r.bindBuffer(m,y),r.bufferData(m,p,g),d.onUploadCallback();let v;if(p instanceof Float32Array)v=r.FLOAT;else if(p instanceof Uint16Array)d.isFloat16BufferAttribute?v=r.HALF_FLOAT:v=r.UNSIGNED_SHORT;else if(p instanceof Int16Array)v=r.SHORT;else if(p instanceof Uint32Array)v=r.UNSIGNED_INT;else if(p instanceof Int32Array)v=r.INT;else if(p instanceof Int8Array)v=r.BYTE;else if(p instanceof Uint8Array)v=r.UNSIGNED_BYTE;else if(p instanceof Uint8ClampedArray)v=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+p);return{buffer:y,type:v,bytesPerElement:p.BYTES_PER_ELEMENT,version:d.version,size:_}}function s(d,m,p){const g=m.array,_=m.updateRanges;if(r.bindBuffer(p,d),_.length===0)r.bufferSubData(p,0,g);else{_.sort((v,b)=>v.start-b.start);let y=0;for(let v=1;v<_.length;v++){const b=_[y],E=_[v];E.start<=b.start+b.count+1?b.count=Math.max(b.count,E.start+E.count-b.start):(++y,_[y]=E)}_.length=y+1;for(let v=0,b=_.length;v<b;v++){const E=_[v];r.bufferSubData(p,E.start*g.BYTES_PER_ELEMENT,g,E.start,E.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(d){return d.isInterleavedBufferAttribute&&(d=d.data),t.get(d)}function c(d){d.isInterleavedBufferAttribute&&(d=d.data);const m=t.get(d);m&&(r.deleteBuffer(m.buffer),t.delete(d))}function h(d,m){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const g=t.get(d);(!g||g.version<d.version)&&t.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const p=t.get(d);if(p===void 0)t.set(d,i(d,m));else if(p.version<d.version){if(p.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(p.buffer,d,m),p.version=d.version}}return{get:l,remove:c,update:h}}var V1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,k1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,j1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,X1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,W1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,q1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Y1=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Z1=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,K1=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Q1=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,J1=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,$1=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,tM=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,eM=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,nM=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,iM=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,aM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,sM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,rM=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,oM=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,lM=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,cM=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,uM=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,fM=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,hM=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,dM=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,pM=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,mM=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,gM=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,_M=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,vM="gl_FragColor = linearToOutputTexel( gl_FragColor );",xM=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,yM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,SM=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,MM=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,bM=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,EM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,TM=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,AM=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,RM=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,CM=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,wM=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,DM=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,LM=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,UM=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,NM=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,OM=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,PM=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,zM=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,IM=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,BM=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,FM=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,HM=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,GM=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,VM=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,kM=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,jM=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,XM=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,WM=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,qM=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,YM=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,ZM=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,KM=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,QM=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,JM=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,$M=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,tb=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,eb=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,nb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ib=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,ab=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,sb=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,rb=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,ob=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,lb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,cb=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,ub=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,fb=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,hb=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,db=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,pb=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,mb=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,gb=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,_b=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,vb=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,xb=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,yb=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Sb=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Mb=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,bb=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Eb=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Tb=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Ab=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Rb=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Cb=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,wb=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Db=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Lb=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Ub=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Nb=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Ob=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Pb=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,zb=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ib=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Bb=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Fb=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Hb=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Gb=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Vb=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,jb=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Wb=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qb=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Yb=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Zb=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Kb=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Qb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Jb=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$b=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,tE=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,eE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,nE=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,iE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,aE=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,rE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,oE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,lE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,cE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,uE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,fE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,hE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,pE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,gE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,_E=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,xE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,yE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,he={alphahash_fragment:V1,alphahash_pars_fragment:k1,alphamap_fragment:j1,alphamap_pars_fragment:X1,alphatest_fragment:W1,alphatest_pars_fragment:q1,aomap_fragment:Y1,aomap_pars_fragment:Z1,batching_pars_vertex:K1,batching_vertex:Q1,begin_vertex:J1,beginnormal_vertex:$1,bsdfs:tM,iridescence_fragment:eM,bumpmap_pars_fragment:nM,clipping_planes_fragment:iM,clipping_planes_pars_fragment:aM,clipping_planes_pars_vertex:sM,clipping_planes_vertex:rM,color_fragment:oM,color_pars_fragment:lM,color_pars_vertex:cM,color_vertex:uM,common:fM,cube_uv_reflection_fragment:hM,defaultnormal_vertex:dM,displacementmap_pars_vertex:pM,displacementmap_vertex:mM,emissivemap_fragment:gM,emissivemap_pars_fragment:_M,colorspace_fragment:vM,colorspace_pars_fragment:xM,envmap_fragment:yM,envmap_common_pars_fragment:SM,envmap_pars_fragment:MM,envmap_pars_vertex:bM,envmap_physical_pars_fragment:OM,envmap_vertex:EM,fog_vertex:TM,fog_pars_vertex:AM,fog_fragment:RM,fog_pars_fragment:CM,gradientmap_pars_fragment:wM,lightmap_pars_fragment:DM,lights_lambert_fragment:LM,lights_lambert_pars_fragment:UM,lights_pars_begin:NM,lights_toon_fragment:PM,lights_toon_pars_fragment:zM,lights_phong_fragment:IM,lights_phong_pars_fragment:BM,lights_physical_fragment:FM,lights_physical_pars_fragment:HM,lights_fragment_begin:GM,lights_fragment_maps:VM,lights_fragment_end:kM,logdepthbuf_fragment:jM,logdepthbuf_pars_fragment:XM,logdepthbuf_pars_vertex:WM,logdepthbuf_vertex:qM,map_fragment:YM,map_pars_fragment:ZM,map_particle_fragment:KM,map_particle_pars_fragment:QM,metalnessmap_fragment:JM,metalnessmap_pars_fragment:$M,morphinstance_vertex:tb,morphcolor_vertex:eb,morphnormal_vertex:nb,morphtarget_pars_vertex:ib,morphtarget_vertex:ab,normal_fragment_begin:sb,normal_fragment_maps:rb,normal_pars_fragment:ob,normal_pars_vertex:lb,normal_vertex:cb,normalmap_pars_fragment:ub,clearcoat_normal_fragment_begin:fb,clearcoat_normal_fragment_maps:hb,clearcoat_pars_fragment:db,iridescence_pars_fragment:pb,opaque_fragment:mb,packing:gb,premultiplied_alpha_fragment:_b,project_vertex:vb,dithering_fragment:xb,dithering_pars_fragment:yb,roughnessmap_fragment:Sb,roughnessmap_pars_fragment:Mb,shadowmap_pars_fragment:bb,shadowmap_pars_vertex:Eb,shadowmap_vertex:Tb,shadowmask_pars_fragment:Ab,skinbase_vertex:Rb,skinning_pars_vertex:Cb,skinning_vertex:wb,skinnormal_vertex:Db,specularmap_fragment:Lb,specularmap_pars_fragment:Ub,tonemapping_fragment:Nb,tonemapping_pars_fragment:Ob,transmission_fragment:Pb,transmission_pars_fragment:zb,uv_pars_fragment:Ib,uv_pars_vertex:Bb,uv_vertex:Fb,worldpos_vertex:Hb,background_vert:Gb,background_frag:Vb,backgroundCube_vert:kb,backgroundCube_frag:jb,cube_vert:Xb,cube_frag:Wb,depth_vert:qb,depth_frag:Yb,distanceRGBA_vert:Zb,distanceRGBA_frag:Kb,equirect_vert:Qb,equirect_frag:Jb,linedashed_vert:$b,linedashed_frag:tE,meshbasic_vert:eE,meshbasic_frag:nE,meshlambert_vert:iE,meshlambert_frag:aE,meshmatcap_vert:sE,meshmatcap_frag:rE,meshnormal_vert:oE,meshnormal_frag:lE,meshphong_vert:cE,meshphong_frag:uE,meshphysical_vert:fE,meshphysical_frag:hE,meshtoon_vert:dE,meshtoon_frag:pE,points_vert:mE,points_frag:gE,shadow_vert:_E,shadow_frag:vE,sprite_vert:xE,sprite_frag:yE},Nt={common:{diffuse:{value:new be(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ue},alphaMap:{value:null},alphaMapTransform:{value:new ue},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ue}},envmap:{envMap:{value:null},envMapRotation:{value:new ue},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ue}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ue}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ue},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ue},normalScale:{value:new se(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ue},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ue}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ue}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ue}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new be(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new be(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ue},alphaTest:{value:0},uvTransform:{value:new ue}},sprite:{diffuse:{value:new be(16777215)},opacity:{value:1},center:{value:new se(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ue},alphaMap:{value:null},alphaMapTransform:{value:new ue},alphaTest:{value:0}}},zi={basic:{uniforms:In([Nt.common,Nt.specularmap,Nt.envmap,Nt.aomap,Nt.lightmap,Nt.fog]),vertexShader:he.meshbasic_vert,fragmentShader:he.meshbasic_frag},lambert:{uniforms:In([Nt.common,Nt.specularmap,Nt.envmap,Nt.aomap,Nt.lightmap,Nt.emissivemap,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,Nt.fog,Nt.lights,{emissive:{value:new be(0)}}]),vertexShader:he.meshlambert_vert,fragmentShader:he.meshlambert_frag},phong:{uniforms:In([Nt.common,Nt.specularmap,Nt.envmap,Nt.aomap,Nt.lightmap,Nt.emissivemap,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,Nt.fog,Nt.lights,{emissive:{value:new be(0)},specular:{value:new be(1118481)},shininess:{value:30}}]),vertexShader:he.meshphong_vert,fragmentShader:he.meshphong_frag},standard:{uniforms:In([Nt.common,Nt.envmap,Nt.aomap,Nt.lightmap,Nt.emissivemap,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,Nt.roughnessmap,Nt.metalnessmap,Nt.fog,Nt.lights,{emissive:{value:new be(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:he.meshphysical_vert,fragmentShader:he.meshphysical_frag},toon:{uniforms:In([Nt.common,Nt.aomap,Nt.lightmap,Nt.emissivemap,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,Nt.gradientmap,Nt.fog,Nt.lights,{emissive:{value:new be(0)}}]),vertexShader:he.meshtoon_vert,fragmentShader:he.meshtoon_frag},matcap:{uniforms:In([Nt.common,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,Nt.fog,{matcap:{value:null}}]),vertexShader:he.meshmatcap_vert,fragmentShader:he.meshmatcap_frag},points:{uniforms:In([Nt.points,Nt.fog]),vertexShader:he.points_vert,fragmentShader:he.points_frag},dashed:{uniforms:In([Nt.common,Nt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:he.linedashed_vert,fragmentShader:he.linedashed_frag},depth:{uniforms:In([Nt.common,Nt.displacementmap]),vertexShader:he.depth_vert,fragmentShader:he.depth_frag},normal:{uniforms:In([Nt.common,Nt.bumpmap,Nt.normalmap,Nt.displacementmap,{opacity:{value:1}}]),vertexShader:he.meshnormal_vert,fragmentShader:he.meshnormal_frag},sprite:{uniforms:In([Nt.sprite,Nt.fog]),vertexShader:he.sprite_vert,fragmentShader:he.sprite_frag},background:{uniforms:{uvTransform:{value:new ue},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:he.background_vert,fragmentShader:he.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ue}},vertexShader:he.backgroundCube_vert,fragmentShader:he.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:he.cube_vert,fragmentShader:he.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:he.equirect_vert,fragmentShader:he.equirect_frag},distanceRGBA:{uniforms:In([Nt.common,Nt.displacementmap,{referencePosition:{value:new J},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:he.distanceRGBA_vert,fragmentShader:he.distanceRGBA_frag},shadow:{uniforms:In([Nt.lights,Nt.fog,{color:{value:new be(0)},opacity:{value:1}}]),vertexShader:he.shadow_vert,fragmentShader:he.shadow_frag}};zi.physical={uniforms:In([zi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ue},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ue},clearcoatNormalScale:{value:new se(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ue},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ue},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ue},sheen:{value:0},sheenColor:{value:new be(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ue},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ue},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ue},transmissionSamplerSize:{value:new se},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ue},attenuationDistance:{value:0},attenuationColor:{value:new be(0)},specularColor:{value:new be(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ue},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ue},anisotropyVector:{value:new se},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ue}}]),vertexShader:he.meshphysical_vert,fragmentShader:he.meshphysical_frag};const Nc={r:0,b:0,g:0},Ms=new Fi,SE=new Ke;function ME(r,t,i,s,l,c,h){const d=new be(0);let m=c===!0?0:1,p,g,_=null,y=0,v=null;function b(N){let w=N.isScene===!0?N.background:null;return w&&w.isTexture&&(w=(N.backgroundBlurriness>0?i:t).get(w)),w}function E(N){let w=!1;const k=b(N);k===null?x(d,m):k&&k.isColor&&(x(k,1),w=!0);const H=r.xr.getEnvironmentBlendMode();H==="additive"?s.buffers.color.setClear(0,0,0,1,h):H==="alpha-blend"&&s.buffers.color.setClear(0,0,0,0,h),(r.autoClear||w)&&(s.buffers.depth.setTest(!0),s.buffers.depth.setMask(!0),s.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function M(N,w){const k=b(w);k&&(k.isCubeTexture||k.mapping===$c)?(g===void 0&&(g=new Qe(new Qa(1,1,1),new Hi({name:"BackgroundCubeMaterial",uniforms:kr(zi.backgroundCube.uniforms),vertexShader:zi.backgroundCube.vertexShader,fragmentShader:zi.backgroundCube.fragmentShader,side:Fn,depthTest:!1,depthWrite:!1,fog:!1})),g.geometry.deleteAttribute("normal"),g.geometry.deleteAttribute("uv"),g.onBeforeRender=function(H,I,j){this.matrixWorld.copyPosition(j.matrixWorld)},Object.defineProperty(g.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),l.update(g)),Ms.copy(w.backgroundRotation),Ms.x*=-1,Ms.y*=-1,Ms.z*=-1,k.isCubeTexture&&k.isRenderTargetTexture===!1&&(Ms.y*=-1,Ms.z*=-1),g.material.uniforms.envMap.value=k,g.material.uniforms.flipEnvMap.value=k.isCubeTexture&&k.isRenderTargetTexture===!1?-1:1,g.material.uniforms.backgroundBlurriness.value=w.backgroundBlurriness,g.material.uniforms.backgroundIntensity.value=w.backgroundIntensity,g.material.uniforms.backgroundRotation.value.setFromMatrix4(SE.makeRotationFromEuler(Ms)),g.material.toneMapped=De.getTransfer(k.colorSpace)!==Ve,(_!==k||y!==k.version||v!==r.toneMapping)&&(g.material.needsUpdate=!0,_=k,y=k.version,v=r.toneMapping),g.layers.enableAll(),N.unshift(g,g.geometry,g.material,0,0,null)):k&&k.isTexture&&(p===void 0&&(p=new Qe(new eu(2,2),new Hi({name:"BackgroundMaterial",uniforms:kr(zi.background.uniforms),vertexShader:zi.background.vertexShader,fragmentShader:zi.background.fragmentShader,side:Ja,depthTest:!1,depthWrite:!1,fog:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),l.update(p)),p.material.uniforms.t2D.value=k,p.material.uniforms.backgroundIntensity.value=w.backgroundIntensity,p.material.toneMapped=De.getTransfer(k.colorSpace)!==Ve,k.matrixAutoUpdate===!0&&k.updateMatrix(),p.material.uniforms.uvTransform.value.copy(k.matrix),(_!==k||y!==k.version||v!==r.toneMapping)&&(p.material.needsUpdate=!0,_=k,y=k.version,v=r.toneMapping),p.layers.enableAll(),N.unshift(p,p.geometry,p.material,0,0,null))}function x(N,w){N.getRGB(Nc,Mv(r)),s.buffers.color.setClear(Nc.r,Nc.g,Nc.b,w,h)}function P(){g!==void 0&&(g.geometry.dispose(),g.material.dispose(),g=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return d},setClearColor:function(N,w=1){d.set(N),m=w,x(d,m)},getClearAlpha:function(){return m},setClearAlpha:function(N){m=N,x(d,m)},render:E,addToRenderList:M,dispose:P}}function bE(r,t){const i=r.getParameter(r.MAX_VERTEX_ATTRIBS),s={},l=y(null);let c=l,h=!1;function d(R,B,tt,et,ut){let ft=!1;const z=_(et,tt,B);c!==z&&(c=z,p(c.object)),ft=v(R,et,tt,ut),ft&&b(R,et,tt,ut),ut!==null&&t.update(ut,r.ELEMENT_ARRAY_BUFFER),(ft||h)&&(h=!1,w(R,B,tt,et),ut!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(ut).buffer))}function m(){return r.createVertexArray()}function p(R){return r.bindVertexArray(R)}function g(R){return r.deleteVertexArray(R)}function _(R,B,tt){const et=tt.wireframe===!0;let ut=s[R.id];ut===void 0&&(ut={},s[R.id]=ut);let ft=ut[B.id];ft===void 0&&(ft={},ut[B.id]=ft);let z=ft[et];return z===void 0&&(z=y(m()),ft[et]=z),z}function y(R){const B=[],tt=[],et=[];for(let ut=0;ut<i;ut++)B[ut]=0,tt[ut]=0,et[ut]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:tt,attributeDivisors:et,object:R,attributes:{},index:null}}function v(R,B,tt,et){const ut=c.attributes,ft=B.attributes;let z=0;const W=tt.getAttributes();for(const X in W)if(W[X].location>=0){const Et=ut[X];let O=ft[X];if(O===void 0&&(X==="instanceMatrix"&&R.instanceMatrix&&(O=R.instanceMatrix),X==="instanceColor"&&R.instanceColor&&(O=R.instanceColor)),Et===void 0||Et.attribute!==O||O&&Et.data!==O.data)return!0;z++}return c.attributesNum!==z||c.index!==et}function b(R,B,tt,et){const ut={},ft=B.attributes;let z=0;const W=tt.getAttributes();for(const X in W)if(W[X].location>=0){let Et=ft[X];Et===void 0&&(X==="instanceMatrix"&&R.instanceMatrix&&(Et=R.instanceMatrix),X==="instanceColor"&&R.instanceColor&&(Et=R.instanceColor));const O={};O.attribute=Et,Et&&Et.data&&(O.data=Et.data),ut[X]=O,z++}c.attributes=ut,c.attributesNum=z,c.index=et}function E(){const R=c.newAttributes;for(let B=0,tt=R.length;B<tt;B++)R[B]=0}function M(R){x(R,0)}function x(R,B){const tt=c.newAttributes,et=c.enabledAttributes,ut=c.attributeDivisors;tt[R]=1,et[R]===0&&(r.enableVertexAttribArray(R),et[R]=1),ut[R]!==B&&(r.vertexAttribDivisor(R,B),ut[R]=B)}function P(){const R=c.newAttributes,B=c.enabledAttributes;for(let tt=0,et=B.length;tt<et;tt++)B[tt]!==R[tt]&&(r.disableVertexAttribArray(tt),B[tt]=0)}function N(R,B,tt,et,ut,ft,z){z===!0?r.vertexAttribIPointer(R,B,tt,ut,ft):r.vertexAttribPointer(R,B,tt,et,ut,ft)}function w(R,B,tt,et){E();const ut=et.attributes,ft=tt.getAttributes(),z=B.defaultAttributeValues;for(const W in ft){const X=ft[W];if(X.location>=0){let _t=ut[W];if(_t===void 0&&(W==="instanceMatrix"&&R.instanceMatrix&&(_t=R.instanceMatrix),W==="instanceColor"&&R.instanceColor&&(_t=R.instanceColor)),_t!==void 0){const Et=_t.normalized,O=_t.itemSize,at=t.get(_t);if(at===void 0)continue;const vt=at.buffer,Y=at.type,st=at.bytesPerElement,xt=Y===r.INT||Y===r.UNSIGNED_INT||_t.gpuType===Hd;if(_t.isInterleavedBufferAttribute){const bt=_t.data,Ft=bt.stride,Xt=_t.offset;if(bt.isInstancedInterleavedBuffer){for(let Yt=0;Yt<X.locationSize;Yt++)x(X.location+Yt,bt.meshPerAttribute);R.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=bt.meshPerAttribute*bt.count)}else for(let Yt=0;Yt<X.locationSize;Yt++)M(X.location+Yt);r.bindBuffer(r.ARRAY_BUFFER,vt);for(let Yt=0;Yt<X.locationSize;Yt++)N(X.location+Yt,O/X.locationSize,Y,Et,Ft*st,(Xt+O/X.locationSize*Yt)*st,xt)}else{if(_t.isInstancedBufferAttribute){for(let bt=0;bt<X.locationSize;bt++)x(X.location+bt,_t.meshPerAttribute);R.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=_t.meshPerAttribute*_t.count)}else for(let bt=0;bt<X.locationSize;bt++)M(X.location+bt);r.bindBuffer(r.ARRAY_BUFFER,vt);for(let bt=0;bt<X.locationSize;bt++)N(X.location+bt,O/X.locationSize,Y,Et,O*st,O/X.locationSize*bt*st,xt)}}else if(z!==void 0){const Et=z[W];if(Et!==void 0)switch(Et.length){case 2:r.vertexAttrib2fv(X.location,Et);break;case 3:r.vertexAttrib3fv(X.location,Et);break;case 4:r.vertexAttrib4fv(X.location,Et);break;default:r.vertexAttrib1fv(X.location,Et)}}}}P()}function k(){j();for(const R in s){const B=s[R];for(const tt in B){const et=B[tt];for(const ut in et)g(et[ut].object),delete et[ut];delete B[tt]}delete s[R]}}function H(R){if(s[R.id]===void 0)return;const B=s[R.id];for(const tt in B){const et=B[tt];for(const ut in et)g(et[ut].object),delete et[ut];delete B[tt]}delete s[R.id]}function I(R){for(const B in s){const tt=s[B];if(tt[R.id]===void 0)continue;const et=tt[R.id];for(const ut in et)g(et[ut].object),delete et[ut];delete tt[R.id]}}function j(){L(),h=!0,c!==l&&(c=l,p(c.object))}function L(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:d,reset:j,resetDefaultState:L,dispose:k,releaseStatesOfGeometry:H,releaseStatesOfProgram:I,initAttributes:E,enableAttribute:M,disableUnusedAttributes:P}}function EE(r,t,i){let s;function l(p){s=p}function c(p,g){r.drawArrays(s,p,g),i.update(g,s,1)}function h(p,g,_){_!==0&&(r.drawArraysInstanced(s,p,g,_),i.update(g,s,_))}function d(p,g,_){if(_===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(s,p,0,g,0,_);let v=0;for(let b=0;b<_;b++)v+=g[b];i.update(v,s,1)}function m(p,g,_,y){if(_===0)return;const v=t.get("WEBGL_multi_draw");if(v===null)for(let b=0;b<p.length;b++)h(p[b],g[b],y[b]);else{v.multiDrawArraysInstancedWEBGL(s,p,0,g,0,y,0,_);let b=0;for(let E=0;E<_;E++)b+=g[E]*y[E];i.update(b,s,1)}}this.setMode=l,this.render=c,this.renderInstances=h,this.renderMultiDraw=d,this.renderMultiDrawInstances=m}function TE(r,t,i,s){let l;function c(){if(l!==void 0)return l;if(t.has("EXT_texture_filter_anisotropic")===!0){const I=t.get("EXT_texture_filter_anisotropic");l=r.getParameter(I.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function h(I){return!(I!==wi&&s.convert(I)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(I){const j=I===Qo&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(I!==pa&&s.convert(I)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&I!==fa&&!j)}function m(I){if(I==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";I="mediump"}return I==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let p=i.precision!==void 0?i.precision:"highp";const g=m(p);g!==p&&(console.warn("THREE.WebGLRenderer:",p,"not supported, using",g,"instead."),p=g);const _=i.logarithmicDepthBuffer===!0,y=i.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),v=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),b=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=r.getParameter(r.MAX_TEXTURE_SIZE),M=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),x=r.getParameter(r.MAX_VERTEX_ATTRIBS),P=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),N=r.getParameter(r.MAX_VARYING_VECTORS),w=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),k=b>0,H=r.getParameter(r.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:h,textureTypeReadable:d,precision:p,logarithmicDepthBuffer:_,reverseDepthBuffer:y,maxTextures:v,maxVertexTextures:b,maxTextureSize:E,maxCubemapSize:M,maxAttributes:x,maxVertexUniforms:P,maxVaryings:N,maxFragmentUniforms:w,vertexTextures:k,maxSamples:H}}function AE(r){const t=this;let i=null,s=0,l=!1,c=!1;const h=new ja,d=new ue,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(_,y){const v=_.length!==0||y||s!==0||l;return l=y,s=_.length,v},this.beginShadows=function(){c=!0,g(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(_,y){i=g(_,y,0)},this.setState=function(_,y,v){const b=_.clippingPlanes,E=_.clipIntersection,M=_.clipShadows,x=r.get(_);if(!l||b===null||b.length===0||c&&!M)c?g(null):p();else{const P=c?0:s,N=P*4;let w=x.clippingState||null;m.value=w,w=g(b,y,N,v);for(let k=0;k!==N;++k)w[k]=i[k];x.clippingState=w,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=P}};function p(){m.value!==i&&(m.value=i,m.needsUpdate=s>0),t.numPlanes=s,t.numIntersection=0}function g(_,y,v,b){const E=_!==null?_.length:0;let M=null;if(E!==0){if(M=m.value,b!==!0||M===null){const x=v+E*4,P=y.matrixWorldInverse;d.getNormalMatrix(P),(M===null||M.length<x)&&(M=new Float32Array(x));for(let N=0,w=v;N!==E;++N,w+=4)h.copy(_[N]).applyMatrix4(P,d),h.normal.toArray(M,w),M[w+3]=h.constant}m.value=M,m.needsUpdate=!0}return t.numPlanes=E,t.numIntersection=0,M}}function RE(r){let t=new WeakMap;function i(h,d){return d===sd?h.mapping=Br:d===rd&&(h.mapping=Fr),h}function s(h){if(h&&h.isTexture){const d=h.mapping;if(d===sd||d===rd)if(t.has(h)){const m=t.get(h).texture;return i(m,h.mapping)}else{const m=h.image;if(m&&m.height>0){const p=new M1(m.height);return p.fromEquirectangularTexture(r,h),t.set(h,p),h.addEventListener("dispose",l),i(p.texture,h.mapping)}else return null}}return h}function l(h){const d=h.target;d.removeEventListener("dispose",l);const m=t.get(d);m!==void 0&&(t.delete(d),m.dispose())}function c(){t=new WeakMap}return{get:s,dispose:c}}const Dr=4,T_=[.125,.215,.35,.446,.526,.582],Rs=20,Vh=new Rv,A_=new be;let kh=null,jh=0,Xh=0,Wh=!1;const Ts=(1+Math.sqrt(5))/2,Ar=1/Ts,R_=[new J(-Ts,Ar,0),new J(Ts,Ar,0),new J(-Ar,0,Ts),new J(Ar,0,Ts),new J(0,Ts,-Ar),new J(0,Ts,Ar),new J(-1,1,-1),new J(1,1,-1),new J(-1,1,1),new J(1,1,1)],CE=new J;class C_{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,i=0,s=.1,l=100,c={}){const{size:h=256,position:d=CE}=c;kh=this._renderer.getRenderTarget(),jh=this._renderer.getActiveCubeFace(),Xh=this._renderer.getActiveMipmapLevel(),Wh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(h);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(t,s,l,m,d),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(t,i=null){return this._fromTexture(t,i)}fromCubemap(t,i=null){return this._fromTexture(t,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=L_(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=D_(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(kh,jh,Xh),this._renderer.xr.enabled=Wh,t.scissorTest=!1,Oc(t,0,0,t.width,t.height)}_fromTexture(t,i){t.mapping===Br||t.mapping===Fr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),kh=this._renderer.getRenderTarget(),jh=this._renderer.getActiveCubeFace(),Xh=this._renderer.getActiveMipmapLevel(),Wh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const s=i||this._allocateTargets();return this._textureToCubeUV(t,s),this._applyPMREM(s),this._cleanup(s),s}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,s={magFilter:Ii,minFilter:Ii,generateMipmaps:!1,type:Qo,format:wi,colorSpace:Vr,depthBuffer:!1},l=w_(t,i,s);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=w_(t,i,s);const{_lodMax:c}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=wE(c)),this._blurMaterial=DE(c,t,i)}return l}_compileMaterial(t){const i=new Qe(this._lodPlanes[0],t);this._renderer.compile(i,Vh)}_sceneToCubeUV(t,i,s,l,c){const m=new vi(90,1,i,s),p=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],_=this._renderer,y=_.autoClear,v=_.toneMapping;_.getClearColor(A_),_.toneMapping=Ka,_.autoClear=!1;const b=new Yc({name:"PMREM.Background",side:Fn,depthWrite:!1,depthTest:!1}),E=new Qe(new Qa,b);let M=!1;const x=t.background;x?x.isColor&&(b.color.copy(x),t.background=null,M=!0):(b.color.copy(A_),M=!0);for(let P=0;P<6;P++){const N=P%3;N===0?(m.up.set(0,p[P],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+g[P],c.y,c.z)):N===1?(m.up.set(0,0,p[P]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+g[P],c.z)):(m.up.set(0,p[P],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+g[P]));const w=this._cubeSize;Oc(l,N*w,P>2?w:0,w,w),_.setRenderTarget(l),M&&_.render(E,m),_.render(t,m)}E.geometry.dispose(),E.material.dispose(),_.toneMapping=v,_.autoClear=y,t.background=x}_textureToCubeUV(t,i){const s=this._renderer,l=t.mapping===Br||t.mapping===Fr;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=L_()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=D_());const c=l?this._cubemapMaterial:this._equirectMaterial,h=new Qe(this._lodPlanes[0],c),d=c.uniforms;d.envMap.value=t;const m=this._cubeSize;Oc(i,0,0,3*m,2*m),s.setRenderTarget(i),s.render(h,Vh)}_applyPMREM(t){const i=this._renderer,s=i.autoClear;i.autoClear=!1;const l=this._lodPlanes.length;for(let c=1;c<l;c++){const h=Math.sqrt(this._sigmas[c]*this._sigmas[c]-this._sigmas[c-1]*this._sigmas[c-1]),d=R_[(l-c-1)%R_.length];this._blur(t,c-1,c,h,d)}i.autoClear=s}_blur(t,i,s,l,c){const h=this._pingPongRenderTarget;this._halfBlur(t,h,i,s,l,"latitudinal",c),this._halfBlur(h,t,s,s,l,"longitudinal",c)}_halfBlur(t,i,s,l,c,h,d){const m=this._renderer,p=this._blurMaterial;h!=="latitudinal"&&h!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const g=3,_=new Qe(this._lodPlanes[l],p),y=p.uniforms,v=this._sizeLods[s]-1,b=isFinite(c)?Math.PI/(2*v):2*Math.PI/(2*Rs-1),E=c/b,M=isFinite(c)?1+Math.floor(g*E):Rs;M>Rs&&console.warn(`sigmaRadians, ${c}, is too large and will clip, as it requested ${M} samples when the maximum is set to ${Rs}`);const x=[];let P=0;for(let I=0;I<Rs;++I){const j=I/E,L=Math.exp(-j*j/2);x.push(L),I===0?P+=L:I<M&&(P+=2*L)}for(let I=0;I<x.length;I++)x[I]=x[I]/P;y.envMap.value=t.texture,y.samples.value=M,y.weights.value=x,y.latitudinal.value=h==="latitudinal",d&&(y.poleAxis.value=d);const{_lodMax:N}=this;y.dTheta.value=b,y.mipInt.value=N-s;const w=this._sizeLods[l],k=3*w*(l>N-Dr?l-N+Dr:0),H=4*(this._cubeSize-w);Oc(i,k,H,3*w,2*w),m.setRenderTarget(i),m.render(_,Vh)}}function wE(r){const t=[],i=[],s=[];let l=r;const c=r-Dr+1+T_.length;for(let h=0;h<c;h++){const d=Math.pow(2,l);i.push(d);let m=1/d;h>r-Dr?m=T_[h-r+Dr-1]:h===0&&(m=0),s.push(m);const p=1/(d-2),g=-p,_=1+p,y=[g,g,_,g,_,_,g,g,_,_,g,_],v=6,b=6,E=3,M=2,x=1,P=new Float32Array(E*b*v),N=new Float32Array(M*b*v),w=new Float32Array(x*b*v);for(let H=0;H<v;H++){const I=H%3*2/3-1,j=H>2?0:-1,L=[I,j,0,I+2/3,j,0,I+2/3,j+1,0,I,j,0,I+2/3,j+1,0,I,j+1,0];P.set(L,E*b*H),N.set(y,M*b*H);const R=[H,H,H,H,H,H];w.set(R,x*b*H)}const k=new Gn;k.setAttribute("position",new Jn(P,E)),k.setAttribute("uv",new Jn(N,M)),k.setAttribute("faceIndex",new Jn(w,x)),t.push(k),l>Dr&&l--}return{lodPlanes:t,sizeLods:i,sigmas:s}}function w_(r,t,i){const s=new Ds(r,t,i);return s.texture.mapping=$c,s.texture.name="PMREM.cubeUv",s.scissorTest=!0,s}function Oc(r,t,i,s,l){r.viewport.set(t,i,s,l),r.scissor.set(t,i,s,l)}function DE(r,t,i){const s=new Float32Array(Rs),l=new J(0,1,0);return new Hi({name:"SphericalGaussianBlur",defines:{n:Rs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:s},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:Kd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Za,depthTest:!1,depthWrite:!1})}function D_(){return new Hi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Kd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Za,depthTest:!1,depthWrite:!1})}function L_(){return new Hi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Kd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Za,depthTest:!1,depthWrite:!1})}function Kd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function LE(r){let t=new WeakMap,i=null;function s(d){if(d&&d.isTexture){const m=d.mapping,p=m===sd||m===rd,g=m===Br||m===Fr;if(p||g){let _=t.get(d);const y=_!==void 0?_.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==y)return i===null&&(i=new C_(r)),_=p?i.fromEquirectangular(d,_):i.fromCubemap(d,_),_.texture.pmremVersion=d.pmremVersion,t.set(d,_),_.texture;if(_!==void 0)return _.texture;{const v=d.image;return p&&v&&v.height>0||g&&v&&l(v)?(i===null&&(i=new C_(r)),_=p?i.fromEquirectangular(d):i.fromCubemap(d),_.texture.pmremVersion=d.pmremVersion,t.set(d,_),d.addEventListener("dispose",c),_.texture):null}}}return d}function l(d){let m=0;const p=6;for(let g=0;g<p;g++)d[g]!==void 0&&m++;return m===p}function c(d){const m=d.target;m.removeEventListener("dispose",c);const p=t.get(m);p!==void 0&&(t.delete(m),p.dispose())}function h(){t=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:s,dispose:h}}function UE(r){const t={};function i(s){if(t[s]!==void 0)return t[s];let l;switch(s){case"WEBGL_depth_texture":l=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":l=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":l=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":l=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:l=r.getExtension(s)}return t[s]=l,l}return{has:function(s){return i(s)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(s){const l=i(s);return l===null&&Es("THREE.WebGLRenderer: "+s+" extension not supported."),l}}}function NE(r,t,i,s){const l={},c=new WeakMap;function h(_){const y=_.target;y.index!==null&&t.remove(y.index);for(const b in y.attributes)t.remove(y.attributes[b]);y.removeEventListener("dispose",h),delete l[y.id];const v=c.get(y);v&&(t.remove(v),c.delete(y)),s.releaseStatesOfGeometry(y),y.isInstancedBufferGeometry===!0&&delete y._maxInstanceCount,i.memory.geometries--}function d(_,y){return l[y.id]===!0||(y.addEventListener("dispose",h),l[y.id]=!0,i.memory.geometries++),y}function m(_){const y=_.attributes;for(const v in y)t.update(y[v],r.ARRAY_BUFFER)}function p(_){const y=[],v=_.index,b=_.attributes.position;let E=0;if(v!==null){const P=v.array;E=v.version;for(let N=0,w=P.length;N<w;N+=3){const k=P[N+0],H=P[N+1],I=P[N+2];y.push(k,H,H,I,I,k)}}else if(b!==void 0){const P=b.array;E=b.version;for(let N=0,w=P.length/3-1;N<w;N+=3){const k=N+0,H=N+1,I=N+2;y.push(k,H,H,I,I,k)}}else return;const M=new(gv(y)?Sv:yv)(y,1);M.version=E;const x=c.get(_);x&&t.remove(x),c.set(_,M)}function g(_){const y=c.get(_);if(y){const v=_.index;v!==null&&y.version<v.version&&p(_)}else p(_);return c.get(_)}return{get:d,update:m,getWireframeAttribute:g}}function OE(r,t,i){let s;function l(y){s=y}let c,h;function d(y){c=y.type,h=y.bytesPerElement}function m(y,v){r.drawElements(s,v,c,y*h),i.update(v,s,1)}function p(y,v,b){b!==0&&(r.drawElementsInstanced(s,v,c,y*h,b),i.update(v,s,b))}function g(y,v,b){if(b===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(s,v,0,c,y,0,b);let M=0;for(let x=0;x<b;x++)M+=v[x];i.update(M,s,1)}function _(y,v,b,E){if(b===0)return;const M=t.get("WEBGL_multi_draw");if(M===null)for(let x=0;x<y.length;x++)p(y[x]/h,v[x],E[x]);else{M.multiDrawElementsInstancedWEBGL(s,v,0,c,y,0,E,0,b);let x=0;for(let P=0;P<b;P++)x+=v[P]*E[P];i.update(x,s,1)}}this.setMode=l,this.setIndex=d,this.render=m,this.renderInstances=p,this.renderMultiDraw=g,this.renderMultiDrawInstances=_}function PE(r){const t={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function s(c,h,d){switch(i.calls++,h){case r.TRIANGLES:i.triangles+=d*(c/3);break;case r.LINES:i.lines+=d*(c/2);break;case r.LINE_STRIP:i.lines+=d*(c-1);break;case r.LINE_LOOP:i.lines+=d*c;break;case r.POINTS:i.points+=d*c;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",h);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:t,render:i,programs:null,autoReset:!0,reset:l,update:s}}function zE(r,t,i){const s=new WeakMap,l=new an;function c(h,d,m){const p=h.morphTargetInfluences,g=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,_=g!==void 0?g.length:0;let y=s.get(d);if(y===void 0||y.count!==_){let R=function(){j.dispose(),s.delete(d),d.removeEventListener("dispose",R)};var v=R;y!==void 0&&y.texture.dispose();const b=d.morphAttributes.position!==void 0,E=d.morphAttributes.normal!==void 0,M=d.morphAttributes.color!==void 0,x=d.morphAttributes.position||[],P=d.morphAttributes.normal||[],N=d.morphAttributes.color||[];let w=0;b===!0&&(w=1),E===!0&&(w=2),M===!0&&(w=3);let k=d.attributes.position.count*w,H=1;k>t.maxTextureSize&&(H=Math.ceil(k/t.maxTextureSize),k=t.maxTextureSize);const I=new Float32Array(k*H*4*_),j=new _v(I,k,H,_);j.type=fa,j.needsUpdate=!0;const L=w*4;for(let B=0;B<_;B++){const tt=x[B],et=P[B],ut=N[B],ft=k*H*4*B;for(let z=0;z<tt.count;z++){const W=z*L;b===!0&&(l.fromBufferAttribute(tt,z),I[ft+W+0]=l.x,I[ft+W+1]=l.y,I[ft+W+2]=l.z,I[ft+W+3]=0),E===!0&&(l.fromBufferAttribute(et,z),I[ft+W+4]=l.x,I[ft+W+5]=l.y,I[ft+W+6]=l.z,I[ft+W+7]=0),M===!0&&(l.fromBufferAttribute(ut,z),I[ft+W+8]=l.x,I[ft+W+9]=l.y,I[ft+W+10]=l.z,I[ft+W+11]=ut.itemSize===4?l.w:1)}}y={count:_,texture:j,size:new se(k,H)},s.set(d,y),d.addEventListener("dispose",R)}if(h.isInstancedMesh===!0&&h.morphTexture!==null)m.getUniforms().setValue(r,"morphTexture",h.morphTexture,i);else{let b=0;for(let M=0;M<p.length;M++)b+=p[M];const E=d.morphTargetsRelative?1:1-b;m.getUniforms().setValue(r,"morphTargetBaseInfluence",E),m.getUniforms().setValue(r,"morphTargetInfluences",p)}m.getUniforms().setValue(r,"morphTargetsTexture",y.texture,i),m.getUniforms().setValue(r,"morphTargetsTextureSize",y.size)}return{update:c}}function IE(r,t,i,s){let l=new WeakMap;function c(m){const p=s.render.frame,g=m.geometry,_=t.get(m,g);if(l.get(_)!==p&&(t.update(_),l.set(_,p)),m.isInstancedMesh&&(m.hasEventListener("dispose",d)===!1&&m.addEventListener("dispose",d),l.get(m)!==p&&(i.update(m.instanceMatrix,r.ARRAY_BUFFER),m.instanceColor!==null&&i.update(m.instanceColor,r.ARRAY_BUFFER),l.set(m,p))),m.isSkinnedMesh){const y=m.skeleton;l.get(y)!==p&&(y.update(),l.set(y,p))}return _}function h(){l=new WeakMap}function d(m){const p=m.target;p.removeEventListener("dispose",d),i.remove(p.instanceMatrix),p.instanceColor!==null&&i.remove(p.instanceColor)}return{update:c,dispose:h}}const wv=new Hn,U_=new Av(1,1),Dv=new _v,Lv=new s1,Uv=new Ev,N_=[],O_=[],P_=new Float32Array(16),z_=new Float32Array(9),I_=new Float32Array(4);function jr(r,t,i){const s=r[0];if(s<=0||s>0)return r;const l=t*i;let c=N_[l];if(c===void 0&&(c=new Float32Array(l),N_[l]=c),t!==0){s.toArray(c,0);for(let h=1,d=0;h!==t;++h)d+=i,r[h].toArray(c,d)}return c}function _n(r,t){if(r.length!==t.length)return!1;for(let i=0,s=r.length;i<s;i++)if(r[i]!==t[i])return!1;return!0}function vn(r,t){for(let i=0,s=t.length;i<s;i++)r[i]=t[i]}function nu(r,t){let i=O_[t];i===void 0&&(i=new Int32Array(t),O_[t]=i);for(let s=0;s!==t;++s)i[s]=r.allocateTextureUnit();return i}function BE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1f(this.addr,t),i[0]=t)}function FE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2fv(this.addr,t),vn(i,t)}}function HE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else if(t.r!==void 0)(i[0]!==t.r||i[1]!==t.g||i[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),i[0]=t.r,i[1]=t.g,i[2]=t.b);else{if(_n(i,t))return;r.uniform3fv(this.addr,t),vn(i,t)}}function GE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4fv(this.addr,t),vn(i,t)}}function VE(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix2fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;I_.set(s),r.uniformMatrix2fv(this.addr,!1,I_),vn(i,s)}}function kE(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix3fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;z_.set(s),r.uniformMatrix3fv(this.addr,!1,z_),vn(i,s)}}function jE(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix4fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;P_.set(s),r.uniformMatrix4fv(this.addr,!1,P_),vn(i,s)}}function XE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1i(this.addr,t),i[0]=t)}function WE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2iv(this.addr,t),vn(i,t)}}function qE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(_n(i,t))return;r.uniform3iv(this.addr,t),vn(i,t)}}function YE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4iv(this.addr,t),vn(i,t)}}function ZE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1ui(this.addr,t),i[0]=t)}function KE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2uiv(this.addr,t),vn(i,t)}}function QE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(_n(i,t))return;r.uniform3uiv(this.addr,t),vn(i,t)}}function JE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4uiv(this.addr,t),vn(i,t)}}function $E(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l);let c;this.type===r.SAMPLER_2D_SHADOW?(U_.compareFunction=mv,c=U_):c=wv,i.setTexture2D(t||c,l)}function tT(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture3D(t||Lv,l)}function eT(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTextureCube(t||Uv,l)}function nT(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture2DArray(t||Dv,l)}function iT(r){switch(r){case 5126:return BE;case 35664:return FE;case 35665:return HE;case 35666:return GE;case 35674:return VE;case 35675:return kE;case 35676:return jE;case 5124:case 35670:return XE;case 35667:case 35671:return WE;case 35668:case 35672:return qE;case 35669:case 35673:return YE;case 5125:return ZE;case 36294:return KE;case 36295:return QE;case 36296:return JE;case 35678:case 36198:case 36298:case 36306:case 35682:return $E;case 35679:case 36299:case 36307:return tT;case 35680:case 36300:case 36308:case 36293:return eT;case 36289:case 36303:case 36311:case 36292:return nT}}function aT(r,t){r.uniform1fv(this.addr,t)}function sT(r,t){const i=jr(t,this.size,2);r.uniform2fv(this.addr,i)}function rT(r,t){const i=jr(t,this.size,3);r.uniform3fv(this.addr,i)}function oT(r,t){const i=jr(t,this.size,4);r.uniform4fv(this.addr,i)}function lT(r,t){const i=jr(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,i)}function cT(r,t){const i=jr(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,i)}function uT(r,t){const i=jr(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,i)}function fT(r,t){r.uniform1iv(this.addr,t)}function hT(r,t){r.uniform2iv(this.addr,t)}function dT(r,t){r.uniform3iv(this.addr,t)}function pT(r,t){r.uniform4iv(this.addr,t)}function mT(r,t){r.uniform1uiv(this.addr,t)}function gT(r,t){r.uniform2uiv(this.addr,t)}function _T(r,t){r.uniform3uiv(this.addr,t)}function vT(r,t){r.uniform4uiv(this.addr,t)}function xT(r,t,i){const s=this.cache,l=t.length,c=nu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let h=0;h!==l;++h)i.setTexture2D(t[h]||wv,c[h])}function yT(r,t,i){const s=this.cache,l=t.length,c=nu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let h=0;h!==l;++h)i.setTexture3D(t[h]||Lv,c[h])}function ST(r,t,i){const s=this.cache,l=t.length,c=nu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let h=0;h!==l;++h)i.setTextureCube(t[h]||Uv,c[h])}function MT(r,t,i){const s=this.cache,l=t.length,c=nu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let h=0;h!==l;++h)i.setTexture2DArray(t[h]||Dv,c[h])}function bT(r){switch(r){case 5126:return aT;case 35664:return sT;case 35665:return rT;case 35666:return oT;case 35674:return lT;case 35675:return cT;case 35676:return uT;case 5124:case 35670:return fT;case 35667:case 35671:return hT;case 35668:case 35672:return dT;case 35669:case 35673:return pT;case 5125:return mT;case 36294:return gT;case 36295:return _T;case 36296:return vT;case 35678:case 36198:case 36298:case 36306:case 35682:return xT;case 35679:case 36299:case 36307:return yT;case 35680:case 36300:case 36308:case 36293:return ST;case 36289:case 36303:case 36311:case 36292:return MT}}class ET{constructor(t,i,s){this.id=t,this.addr=s,this.cache=[],this.type=i.type,this.setValue=iT(i.type)}}class TT{constructor(t,i,s){this.id=t,this.addr=s,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=bT(i.type)}}class AT{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,i,s){const l=this.seq;for(let c=0,h=l.length;c!==h;++c){const d=l[c];d.setValue(t,i[d.id],s)}}}const qh=/(\w+)(\])?(\[|\.)?/g;function B_(r,t){r.seq.push(t),r.map[t.id]=t}function RT(r,t,i){const s=r.name,l=s.length;for(qh.lastIndex=0;;){const c=qh.exec(s),h=qh.lastIndex;let d=c[1];const m=c[2]==="]",p=c[3];if(m&&(d=d|0),p===void 0||p==="["&&h+2===l){B_(i,p===void 0?new ET(d,r,t):new TT(d,r,t));break}else{let _=i.map[d];_===void 0&&(_=new AT(d),B_(i,_)),i=_}}}class jc{constructor(t,i){this.seq=[],this.map={};const s=t.getProgramParameter(i,t.ACTIVE_UNIFORMS);for(let l=0;l<s;++l){const c=t.getActiveUniform(i,l),h=t.getUniformLocation(i,c.name);RT(c,h,this)}}setValue(t,i,s,l){const c=this.map[i];c!==void 0&&c.setValue(t,s,l)}setOptional(t,i,s){const l=i[s];l!==void 0&&this.setValue(t,s,l)}static upload(t,i,s,l){for(let c=0,h=i.length;c!==h;++c){const d=i[c],m=s[d.id];m.needsUpdate!==!1&&d.setValue(t,m.value,l)}}static seqWithValue(t,i){const s=[];for(let l=0,c=t.length;l!==c;++l){const h=t[l];h.id in i&&s.push(h)}return s}}function F_(r,t,i){const s=r.createShader(t);return r.shaderSource(s,i),r.compileShader(s),s}const CT=37297;let wT=0;function DT(r,t){const i=r.split(`
`),s=[],l=Math.max(t-6,0),c=Math.min(t+6,i.length);for(let h=l;h<c;h++){const d=h+1;s.push(`${d===t?">":" "} ${d}: ${i[h]}`)}return s.join(`
`)}const H_=new ue;function LT(r){De._getMatrix(H_,De.workingColorSpace,r);const t=`mat3( ${H_.elements.map(i=>i.toFixed(4))} )`;switch(De.getTransfer(r)){case Wc:return[t,"LinearTransferOETF"];case Ve:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function G_(r,t,i){const s=r.getShaderParameter(t,r.COMPILE_STATUS),l=r.getShaderInfoLog(t).trim();if(s&&l==="")return"";const c=/ERROR: 0:(\d+)/.exec(l);if(c){const h=parseInt(c[1]);return i.toUpperCase()+`

`+l+`

`+DT(r.getShaderSource(t),h)}else return l}function UT(r,t){const i=LT(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}function NT(r,t){let i;switch(t){case LS:i="Linear";break;case US:i="Reinhard";break;case NS:i="Cineon";break;case nv:i="ACESFilmic";break;case PS:i="AgX";break;case zS:i="Neutral";break;case OS:i="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),i="Linear"}return"vec3 "+r+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Pc=new J;function OT(){De.getLuminanceCoefficients(Pc);const r=Pc.x.toFixed(4),t=Pc.y.toFixed(4),i=Pc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function PT(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Yo).join(`
`)}function zT(r){const t=[];for(const i in r){const s=r[i];s!==!1&&t.push("#define "+i+" "+s)}return t.join(`
`)}function IT(r,t){const i={},s=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let l=0;l<s;l++){const c=r.getActiveAttrib(t,l),h=c.name;let d=1;c.type===r.FLOAT_MAT2&&(d=2),c.type===r.FLOAT_MAT3&&(d=3),c.type===r.FLOAT_MAT4&&(d=4),i[h]={type:c.type,location:r.getAttribLocation(t,h),locationSize:d}}return i}function Yo(r){return r!==""}function V_(r,t){const i=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function k_(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const BT=/^[ \t]*#include +<([\w\d./]+)>/gm;function Id(r){return r.replace(BT,HT)}const FT=new Map;function HT(r,t){let i=he[t];if(i===void 0){const s=FT.get(t);if(s!==void 0)i=he[s],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,s);else throw new Error("Can not resolve #include <"+t+">")}return Id(i)}const GT=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function j_(r){return r.replace(GT,VT)}function VT(r,t,i,s){let l="";for(let c=parseInt(t);c<parseInt(i);c++)l+=s.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function X_(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function kT(r){let t="SHADOWMAP_TYPE_BASIC";return r.shadowMapType===tv?t="SHADOWMAP_TYPE_PCF":r.shadowMapType===uS?t="SHADOWMAP_TYPE_PCF_SOFT":r.shadowMapType===ua&&(t="SHADOWMAP_TYPE_VSM"),t}function jT(r){let t="ENVMAP_TYPE_CUBE";if(r.envMap)switch(r.envMapMode){case Br:case Fr:t="ENVMAP_TYPE_CUBE";break;case $c:t="ENVMAP_TYPE_CUBE_UV";break}return t}function XT(r){let t="ENVMAP_MODE_REFLECTION";if(r.envMap)switch(r.envMapMode){case Fr:t="ENVMAP_MODE_REFRACTION";break}return t}function WT(r){let t="ENVMAP_BLENDING_NONE";if(r.envMap)switch(r.combine){case ev:t="ENVMAP_BLENDING_MULTIPLY";break;case wS:t="ENVMAP_BLENDING_MIX";break;case DS:t="ENVMAP_BLENDING_ADD";break}return t}function qT(r){const t=r.envMapCubeUVHeight;if(t===null)return null;const i=Math.log2(t)-2,s=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:s,maxMip:i}}function YT(r,t,i,s){const l=r.getContext(),c=i.defines;let h=i.vertexShader,d=i.fragmentShader;const m=kT(i),p=jT(i),g=XT(i),_=WT(i),y=qT(i),v=PT(i),b=zT(c),E=l.createProgram();let M,x,P=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(M=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(Yo).join(`
`),M.length>0&&(M+=`
`),x=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(Yo).join(`
`),x.length>0&&(x+=`
`)):(M=[X_(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+g:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",i.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Yo).join(`
`),x=[X_(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+p:"",i.envMap?"#define "+g:"",i.envMap?"#define "+_:"",y?"#define CUBEUV_TEXEL_WIDTH "+y.texelWidth:"",y?"#define CUBEUV_TEXEL_HEIGHT "+y.texelHeight:"",y?"#define CUBEUV_MAX_MIP "+y.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor||i.batchingColor?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",i.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==Ka?"#define TONE_MAPPING":"",i.toneMapping!==Ka?he.tonemapping_pars_fragment:"",i.toneMapping!==Ka?NT("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",he.colorspace_pars_fragment,UT("linearToOutputTexel",i.outputColorSpace),OT(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(Yo).join(`
`)),h=Id(h),h=V_(h,i),h=k_(h,i),d=Id(d),d=V_(d,i),d=k_(d,i),h=j_(h),d=j_(d),i.isRawShaderMaterial!==!0&&(P=`#version 300 es
`,M=[v,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+M,x=["#define varying in",i.glslVersion===K0?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===K0?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const N=P+M+h,w=P+x+d,k=F_(l,l.VERTEX_SHADER,N),H=F_(l,l.FRAGMENT_SHADER,w);l.attachShader(E,k),l.attachShader(E,H),i.index0AttributeName!==void 0?l.bindAttribLocation(E,0,i.index0AttributeName):i.morphTargets===!0&&l.bindAttribLocation(E,0,"position"),l.linkProgram(E);function I(B){if(r.debug.checkShaderErrors){const tt=l.getProgramInfoLog(E).trim(),et=l.getShaderInfoLog(k).trim(),ut=l.getShaderInfoLog(H).trim();let ft=!0,z=!0;if(l.getProgramParameter(E,l.LINK_STATUS)===!1)if(ft=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(l,E,k,H);else{const W=G_(l,k,"vertex"),X=G_(l,H,"fragment");console.error("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(E,l.VALIDATE_STATUS)+`

Material Name: `+B.name+`
Material Type: `+B.type+`

Program Info Log: `+tt+`
`+W+`
`+X)}else tt!==""?console.warn("THREE.WebGLProgram: Program Info Log:",tt):(et===""||ut==="")&&(z=!1);z&&(B.diagnostics={runnable:ft,programLog:tt,vertexShader:{log:et,prefix:M},fragmentShader:{log:ut,prefix:x}})}l.deleteShader(k),l.deleteShader(H),j=new jc(l,E),L=IT(l,E)}let j;this.getUniforms=function(){return j===void 0&&I(this),j};let L;this.getAttributes=function(){return L===void 0&&I(this),L};let R=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return R===!1&&(R=l.getProgramParameter(E,CT)),R},this.destroy=function(){s.releaseStatesOfProgram(this),l.deleteProgram(E),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=wT++,this.cacheKey=t,this.usedTimes=1,this.program=E,this.vertexShader=k,this.fragmentShader=H,this}let ZT=0;class KT{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const i=t.vertexShader,s=t.fragmentShader,l=this._getShaderStage(i),c=this._getShaderStage(s),h=this._getShaderCacheForMaterial(t);return h.has(l)===!1&&(h.add(l),l.usedTimes++),h.has(c)===!1&&(h.add(c),c.usedTimes++),this}remove(t){const i=this.materialCache.get(t);for(const s of i)s.usedTimes--,s.usedTimes===0&&this.shaderCache.delete(s.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const i=this.materialCache;let s=i.get(t);return s===void 0&&(s=new Set,i.set(t,s)),s}_getShaderStage(t){const i=this.shaderCache;let s=i.get(t);return s===void 0&&(s=new QT(t),i.set(t,s)),s}}class QT{constructor(t){this.id=ZT++,this.code=t,this.usedTimes=0}}function JT(r,t,i,s,l,c,h){const d=new vv,m=new KT,p=new Set,g=[],_=l.logarithmicDepthBuffer,y=l.vertexTextures;let v=l.precision;const b={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function E(L){return p.add(L),L===0?"uv":`uv${L}`}function M(L,R,B,tt,et){const ut=tt.fog,ft=et.geometry,z=L.isMeshStandardMaterial?tt.environment:null,W=(L.isMeshStandardMaterial?i:t).get(L.envMap||z),X=W&&W.mapping===$c?W.image.height:null,_t=b[L.type];L.precision!==null&&(v=l.getMaxPrecision(L.precision),v!==L.precision&&console.warn("THREE.WebGLProgram.getParameters:",L.precision,"not supported, using",v,"instead."));const Et=ft.morphAttributes.position||ft.morphAttributes.normal||ft.morphAttributes.color,O=Et!==void 0?Et.length:0;let at=0;ft.morphAttributes.position!==void 0&&(at=1),ft.morphAttributes.normal!==void 0&&(at=2),ft.morphAttributes.color!==void 0&&(at=3);let vt,Y,st,xt;if(_t){const Te=zi[_t];vt=Te.vertexShader,Y=Te.fragmentShader}else vt=L.vertexShader,Y=L.fragmentShader,m.update(L),st=m.getVertexShaderID(L),xt=m.getFragmentShaderID(L);const bt=r.getRenderTarget(),Ft=r.state.buffers.depth.getReversed(),Xt=et.isInstancedMesh===!0,Yt=et.isBatchedMesh===!0,ze=!!L.map,Ue=!!L.matcap,fe=!!W,G=!!L.aoMap,Je=!!L.lightMap,le=!!L.bumpMap,de=!!L.normalMap,kt=!!L.displacementMap,Ae=!!L.emissiveMap,Rt=!!L.metalnessMap,U=!!L.roughnessMap,T=L.anisotropy>0,$=L.clearcoat>0,dt=L.dispersion>0,St=L.iridescence>0,mt=L.sheen>0,Bt=L.transmission>0,Ct=T&&!!L.anisotropyMap,It=$&&!!L.clearcoatMap,pe=$&&!!L.clearcoatNormalMap,At=$&&!!L.clearcoatRoughnessMap,Ht=St&&!!L.iridescenceMap,Kt=St&&!!L.iridescenceThicknessMap,jt=mt&&!!L.sheenColorMap,Pt=mt&&!!L.sheenRoughnessMap,Jt=!!L.specularMap,re=!!L.specularColorMap,Ie=!!L.specularIntensityMap,Z=Bt&&!!L.transmissionMap,wt=Bt&&!!L.thicknessMap,ht=!!L.gradientMap,Mt=!!L.alphaMap,Dt=L.alphaTest>0,Lt=!!L.alphaHash,$t=!!L.extensions;let Ye=Ka;L.toneMapped&&(bt===null||bt.isXRRenderTarget===!0)&&(Ye=r.toneMapping);const hn={shaderID:_t,shaderType:L.type,shaderName:L.name,vertexShader:vt,fragmentShader:Y,defines:L.defines,customVertexShaderID:st,customFragmentShaderID:xt,isRawShaderMaterial:L.isRawShaderMaterial===!0,glslVersion:L.glslVersion,precision:v,batching:Yt,batchingColor:Yt&&et._colorsTexture!==null,instancing:Xt,instancingColor:Xt&&et.instanceColor!==null,instancingMorph:Xt&&et.morphTexture!==null,supportsVertexTextures:y,outputColorSpace:bt===null?r.outputColorSpace:bt.isXRRenderTarget===!0?bt.texture.colorSpace:Vr,alphaToCoverage:!!L.alphaToCoverage,map:ze,matcap:Ue,envMap:fe,envMapMode:fe&&W.mapping,envMapCubeUVHeight:X,aoMap:G,lightMap:Je,bumpMap:le,normalMap:de,displacementMap:y&&kt,emissiveMap:Ae,normalMapObjectSpace:de&&L.normalMapType===HS,normalMapTangentSpace:de&&L.normalMapType===pv,metalnessMap:Rt,roughnessMap:U,anisotropy:T,anisotropyMap:Ct,clearcoat:$,clearcoatMap:It,clearcoatNormalMap:pe,clearcoatRoughnessMap:At,dispersion:dt,iridescence:St,iridescenceMap:Ht,iridescenceThicknessMap:Kt,sheen:mt,sheenColorMap:jt,sheenRoughnessMap:Pt,specularMap:Jt,specularColorMap:re,specularIntensityMap:Ie,transmission:Bt,transmissionMap:Z,thicknessMap:wt,gradientMap:ht,opaque:L.transparent===!1&&L.blending===Ur&&L.alphaToCoverage===!1,alphaMap:Mt,alphaTest:Dt,alphaHash:Lt,combine:L.combine,mapUv:ze&&E(L.map.channel),aoMapUv:G&&E(L.aoMap.channel),lightMapUv:Je&&E(L.lightMap.channel),bumpMapUv:le&&E(L.bumpMap.channel),normalMapUv:de&&E(L.normalMap.channel),displacementMapUv:kt&&E(L.displacementMap.channel),emissiveMapUv:Ae&&E(L.emissiveMap.channel),metalnessMapUv:Rt&&E(L.metalnessMap.channel),roughnessMapUv:U&&E(L.roughnessMap.channel),anisotropyMapUv:Ct&&E(L.anisotropyMap.channel),clearcoatMapUv:It&&E(L.clearcoatMap.channel),clearcoatNormalMapUv:pe&&E(L.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:At&&E(L.clearcoatRoughnessMap.channel),iridescenceMapUv:Ht&&E(L.iridescenceMap.channel),iridescenceThicknessMapUv:Kt&&E(L.iridescenceThicknessMap.channel),sheenColorMapUv:jt&&E(L.sheenColorMap.channel),sheenRoughnessMapUv:Pt&&E(L.sheenRoughnessMap.channel),specularMapUv:Jt&&E(L.specularMap.channel),specularColorMapUv:re&&E(L.specularColorMap.channel),specularIntensityMapUv:Ie&&E(L.specularIntensityMap.channel),transmissionMapUv:Z&&E(L.transmissionMap.channel),thicknessMapUv:wt&&E(L.thicknessMap.channel),alphaMapUv:Mt&&E(L.alphaMap.channel),vertexTangents:!!ft.attributes.tangent&&(de||T),vertexColors:L.vertexColors,vertexAlphas:L.vertexColors===!0&&!!ft.attributes.color&&ft.attributes.color.itemSize===4,pointsUvs:et.isPoints===!0&&!!ft.attributes.uv&&(ze||Mt),fog:!!ut,useFog:L.fog===!0,fogExp2:!!ut&&ut.isFogExp2,flatShading:L.flatShading===!0,sizeAttenuation:L.sizeAttenuation===!0,logarithmicDepthBuffer:_,reverseDepthBuffer:Ft,skinning:et.isSkinnedMesh===!0,morphTargets:ft.morphAttributes.position!==void 0,morphNormals:ft.morphAttributes.normal!==void 0,morphColors:ft.morphAttributes.color!==void 0,morphTargetsCount:O,morphTextureStride:at,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numClippingPlanes:h.numPlanes,numClipIntersection:h.numIntersection,dithering:L.dithering,shadowMapEnabled:r.shadowMap.enabled&&B.length>0,shadowMapType:r.shadowMap.type,toneMapping:Ye,decodeVideoTexture:ze&&L.map.isVideoTexture===!0&&De.getTransfer(L.map.colorSpace)===Ve,decodeVideoTextureEmissive:Ae&&L.emissiveMap.isVideoTexture===!0&&De.getTransfer(L.emissiveMap.colorSpace)===Ve,premultipliedAlpha:L.premultipliedAlpha,doubleSided:L.side===li,flipSided:L.side===Fn,useDepthPacking:L.depthPacking>=0,depthPacking:L.depthPacking||0,index0AttributeName:L.index0AttributeName,extensionClipCullDistance:$t&&L.extensions.clipCullDistance===!0&&s.has("WEBGL_clip_cull_distance"),extensionMultiDraw:($t&&L.extensions.multiDraw===!0||Yt)&&s.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:s.has("KHR_parallel_shader_compile"),customProgramCacheKey:L.customProgramCacheKey()};return hn.vertexUv1s=p.has(1),hn.vertexUv2s=p.has(2),hn.vertexUv3s=p.has(3),p.clear(),hn}function x(L){const R=[];if(L.shaderID?R.push(L.shaderID):(R.push(L.customVertexShaderID),R.push(L.customFragmentShaderID)),L.defines!==void 0)for(const B in L.defines)R.push(B),R.push(L.defines[B]);return L.isRawShaderMaterial===!1&&(P(R,L),N(R,L),R.push(r.outputColorSpace)),R.push(L.customProgramCacheKey),R.join()}function P(L,R){L.push(R.precision),L.push(R.outputColorSpace),L.push(R.envMapMode),L.push(R.envMapCubeUVHeight),L.push(R.mapUv),L.push(R.alphaMapUv),L.push(R.lightMapUv),L.push(R.aoMapUv),L.push(R.bumpMapUv),L.push(R.normalMapUv),L.push(R.displacementMapUv),L.push(R.emissiveMapUv),L.push(R.metalnessMapUv),L.push(R.roughnessMapUv),L.push(R.anisotropyMapUv),L.push(R.clearcoatMapUv),L.push(R.clearcoatNormalMapUv),L.push(R.clearcoatRoughnessMapUv),L.push(R.iridescenceMapUv),L.push(R.iridescenceThicknessMapUv),L.push(R.sheenColorMapUv),L.push(R.sheenRoughnessMapUv),L.push(R.specularMapUv),L.push(R.specularColorMapUv),L.push(R.specularIntensityMapUv),L.push(R.transmissionMapUv),L.push(R.thicknessMapUv),L.push(R.combine),L.push(R.fogExp2),L.push(R.sizeAttenuation),L.push(R.morphTargetsCount),L.push(R.morphAttributeCount),L.push(R.numDirLights),L.push(R.numPointLights),L.push(R.numSpotLights),L.push(R.numSpotLightMaps),L.push(R.numHemiLights),L.push(R.numRectAreaLights),L.push(R.numDirLightShadows),L.push(R.numPointLightShadows),L.push(R.numSpotLightShadows),L.push(R.numSpotLightShadowsWithMaps),L.push(R.numLightProbes),L.push(R.shadowMapType),L.push(R.toneMapping),L.push(R.numClippingPlanes),L.push(R.numClipIntersection),L.push(R.depthPacking)}function N(L,R){d.disableAll(),R.supportsVertexTextures&&d.enable(0),R.instancing&&d.enable(1),R.instancingColor&&d.enable(2),R.instancingMorph&&d.enable(3),R.matcap&&d.enable(4),R.envMap&&d.enable(5),R.normalMapObjectSpace&&d.enable(6),R.normalMapTangentSpace&&d.enable(7),R.clearcoat&&d.enable(8),R.iridescence&&d.enable(9),R.alphaTest&&d.enable(10),R.vertexColors&&d.enable(11),R.vertexAlphas&&d.enable(12),R.vertexUv1s&&d.enable(13),R.vertexUv2s&&d.enable(14),R.vertexUv3s&&d.enable(15),R.vertexTangents&&d.enable(16),R.anisotropy&&d.enable(17),R.alphaHash&&d.enable(18),R.batching&&d.enable(19),R.dispersion&&d.enable(20),R.batchingColor&&d.enable(21),L.push(d.mask),d.disableAll(),R.fog&&d.enable(0),R.useFog&&d.enable(1),R.flatShading&&d.enable(2),R.logarithmicDepthBuffer&&d.enable(3),R.reverseDepthBuffer&&d.enable(4),R.skinning&&d.enable(5),R.morphTargets&&d.enable(6),R.morphNormals&&d.enable(7),R.morphColors&&d.enable(8),R.premultipliedAlpha&&d.enable(9),R.shadowMapEnabled&&d.enable(10),R.doubleSided&&d.enable(11),R.flipSided&&d.enable(12),R.useDepthPacking&&d.enable(13),R.dithering&&d.enable(14),R.transmission&&d.enable(15),R.sheen&&d.enable(16),R.opaque&&d.enable(17),R.pointsUvs&&d.enable(18),R.decodeVideoTexture&&d.enable(19),R.decodeVideoTextureEmissive&&d.enable(20),R.alphaToCoverage&&d.enable(21),L.push(d.mask)}function w(L){const R=b[L.type];let B;if(R){const tt=zi[R];B=v1.clone(tt.uniforms)}else B=L.uniforms;return B}function k(L,R){let B;for(let tt=0,et=g.length;tt<et;tt++){const ut=g[tt];if(ut.cacheKey===R){B=ut,++B.usedTimes;break}}return B===void 0&&(B=new YT(r,R,L,c),g.push(B)),B}function H(L){if(--L.usedTimes===0){const R=g.indexOf(L);g[R]=g[g.length-1],g.pop(),L.destroy()}}function I(L){m.remove(L)}function j(){m.dispose()}return{getParameters:M,getProgramCacheKey:x,getUniforms:w,acquireProgram:k,releaseProgram:H,releaseShaderCache:I,programs:g,dispose:j}}function $T(){let r=new WeakMap;function t(h){return r.has(h)}function i(h){let d=r.get(h);return d===void 0&&(d={},r.set(h,d)),d}function s(h){r.delete(h)}function l(h,d,m){r.get(h)[d]=m}function c(){r=new WeakMap}return{has:t,get:i,remove:s,update:l,dispose:c}}function t2(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.z!==t.z?r.z-t.z:r.id-t.id}function W_(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function q_(){const r=[];let t=0;const i=[],s=[],l=[];function c(){t=0,i.length=0,s.length=0,l.length=0}function h(_,y,v,b,E,M){let x=r[t];return x===void 0?(x={id:_.id,object:_,geometry:y,material:v,groupOrder:b,renderOrder:_.renderOrder,z:E,group:M},r[t]=x):(x.id=_.id,x.object=_,x.geometry=y,x.material=v,x.groupOrder=b,x.renderOrder=_.renderOrder,x.z=E,x.group=M),t++,x}function d(_,y,v,b,E,M){const x=h(_,y,v,b,E,M);v.transmission>0?s.push(x):v.transparent===!0?l.push(x):i.push(x)}function m(_,y,v,b,E,M){const x=h(_,y,v,b,E,M);v.transmission>0?s.unshift(x):v.transparent===!0?l.unshift(x):i.unshift(x)}function p(_,y){i.length>1&&i.sort(_||t2),s.length>1&&s.sort(y||W_),l.length>1&&l.sort(y||W_)}function g(){for(let _=t,y=r.length;_<y;_++){const v=r[_];if(v.id===null)break;v.id=null,v.object=null,v.geometry=null,v.material=null,v.group=null}}return{opaque:i,transmissive:s,transparent:l,init:c,push:d,unshift:m,finish:g,sort:p}}function e2(){let r=new WeakMap;function t(s,l){const c=r.get(s);let h;return c===void 0?(h=new q_,r.set(s,[h])):l>=c.length?(h=new q_,c.push(h)):h=c[l],h}function i(){r=new WeakMap}return{get:t,dispose:i}}function n2(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={direction:new J,color:new be};break;case"SpotLight":i={position:new J,direction:new J,color:new be,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new J,color:new be,distance:0,decay:0};break;case"HemisphereLight":i={direction:new J,skyColor:new be,groundColor:new be};break;case"RectAreaLight":i={color:new be,position:new J,halfWidth:new J,halfHeight:new J};break}return r[t.id]=i,i}}}function i2(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=i,i}}}let a2=0;function s2(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function r2(r){const t=new n2,i=i2(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let p=0;p<9;p++)s.probe.push(new J);const l=new J,c=new Ke,h=new Ke;function d(p){let g=0,_=0,y=0;for(let L=0;L<9;L++)s.probe[L].set(0,0,0);let v=0,b=0,E=0,M=0,x=0,P=0,N=0,w=0,k=0,H=0,I=0;p.sort(s2);for(let L=0,R=p.length;L<R;L++){const B=p[L],tt=B.color,et=B.intensity,ut=B.distance,ft=B.shadow&&B.shadow.map?B.shadow.map.texture:null;if(B.isAmbientLight)g+=tt.r*et,_+=tt.g*et,y+=tt.b*et;else if(B.isLightProbe){for(let z=0;z<9;z++)s.probe[z].addScaledVector(B.sh.coefficients[z],et);I++}else if(B.isDirectionalLight){const z=t.get(B);if(z.color.copy(B.color).multiplyScalar(B.intensity),B.castShadow){const W=B.shadow,X=i.get(B);X.shadowIntensity=W.intensity,X.shadowBias=W.bias,X.shadowNormalBias=W.normalBias,X.shadowRadius=W.radius,X.shadowMapSize=W.mapSize,s.directionalShadow[v]=X,s.directionalShadowMap[v]=ft,s.directionalShadowMatrix[v]=B.shadow.matrix,P++}s.directional[v]=z,v++}else if(B.isSpotLight){const z=t.get(B);z.position.setFromMatrixPosition(B.matrixWorld),z.color.copy(tt).multiplyScalar(et),z.distance=ut,z.coneCos=Math.cos(B.angle),z.penumbraCos=Math.cos(B.angle*(1-B.penumbra)),z.decay=B.decay,s.spot[E]=z;const W=B.shadow;if(B.map&&(s.spotLightMap[k]=B.map,k++,W.updateMatrices(B),B.castShadow&&H++),s.spotLightMatrix[E]=W.matrix,B.castShadow){const X=i.get(B);X.shadowIntensity=W.intensity,X.shadowBias=W.bias,X.shadowNormalBias=W.normalBias,X.shadowRadius=W.radius,X.shadowMapSize=W.mapSize,s.spotShadow[E]=X,s.spotShadowMap[E]=ft,w++}E++}else if(B.isRectAreaLight){const z=t.get(B);z.color.copy(tt).multiplyScalar(et),z.halfWidth.set(B.width*.5,0,0),z.halfHeight.set(0,B.height*.5,0),s.rectArea[M]=z,M++}else if(B.isPointLight){const z=t.get(B);if(z.color.copy(B.color).multiplyScalar(B.intensity),z.distance=B.distance,z.decay=B.decay,B.castShadow){const W=B.shadow,X=i.get(B);X.shadowIntensity=W.intensity,X.shadowBias=W.bias,X.shadowNormalBias=W.normalBias,X.shadowRadius=W.radius,X.shadowMapSize=W.mapSize,X.shadowCameraNear=W.camera.near,X.shadowCameraFar=W.camera.far,s.pointShadow[b]=X,s.pointShadowMap[b]=ft,s.pointShadowMatrix[b]=B.shadow.matrix,N++}s.point[b]=z,b++}else if(B.isHemisphereLight){const z=t.get(B);z.skyColor.copy(B.color).multiplyScalar(et),z.groundColor.copy(B.groundColor).multiplyScalar(et),s.hemi[x]=z,x++}}M>0&&(r.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Nt.LTC_FLOAT_1,s.rectAreaLTC2=Nt.LTC_FLOAT_2):(s.rectAreaLTC1=Nt.LTC_HALF_1,s.rectAreaLTC2=Nt.LTC_HALF_2)),s.ambient[0]=g,s.ambient[1]=_,s.ambient[2]=y;const j=s.hash;(j.directionalLength!==v||j.pointLength!==b||j.spotLength!==E||j.rectAreaLength!==M||j.hemiLength!==x||j.numDirectionalShadows!==P||j.numPointShadows!==N||j.numSpotShadows!==w||j.numSpotMaps!==k||j.numLightProbes!==I)&&(s.directional.length=v,s.spot.length=E,s.rectArea.length=M,s.point.length=b,s.hemi.length=x,s.directionalShadow.length=P,s.directionalShadowMap.length=P,s.pointShadow.length=N,s.pointShadowMap.length=N,s.spotShadow.length=w,s.spotShadowMap.length=w,s.directionalShadowMatrix.length=P,s.pointShadowMatrix.length=N,s.spotLightMatrix.length=w+k-H,s.spotLightMap.length=k,s.numSpotLightShadowsWithMaps=H,s.numLightProbes=I,j.directionalLength=v,j.pointLength=b,j.spotLength=E,j.rectAreaLength=M,j.hemiLength=x,j.numDirectionalShadows=P,j.numPointShadows=N,j.numSpotShadows=w,j.numSpotMaps=k,j.numLightProbes=I,s.version=a2++)}function m(p,g){let _=0,y=0,v=0,b=0,E=0;const M=g.matrixWorldInverse;for(let x=0,P=p.length;x<P;x++){const N=p[x];if(N.isDirectionalLight){const w=s.directional[_];w.direction.setFromMatrixPosition(N.matrixWorld),l.setFromMatrixPosition(N.target.matrixWorld),w.direction.sub(l),w.direction.transformDirection(M),_++}else if(N.isSpotLight){const w=s.spot[v];w.position.setFromMatrixPosition(N.matrixWorld),w.position.applyMatrix4(M),w.direction.setFromMatrixPosition(N.matrixWorld),l.setFromMatrixPosition(N.target.matrixWorld),w.direction.sub(l),w.direction.transformDirection(M),v++}else if(N.isRectAreaLight){const w=s.rectArea[b];w.position.setFromMatrixPosition(N.matrixWorld),w.position.applyMatrix4(M),h.identity(),c.copy(N.matrixWorld),c.premultiply(M),h.extractRotation(c),w.halfWidth.set(N.width*.5,0,0),w.halfHeight.set(0,N.height*.5,0),w.halfWidth.applyMatrix4(h),w.halfHeight.applyMatrix4(h),b++}else if(N.isPointLight){const w=s.point[y];w.position.setFromMatrixPosition(N.matrixWorld),w.position.applyMatrix4(M),y++}else if(N.isHemisphereLight){const w=s.hemi[E];w.direction.setFromMatrixPosition(N.matrixWorld),w.direction.transformDirection(M),E++}}}return{setup:d,setupView:m,state:s}}function Y_(r){const t=new r2(r),i=[],s=[];function l(g){p.camera=g,i.length=0,s.length=0}function c(g){i.push(g)}function h(g){s.push(g)}function d(){t.setup(i)}function m(g){t.setupView(i,g)}const p={lightsArray:i,shadowsArray:s,camera:null,lights:t,transmissionRenderTarget:{}};return{init:l,state:p,setupLights:d,setupLightsView:m,pushLight:c,pushShadow:h}}function o2(r){let t=new WeakMap;function i(l,c=0){const h=t.get(l);let d;return h===void 0?(d=new Y_(r),t.set(l,[d])):c>=h.length?(d=new Y_(r),h.push(d)):d=h[c],d}function s(){t=new WeakMap}return{get:i,dispose:s}}const l2=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,c2=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function u2(r,t,i){let s=new qd;const l=new se,c=new se,h=new an,d=new C1({depthPacking:FS}),m=new w1,p={},g=i.maxTextureSize,_={[Ja]:Fn,[Fn]:Ja,[li]:li},y=new Hi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new se},radius:{value:4}},vertexShader:l2,fragmentShader:c2}),v=y.clone();v.defines.HORIZONTAL_PASS=1;const b=new Gn;b.setAttribute("position",new Jn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new Qe(b,y),M=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=tv;let x=this.type;this.render=function(H,I,j){if(M.enabled===!1||M.autoUpdate===!1&&M.needsUpdate===!1||H.length===0)return;const L=r.getRenderTarget(),R=r.getActiveCubeFace(),B=r.getActiveMipmapLevel(),tt=r.state;tt.setBlending(Za),tt.buffers.color.setClear(1,1,1,1),tt.buffers.depth.setTest(!0),tt.setScissorTest(!1);const et=x!==ua&&this.type===ua,ut=x===ua&&this.type!==ua;for(let ft=0,z=H.length;ft<z;ft++){const W=H[ft],X=W.shadow;if(X===void 0){console.warn("THREE.WebGLShadowMap:",W,"has no shadow.");continue}if(X.autoUpdate===!1&&X.needsUpdate===!1)continue;l.copy(X.mapSize);const _t=X.getFrameExtents();if(l.multiply(_t),c.copy(X.mapSize),(l.x>g||l.y>g)&&(l.x>g&&(c.x=Math.floor(g/_t.x),l.x=c.x*_t.x,X.mapSize.x=c.x),l.y>g&&(c.y=Math.floor(g/_t.y),l.y=c.y*_t.y,X.mapSize.y=c.y)),X.map===null||et===!0||ut===!0){const O=this.type!==ua?{minFilter:Di,magFilter:Di}:{};X.map!==null&&X.map.dispose(),X.map=new Ds(l.x,l.y,O),X.map.texture.name=W.name+".shadowMap",X.camera.updateProjectionMatrix()}r.setRenderTarget(X.map),r.clear();const Et=X.getViewportCount();for(let O=0;O<Et;O++){const at=X.getViewport(O);h.set(c.x*at.x,c.y*at.y,c.x*at.z,c.y*at.w),tt.viewport(h),X.updateMatrices(W,O),s=X.getFrustum(),w(I,j,X.camera,W,this.type)}X.isPointLightShadow!==!0&&this.type===ua&&P(X,j),X.needsUpdate=!1}x=this.type,M.needsUpdate=!1,r.setRenderTarget(L,R,B)};function P(H,I){const j=t.update(E);y.defines.VSM_SAMPLES!==H.blurSamples&&(y.defines.VSM_SAMPLES=H.blurSamples,v.defines.VSM_SAMPLES=H.blurSamples,y.needsUpdate=!0,v.needsUpdate=!0),H.mapPass===null&&(H.mapPass=new Ds(l.x,l.y)),y.uniforms.shadow_pass.value=H.map.texture,y.uniforms.resolution.value=H.mapSize,y.uniforms.radius.value=H.radius,r.setRenderTarget(H.mapPass),r.clear(),r.renderBufferDirect(I,null,j,y,E,null),v.uniforms.shadow_pass.value=H.mapPass.texture,v.uniforms.resolution.value=H.mapSize,v.uniforms.radius.value=H.radius,r.setRenderTarget(H.map),r.clear(),r.renderBufferDirect(I,null,j,v,E,null)}function N(H,I,j,L){let R=null;const B=j.isPointLight===!0?H.customDistanceMaterial:H.customDepthMaterial;if(B!==void 0)R=B;else if(R=j.isPointLight===!0?m:d,r.localClippingEnabled&&I.clipShadows===!0&&Array.isArray(I.clippingPlanes)&&I.clippingPlanes.length!==0||I.displacementMap&&I.displacementScale!==0||I.alphaMap&&I.alphaTest>0||I.map&&I.alphaTest>0){const tt=R.uuid,et=I.uuid;let ut=p[tt];ut===void 0&&(ut={},p[tt]=ut);let ft=ut[et];ft===void 0&&(ft=R.clone(),ut[et]=ft,I.addEventListener("dispose",k)),R=ft}if(R.visible=I.visible,R.wireframe=I.wireframe,L===ua?R.side=I.shadowSide!==null?I.shadowSide:I.side:R.side=I.shadowSide!==null?I.shadowSide:_[I.side],R.alphaMap=I.alphaMap,R.alphaTest=I.alphaTest,R.map=I.map,R.clipShadows=I.clipShadows,R.clippingPlanes=I.clippingPlanes,R.clipIntersection=I.clipIntersection,R.displacementMap=I.displacementMap,R.displacementScale=I.displacementScale,R.displacementBias=I.displacementBias,R.wireframeLinewidth=I.wireframeLinewidth,R.linewidth=I.linewidth,j.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const tt=r.properties.get(R);tt.light=j}return R}function w(H,I,j,L,R){if(H.visible===!1)return;if(H.layers.test(I.layers)&&(H.isMesh||H.isLine||H.isPoints)&&(H.castShadow||H.receiveShadow&&R===ua)&&(!H.frustumCulled||s.intersectsObject(H))){H.modelViewMatrix.multiplyMatrices(j.matrixWorldInverse,H.matrixWorld);const et=t.update(H),ut=H.material;if(Array.isArray(ut)){const ft=et.groups;for(let z=0,W=ft.length;z<W;z++){const X=ft[z],_t=ut[X.materialIndex];if(_t&&_t.visible){const Et=N(H,_t,L,R);H.onBeforeShadow(r,H,I,j,et,Et,X),r.renderBufferDirect(j,null,et,Et,H,X),H.onAfterShadow(r,H,I,j,et,Et,X)}}}else if(ut.visible){const ft=N(H,ut,L,R);H.onBeforeShadow(r,H,I,j,et,ft,null),r.renderBufferDirect(j,null,et,ft,H,null),H.onAfterShadow(r,H,I,j,et,ft,null)}}const tt=H.children;for(let et=0,ut=tt.length;et<ut;et++)w(tt[et],I,j,L,R)}function k(H){H.target.removeEventListener("dispose",k);for(const j in p){const L=p[j],R=H.target.uuid;R in L&&(L[R].dispose(),delete L[R])}}}const f2={[Jh]:$h,[td]:id,[ed]:ad,[Ir]:nd,[$h]:Jh,[id]:td,[ad]:ed,[nd]:Ir};function h2(r,t){function i(){let Z=!1;const wt=new an;let ht=null;const Mt=new an(0,0,0,0);return{setMask:function(Dt){ht!==Dt&&!Z&&(r.colorMask(Dt,Dt,Dt,Dt),ht=Dt)},setLocked:function(Dt){Z=Dt},setClear:function(Dt,Lt,$t,Ye,hn){hn===!0&&(Dt*=Ye,Lt*=Ye,$t*=Ye),wt.set(Dt,Lt,$t,Ye),Mt.equals(wt)===!1&&(r.clearColor(Dt,Lt,$t,Ye),Mt.copy(wt))},reset:function(){Z=!1,ht=null,Mt.set(-1,0,0,0)}}}function s(){let Z=!1,wt=!1,ht=null,Mt=null,Dt=null;return{setReversed:function(Lt){if(wt!==Lt){const $t=t.get("EXT_clip_control");wt?$t.clipControlEXT($t.LOWER_LEFT_EXT,$t.ZERO_TO_ONE_EXT):$t.clipControlEXT($t.LOWER_LEFT_EXT,$t.NEGATIVE_ONE_TO_ONE_EXT);const Ye=Dt;Dt=null,this.setClear(Ye)}wt=Lt},getReversed:function(){return wt},setTest:function(Lt){Lt?bt(r.DEPTH_TEST):Ft(r.DEPTH_TEST)},setMask:function(Lt){ht!==Lt&&!Z&&(r.depthMask(Lt),ht=Lt)},setFunc:function(Lt){if(wt&&(Lt=f2[Lt]),Mt!==Lt){switch(Lt){case Jh:r.depthFunc(r.NEVER);break;case $h:r.depthFunc(r.ALWAYS);break;case td:r.depthFunc(r.LESS);break;case Ir:r.depthFunc(r.LEQUAL);break;case ed:r.depthFunc(r.EQUAL);break;case nd:r.depthFunc(r.GEQUAL);break;case id:r.depthFunc(r.GREATER);break;case ad:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}Mt=Lt}},setLocked:function(Lt){Z=Lt},setClear:function(Lt){Dt!==Lt&&(wt&&(Lt=1-Lt),r.clearDepth(Lt),Dt=Lt)},reset:function(){Z=!1,ht=null,Mt=null,Dt=null,wt=!1}}}function l(){let Z=!1,wt=null,ht=null,Mt=null,Dt=null,Lt=null,$t=null,Ye=null,hn=null;return{setTest:function(Te){Z||(Te?bt(r.STENCIL_TEST):Ft(r.STENCIL_TEST))},setMask:function(Te){wt!==Te&&!Z&&(r.stencilMask(Te),wt=Te)},setFunc:function(Te,Mn,xi){(ht!==Te||Mt!==Mn||Dt!==xi)&&(r.stencilFunc(Te,Mn,xi),ht=Te,Mt=Mn,Dt=xi)},setOp:function(Te,Mn,xi){(Lt!==Te||$t!==Mn||Ye!==xi)&&(r.stencilOp(Te,Mn,xi),Lt=Te,$t=Mn,Ye=xi)},setLocked:function(Te){Z=Te},setClear:function(Te){hn!==Te&&(r.clearStencil(Te),hn=Te)},reset:function(){Z=!1,wt=null,ht=null,Mt=null,Dt=null,Lt=null,$t=null,Ye=null,hn=null}}}const c=new i,h=new s,d=new l,m=new WeakMap,p=new WeakMap;let g={},_={},y=new WeakMap,v=[],b=null,E=!1,M=null,x=null,P=null,N=null,w=null,k=null,H=null,I=new be(0,0,0),j=0,L=!1,R=null,B=null,tt=null,et=null,ut=null;const ft=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,W=0;const X=r.getParameter(r.VERSION);X.indexOf("WebGL")!==-1?(W=parseFloat(/^WebGL (\d)/.exec(X)[1]),z=W>=1):X.indexOf("OpenGL ES")!==-1&&(W=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),z=W>=2);let _t=null,Et={};const O=r.getParameter(r.SCISSOR_BOX),at=r.getParameter(r.VIEWPORT),vt=new an().fromArray(O),Y=new an().fromArray(at);function st(Z,wt,ht,Mt){const Dt=new Uint8Array(4),Lt=r.createTexture();r.bindTexture(Z,Lt),r.texParameteri(Z,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(Z,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let $t=0;$t<ht;$t++)Z===r.TEXTURE_3D||Z===r.TEXTURE_2D_ARRAY?r.texImage3D(wt,0,r.RGBA,1,1,Mt,0,r.RGBA,r.UNSIGNED_BYTE,Dt):r.texImage2D(wt+$t,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Dt);return Lt}const xt={};xt[r.TEXTURE_2D]=st(r.TEXTURE_2D,r.TEXTURE_2D,1),xt[r.TEXTURE_CUBE_MAP]=st(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),xt[r.TEXTURE_2D_ARRAY]=st(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),xt[r.TEXTURE_3D]=st(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),h.setClear(1),d.setClear(0),bt(r.DEPTH_TEST),h.setFunc(Ir),le(!1),de(X0),bt(r.CULL_FACE),G(Za);function bt(Z){g[Z]!==!0&&(r.enable(Z),g[Z]=!0)}function Ft(Z){g[Z]!==!1&&(r.disable(Z),g[Z]=!1)}function Xt(Z,wt){return _[Z]!==wt?(r.bindFramebuffer(Z,wt),_[Z]=wt,Z===r.DRAW_FRAMEBUFFER&&(_[r.FRAMEBUFFER]=wt),Z===r.FRAMEBUFFER&&(_[r.DRAW_FRAMEBUFFER]=wt),!0):!1}function Yt(Z,wt){let ht=v,Mt=!1;if(Z){ht=y.get(wt),ht===void 0&&(ht=[],y.set(wt,ht));const Dt=Z.textures;if(ht.length!==Dt.length||ht[0]!==r.COLOR_ATTACHMENT0){for(let Lt=0,$t=Dt.length;Lt<$t;Lt++)ht[Lt]=r.COLOR_ATTACHMENT0+Lt;ht.length=Dt.length,Mt=!0}}else ht[0]!==r.BACK&&(ht[0]=r.BACK,Mt=!0);Mt&&r.drawBuffers(ht)}function ze(Z){return b!==Z?(r.useProgram(Z),b=Z,!0):!1}const Ue={[As]:r.FUNC_ADD,[hS]:r.FUNC_SUBTRACT,[dS]:r.FUNC_REVERSE_SUBTRACT};Ue[pS]=r.MIN,Ue[mS]=r.MAX;const fe={[gS]:r.ZERO,[_S]:r.ONE,[vS]:r.SRC_COLOR,[Kh]:r.SRC_ALPHA,[ES]:r.SRC_ALPHA_SATURATE,[MS]:r.DST_COLOR,[yS]:r.DST_ALPHA,[xS]:r.ONE_MINUS_SRC_COLOR,[Qh]:r.ONE_MINUS_SRC_ALPHA,[bS]:r.ONE_MINUS_DST_COLOR,[SS]:r.ONE_MINUS_DST_ALPHA,[TS]:r.CONSTANT_COLOR,[AS]:r.ONE_MINUS_CONSTANT_COLOR,[RS]:r.CONSTANT_ALPHA,[CS]:r.ONE_MINUS_CONSTANT_ALPHA};function G(Z,wt,ht,Mt,Dt,Lt,$t,Ye,hn,Te){if(Z===Za){E===!0&&(Ft(r.BLEND),E=!1);return}if(E===!1&&(bt(r.BLEND),E=!0),Z!==fS){if(Z!==M||Te!==L){if((x!==As||w!==As)&&(r.blendEquation(r.FUNC_ADD),x=As,w=As),Te)switch(Z){case Ur:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case qa:r.blendFunc(r.ONE,r.ONE);break;case W0:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case q0:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",Z);break}else switch(Z){case Ur:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case qa:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case W0:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case q0:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",Z);break}P=null,N=null,k=null,H=null,I.set(0,0,0),j=0,M=Z,L=Te}return}Dt=Dt||wt,Lt=Lt||ht,$t=$t||Mt,(wt!==x||Dt!==w)&&(r.blendEquationSeparate(Ue[wt],Ue[Dt]),x=wt,w=Dt),(ht!==P||Mt!==N||Lt!==k||$t!==H)&&(r.blendFuncSeparate(fe[ht],fe[Mt],fe[Lt],fe[$t]),P=ht,N=Mt,k=Lt,H=$t),(Ye.equals(I)===!1||hn!==j)&&(r.blendColor(Ye.r,Ye.g,Ye.b,hn),I.copy(Ye),j=hn),M=Z,L=!1}function Je(Z,wt){Z.side===li?Ft(r.CULL_FACE):bt(r.CULL_FACE);let ht=Z.side===Fn;wt&&(ht=!ht),le(ht),Z.blending===Ur&&Z.transparent===!1?G(Za):G(Z.blending,Z.blendEquation,Z.blendSrc,Z.blendDst,Z.blendEquationAlpha,Z.blendSrcAlpha,Z.blendDstAlpha,Z.blendColor,Z.blendAlpha,Z.premultipliedAlpha),h.setFunc(Z.depthFunc),h.setTest(Z.depthTest),h.setMask(Z.depthWrite),c.setMask(Z.colorWrite);const Mt=Z.stencilWrite;d.setTest(Mt),Mt&&(d.setMask(Z.stencilWriteMask),d.setFunc(Z.stencilFunc,Z.stencilRef,Z.stencilFuncMask),d.setOp(Z.stencilFail,Z.stencilZFail,Z.stencilZPass)),Ae(Z.polygonOffset,Z.polygonOffsetFactor,Z.polygonOffsetUnits),Z.alphaToCoverage===!0?bt(r.SAMPLE_ALPHA_TO_COVERAGE):Ft(r.SAMPLE_ALPHA_TO_COVERAGE)}function le(Z){R!==Z&&(Z?r.frontFace(r.CW):r.frontFace(r.CCW),R=Z)}function de(Z){Z!==lS?(bt(r.CULL_FACE),Z!==B&&(Z===X0?r.cullFace(r.BACK):Z===cS?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Ft(r.CULL_FACE),B=Z}function kt(Z){Z!==tt&&(z&&r.lineWidth(Z),tt=Z)}function Ae(Z,wt,ht){Z?(bt(r.POLYGON_OFFSET_FILL),(et!==wt||ut!==ht)&&(r.polygonOffset(wt,ht),et=wt,ut=ht)):Ft(r.POLYGON_OFFSET_FILL)}function Rt(Z){Z?bt(r.SCISSOR_TEST):Ft(r.SCISSOR_TEST)}function U(Z){Z===void 0&&(Z=r.TEXTURE0+ft-1),_t!==Z&&(r.activeTexture(Z),_t=Z)}function T(Z,wt,ht){ht===void 0&&(_t===null?ht=r.TEXTURE0+ft-1:ht=_t);let Mt=Et[ht];Mt===void 0&&(Mt={type:void 0,texture:void 0},Et[ht]=Mt),(Mt.type!==Z||Mt.texture!==wt)&&(_t!==ht&&(r.activeTexture(ht),_t=ht),r.bindTexture(Z,wt||xt[Z]),Mt.type=Z,Mt.texture=wt)}function $(){const Z=Et[_t];Z!==void 0&&Z.type!==void 0&&(r.bindTexture(Z.type,null),Z.type=void 0,Z.texture=void 0)}function dt(){try{r.compressedTexImage2D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function St(){try{r.compressedTexImage3D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function mt(){try{r.texSubImage2D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function Bt(){try{r.texSubImage3D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function Ct(){try{r.compressedTexSubImage2D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function It(){try{r.compressedTexSubImage3D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function pe(){try{r.texStorage2D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function At(){try{r.texStorage3D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function Ht(){try{r.texImage2D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function Kt(){try{r.texImage3D(...arguments)}catch(Z){console.error("THREE.WebGLState:",Z)}}function jt(Z){vt.equals(Z)===!1&&(r.scissor(Z.x,Z.y,Z.z,Z.w),vt.copy(Z))}function Pt(Z){Y.equals(Z)===!1&&(r.viewport(Z.x,Z.y,Z.z,Z.w),Y.copy(Z))}function Jt(Z,wt){let ht=p.get(wt);ht===void 0&&(ht=new WeakMap,p.set(wt,ht));let Mt=ht.get(Z);Mt===void 0&&(Mt=r.getUniformBlockIndex(wt,Z.name),ht.set(Z,Mt))}function re(Z,wt){const Mt=p.get(wt).get(Z);m.get(wt)!==Mt&&(r.uniformBlockBinding(wt,Mt,Z.__bindingPointIndex),m.set(wt,Mt))}function Ie(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),h.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),g={},_t=null,Et={},_={},y=new WeakMap,v=[],b=null,E=!1,M=null,x=null,P=null,N=null,w=null,k=null,H=null,I=new be(0,0,0),j=0,L=!1,R=null,B=null,tt=null,et=null,ut=null,vt.set(0,0,r.canvas.width,r.canvas.height),Y.set(0,0,r.canvas.width,r.canvas.height),c.reset(),h.reset(),d.reset()}return{buffers:{color:c,depth:h,stencil:d},enable:bt,disable:Ft,bindFramebuffer:Xt,drawBuffers:Yt,useProgram:ze,setBlending:G,setMaterial:Je,setFlipSided:le,setCullFace:de,setLineWidth:kt,setPolygonOffset:Ae,setScissorTest:Rt,activeTexture:U,bindTexture:T,unbindTexture:$,compressedTexImage2D:dt,compressedTexImage3D:St,texImage2D:Ht,texImage3D:Kt,updateUBOMapping:Jt,uniformBlockBinding:re,texStorage2D:pe,texStorage3D:At,texSubImage2D:mt,texSubImage3D:Bt,compressedTexSubImage2D:Ct,compressedTexSubImage3D:It,scissor:jt,viewport:Pt,reset:Ie}}function d2(r,t,i,s,l,c,h){const d=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),p=new se,g=new WeakMap;let _;const y=new WeakMap;let v=!1;try{v=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function b(U,T){return v?new OffscreenCanvas(U,T):Ko("canvas")}function E(U,T,$){let dt=1;const St=Rt(U);if((St.width>$||St.height>$)&&(dt=$/Math.max(St.width,St.height)),dt<1)if(typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&U instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&U instanceof ImageBitmap||typeof VideoFrame<"u"&&U instanceof VideoFrame){const mt=Math.floor(dt*St.width),Bt=Math.floor(dt*St.height);_===void 0&&(_=b(mt,Bt));const Ct=T?b(mt,Bt):_;return Ct.width=mt,Ct.height=Bt,Ct.getContext("2d").drawImage(U,0,0,mt,Bt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+St.width+"x"+St.height+") to ("+mt+"x"+Bt+")."),Ct}else return"data"in U&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+St.width+"x"+St.height+")."),U;return U}function M(U){return U.generateMipmaps}function x(U){r.generateMipmap(U)}function P(U){return U.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:U.isWebGL3DRenderTarget?r.TEXTURE_3D:U.isWebGLArrayRenderTarget||U.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function N(U,T,$,dt,St=!1){if(U!==null){if(r[U]!==void 0)return r[U];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+U+"'")}let mt=T;if(T===r.RED&&($===r.FLOAT&&(mt=r.R32F),$===r.HALF_FLOAT&&(mt=r.R16F),$===r.UNSIGNED_BYTE&&(mt=r.R8)),T===r.RED_INTEGER&&($===r.UNSIGNED_BYTE&&(mt=r.R8UI),$===r.UNSIGNED_SHORT&&(mt=r.R16UI),$===r.UNSIGNED_INT&&(mt=r.R32UI),$===r.BYTE&&(mt=r.R8I),$===r.SHORT&&(mt=r.R16I),$===r.INT&&(mt=r.R32I)),T===r.RG&&($===r.FLOAT&&(mt=r.RG32F),$===r.HALF_FLOAT&&(mt=r.RG16F),$===r.UNSIGNED_BYTE&&(mt=r.RG8)),T===r.RG_INTEGER&&($===r.UNSIGNED_BYTE&&(mt=r.RG8UI),$===r.UNSIGNED_SHORT&&(mt=r.RG16UI),$===r.UNSIGNED_INT&&(mt=r.RG32UI),$===r.BYTE&&(mt=r.RG8I),$===r.SHORT&&(mt=r.RG16I),$===r.INT&&(mt=r.RG32I)),T===r.RGB_INTEGER&&($===r.UNSIGNED_BYTE&&(mt=r.RGB8UI),$===r.UNSIGNED_SHORT&&(mt=r.RGB16UI),$===r.UNSIGNED_INT&&(mt=r.RGB32UI),$===r.BYTE&&(mt=r.RGB8I),$===r.SHORT&&(mt=r.RGB16I),$===r.INT&&(mt=r.RGB32I)),T===r.RGBA_INTEGER&&($===r.UNSIGNED_BYTE&&(mt=r.RGBA8UI),$===r.UNSIGNED_SHORT&&(mt=r.RGBA16UI),$===r.UNSIGNED_INT&&(mt=r.RGBA32UI),$===r.BYTE&&(mt=r.RGBA8I),$===r.SHORT&&(mt=r.RGBA16I),$===r.INT&&(mt=r.RGBA32I)),T===r.RGB&&$===r.UNSIGNED_INT_5_9_9_9_REV&&(mt=r.RGB9_E5),T===r.RGBA){const Bt=St?Wc:De.getTransfer(dt);$===r.FLOAT&&(mt=r.RGBA32F),$===r.HALF_FLOAT&&(mt=r.RGBA16F),$===r.UNSIGNED_BYTE&&(mt=Bt===Ve?r.SRGB8_ALPHA8:r.RGBA8),$===r.UNSIGNED_SHORT_4_4_4_4&&(mt=r.RGBA4),$===r.UNSIGNED_SHORT_5_5_5_1&&(mt=r.RGB5_A1)}return(mt===r.R16F||mt===r.R32F||mt===r.RG16F||mt===r.RG32F||mt===r.RGBA16F||mt===r.RGBA32F)&&t.get("EXT_color_buffer_float"),mt}function w(U,T){let $;return U?T===null||T===ws||T===Hr?$=r.DEPTH24_STENCIL8:T===fa?$=r.DEPTH32F_STENCIL8:T===Zo&&($=r.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===ws||T===Hr?$=r.DEPTH_COMPONENT24:T===fa?$=r.DEPTH_COMPONENT32F:T===Zo&&($=r.DEPTH_COMPONENT16),$}function k(U,T){return M(U)===!0||U.isFramebufferTexture&&U.minFilter!==Di&&U.minFilter!==Ii?Math.log2(Math.max(T.width,T.height))+1:U.mipmaps!==void 0&&U.mipmaps.length>0?U.mipmaps.length:U.isCompressedTexture&&Array.isArray(U.image)?T.mipmaps.length:1}function H(U){const T=U.target;T.removeEventListener("dispose",H),j(T),T.isVideoTexture&&g.delete(T)}function I(U){const T=U.target;T.removeEventListener("dispose",I),R(T)}function j(U){const T=s.get(U);if(T.__webglInit===void 0)return;const $=U.source,dt=y.get($);if(dt){const St=dt[T.__cacheKey];St.usedTimes--,St.usedTimes===0&&L(U),Object.keys(dt).length===0&&y.delete($)}s.remove(U)}function L(U){const T=s.get(U);r.deleteTexture(T.__webglTexture);const $=U.source,dt=y.get($);delete dt[T.__cacheKey],h.memory.textures--}function R(U){const T=s.get(U);if(U.depthTexture&&(U.depthTexture.dispose(),s.remove(U.depthTexture)),U.isWebGLCubeRenderTarget)for(let dt=0;dt<6;dt++){if(Array.isArray(T.__webglFramebuffer[dt]))for(let St=0;St<T.__webglFramebuffer[dt].length;St++)r.deleteFramebuffer(T.__webglFramebuffer[dt][St]);else r.deleteFramebuffer(T.__webglFramebuffer[dt]);T.__webglDepthbuffer&&r.deleteRenderbuffer(T.__webglDepthbuffer[dt])}else{if(Array.isArray(T.__webglFramebuffer))for(let dt=0;dt<T.__webglFramebuffer.length;dt++)r.deleteFramebuffer(T.__webglFramebuffer[dt]);else r.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&r.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&r.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let dt=0;dt<T.__webglColorRenderbuffer.length;dt++)T.__webglColorRenderbuffer[dt]&&r.deleteRenderbuffer(T.__webglColorRenderbuffer[dt]);T.__webglDepthRenderbuffer&&r.deleteRenderbuffer(T.__webglDepthRenderbuffer)}const $=U.textures;for(let dt=0,St=$.length;dt<St;dt++){const mt=s.get($[dt]);mt.__webglTexture&&(r.deleteTexture(mt.__webglTexture),h.memory.textures--),s.remove($[dt])}s.remove(U)}let B=0;function tt(){B=0}function et(){const U=B;return U>=l.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+U+" texture units while this GPU supports only "+l.maxTextures),B+=1,U}function ut(U){const T=[];return T.push(U.wrapS),T.push(U.wrapT),T.push(U.wrapR||0),T.push(U.magFilter),T.push(U.minFilter),T.push(U.anisotropy),T.push(U.internalFormat),T.push(U.format),T.push(U.type),T.push(U.generateMipmaps),T.push(U.premultiplyAlpha),T.push(U.flipY),T.push(U.unpackAlignment),T.push(U.colorSpace),T.join()}function ft(U,T){const $=s.get(U);if(U.isVideoTexture&&kt(U),U.isRenderTargetTexture===!1&&U.version>0&&$.__version!==U.version){const dt=U.image;if(dt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(dt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y($,U,T);return}}i.bindTexture(r.TEXTURE_2D,$.__webglTexture,r.TEXTURE0+T)}function z(U,T){const $=s.get(U);if(U.version>0&&$.__version!==U.version){Y($,U,T);return}i.bindTexture(r.TEXTURE_2D_ARRAY,$.__webglTexture,r.TEXTURE0+T)}function W(U,T){const $=s.get(U);if(U.version>0&&$.__version!==U.version){Y($,U,T);return}i.bindTexture(r.TEXTURE_3D,$.__webglTexture,r.TEXTURE0+T)}function X(U,T){const $=s.get(U);if(U.version>0&&$.__version!==U.version){st($,U,T);return}i.bindTexture(r.TEXTURE_CUBE_MAP,$.__webglTexture,r.TEXTURE0+T)}const _t={[Xc]:r.REPEAT,[Ya]:r.CLAMP_TO_EDGE,[od]:r.MIRRORED_REPEAT},Et={[Di]:r.NEAREST,[IS]:r.NEAREST_MIPMAP_NEAREST,[fc]:r.NEAREST_MIPMAP_LINEAR,[Ii]:r.LINEAR,[_h]:r.LINEAR_MIPMAP_NEAREST,[Cs]:r.LINEAR_MIPMAP_LINEAR},O={[GS]:r.NEVER,[qS]:r.ALWAYS,[VS]:r.LESS,[mv]:r.LEQUAL,[kS]:r.EQUAL,[WS]:r.GEQUAL,[jS]:r.GREATER,[XS]:r.NOTEQUAL};function at(U,T){if(T.type===fa&&t.has("OES_texture_float_linear")===!1&&(T.magFilter===Ii||T.magFilter===_h||T.magFilter===fc||T.magFilter===Cs||T.minFilter===Ii||T.minFilter===_h||T.minFilter===fc||T.minFilter===Cs)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(U,r.TEXTURE_WRAP_S,_t[T.wrapS]),r.texParameteri(U,r.TEXTURE_WRAP_T,_t[T.wrapT]),(U===r.TEXTURE_3D||U===r.TEXTURE_2D_ARRAY)&&r.texParameteri(U,r.TEXTURE_WRAP_R,_t[T.wrapR]),r.texParameteri(U,r.TEXTURE_MAG_FILTER,Et[T.magFilter]),r.texParameteri(U,r.TEXTURE_MIN_FILTER,Et[T.minFilter]),T.compareFunction&&(r.texParameteri(U,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(U,r.TEXTURE_COMPARE_FUNC,O[T.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===Di||T.minFilter!==fc&&T.minFilter!==Cs||T.type===fa&&t.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||s.get(T).__currentAnisotropy){const $=t.get("EXT_texture_filter_anisotropic");r.texParameterf(U,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,l.getMaxAnisotropy())),s.get(T).__currentAnisotropy=T.anisotropy}}}function vt(U,T){let $=!1;U.__webglInit===void 0&&(U.__webglInit=!0,T.addEventListener("dispose",H));const dt=T.source;let St=y.get(dt);St===void 0&&(St={},y.set(dt,St));const mt=ut(T);if(mt!==U.__cacheKey){St[mt]===void 0&&(St[mt]={texture:r.createTexture(),usedTimes:0},h.memory.textures++,$=!0),St[mt].usedTimes++;const Bt=St[U.__cacheKey];Bt!==void 0&&(St[U.__cacheKey].usedTimes--,Bt.usedTimes===0&&L(T)),U.__cacheKey=mt,U.__webglTexture=St[mt].texture}return $}function Y(U,T,$){let dt=r.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(dt=r.TEXTURE_2D_ARRAY),T.isData3DTexture&&(dt=r.TEXTURE_3D);const St=vt(U,T),mt=T.source;i.bindTexture(dt,U.__webglTexture,r.TEXTURE0+$);const Bt=s.get(mt);if(mt.version!==Bt.__version||St===!0){i.activeTexture(r.TEXTURE0+$);const Ct=De.getPrimaries(De.workingColorSpace),It=T.colorSpace===Xa?null:De.getPrimaries(T.colorSpace),pe=T.colorSpace===Xa||Ct===It?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,T.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,T.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,pe);let At=E(T.image,!1,l.maxTextureSize);At=Ae(T,At);const Ht=c.convert(T.format,T.colorSpace),Kt=c.convert(T.type);let jt=N(T.internalFormat,Ht,Kt,T.colorSpace,T.isVideoTexture);at(dt,T);let Pt;const Jt=T.mipmaps,re=T.isVideoTexture!==!0,Ie=Bt.__version===void 0||St===!0,Z=mt.dataReady,wt=k(T,At);if(T.isDepthTexture)jt=w(T.format===Gr,T.type),Ie&&(re?i.texStorage2D(r.TEXTURE_2D,1,jt,At.width,At.height):i.texImage2D(r.TEXTURE_2D,0,jt,At.width,At.height,0,Ht,Kt,null));else if(T.isDataTexture)if(Jt.length>0){re&&Ie&&i.texStorage2D(r.TEXTURE_2D,wt,jt,Jt[0].width,Jt[0].height);for(let ht=0,Mt=Jt.length;ht<Mt;ht++)Pt=Jt[ht],re?Z&&i.texSubImage2D(r.TEXTURE_2D,ht,0,0,Pt.width,Pt.height,Ht,Kt,Pt.data):i.texImage2D(r.TEXTURE_2D,ht,jt,Pt.width,Pt.height,0,Ht,Kt,Pt.data);T.generateMipmaps=!1}else re?(Ie&&i.texStorage2D(r.TEXTURE_2D,wt,jt,At.width,At.height),Z&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,At.width,At.height,Ht,Kt,At.data)):i.texImage2D(r.TEXTURE_2D,0,jt,At.width,At.height,0,Ht,Kt,At.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){re&&Ie&&i.texStorage3D(r.TEXTURE_2D_ARRAY,wt,jt,Jt[0].width,Jt[0].height,At.depth);for(let ht=0,Mt=Jt.length;ht<Mt;ht++)if(Pt=Jt[ht],T.format!==wi)if(Ht!==null)if(re){if(Z)if(T.layerUpdates.size>0){const Dt=E_(Pt.width,Pt.height,T.format,T.type);for(const Lt of T.layerUpdates){const $t=Pt.data.subarray(Lt*Dt/Pt.data.BYTES_PER_ELEMENT,(Lt+1)*Dt/Pt.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,ht,0,0,Lt,Pt.width,Pt.height,1,Ht,$t)}T.clearLayerUpdates()}else i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,ht,0,0,0,Pt.width,Pt.height,At.depth,Ht,Pt.data)}else i.compressedTexImage3D(r.TEXTURE_2D_ARRAY,ht,jt,Pt.width,Pt.height,At.depth,0,Pt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else re?Z&&i.texSubImage3D(r.TEXTURE_2D_ARRAY,ht,0,0,0,Pt.width,Pt.height,At.depth,Ht,Kt,Pt.data):i.texImage3D(r.TEXTURE_2D_ARRAY,ht,jt,Pt.width,Pt.height,At.depth,0,Ht,Kt,Pt.data)}else{re&&Ie&&i.texStorage2D(r.TEXTURE_2D,wt,jt,Jt[0].width,Jt[0].height);for(let ht=0,Mt=Jt.length;ht<Mt;ht++)Pt=Jt[ht],T.format!==wi?Ht!==null?re?Z&&i.compressedTexSubImage2D(r.TEXTURE_2D,ht,0,0,Pt.width,Pt.height,Ht,Pt.data):i.compressedTexImage2D(r.TEXTURE_2D,ht,jt,Pt.width,Pt.height,0,Pt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?Z&&i.texSubImage2D(r.TEXTURE_2D,ht,0,0,Pt.width,Pt.height,Ht,Kt,Pt.data):i.texImage2D(r.TEXTURE_2D,ht,jt,Pt.width,Pt.height,0,Ht,Kt,Pt.data)}else if(T.isDataArrayTexture)if(re){if(Ie&&i.texStorage3D(r.TEXTURE_2D_ARRAY,wt,jt,At.width,At.height,At.depth),Z)if(T.layerUpdates.size>0){const ht=E_(At.width,At.height,T.format,T.type);for(const Mt of T.layerUpdates){const Dt=At.data.subarray(Mt*ht/At.data.BYTES_PER_ELEMENT,(Mt+1)*ht/At.data.BYTES_PER_ELEMENT);i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Mt,At.width,At.height,1,Ht,Kt,Dt)}T.clearLayerUpdates()}else i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,At.width,At.height,At.depth,Ht,Kt,At.data)}else i.texImage3D(r.TEXTURE_2D_ARRAY,0,jt,At.width,At.height,At.depth,0,Ht,Kt,At.data);else if(T.isData3DTexture)re?(Ie&&i.texStorage3D(r.TEXTURE_3D,wt,jt,At.width,At.height,At.depth),Z&&i.texSubImage3D(r.TEXTURE_3D,0,0,0,0,At.width,At.height,At.depth,Ht,Kt,At.data)):i.texImage3D(r.TEXTURE_3D,0,jt,At.width,At.height,At.depth,0,Ht,Kt,At.data);else if(T.isFramebufferTexture){if(Ie)if(re)i.texStorage2D(r.TEXTURE_2D,wt,jt,At.width,At.height);else{let ht=At.width,Mt=At.height;for(let Dt=0;Dt<wt;Dt++)i.texImage2D(r.TEXTURE_2D,Dt,jt,ht,Mt,0,Ht,Kt,null),ht>>=1,Mt>>=1}}else if(Jt.length>0){if(re&&Ie){const ht=Rt(Jt[0]);i.texStorage2D(r.TEXTURE_2D,wt,jt,ht.width,ht.height)}for(let ht=0,Mt=Jt.length;ht<Mt;ht++)Pt=Jt[ht],re?Z&&i.texSubImage2D(r.TEXTURE_2D,ht,0,0,Ht,Kt,Pt):i.texImage2D(r.TEXTURE_2D,ht,jt,Ht,Kt,Pt);T.generateMipmaps=!1}else if(re){if(Ie){const ht=Rt(At);i.texStorage2D(r.TEXTURE_2D,wt,jt,ht.width,ht.height)}Z&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,Ht,Kt,At)}else i.texImage2D(r.TEXTURE_2D,0,jt,Ht,Kt,At);M(T)&&x(dt),Bt.__version=mt.version,T.onUpdate&&T.onUpdate(T)}U.__version=T.version}function st(U,T,$){if(T.image.length!==6)return;const dt=vt(U,T),St=T.source;i.bindTexture(r.TEXTURE_CUBE_MAP,U.__webglTexture,r.TEXTURE0+$);const mt=s.get(St);if(St.version!==mt.__version||dt===!0){i.activeTexture(r.TEXTURE0+$);const Bt=De.getPrimaries(De.workingColorSpace),Ct=T.colorSpace===Xa?null:De.getPrimaries(T.colorSpace),It=T.colorSpace===Xa||Bt===Ct?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,T.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,T.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,It);const pe=T.isCompressedTexture||T.image[0].isCompressedTexture,At=T.image[0]&&T.image[0].isDataTexture,Ht=[];for(let Mt=0;Mt<6;Mt++)!pe&&!At?Ht[Mt]=E(T.image[Mt],!0,l.maxCubemapSize):Ht[Mt]=At?T.image[Mt].image:T.image[Mt],Ht[Mt]=Ae(T,Ht[Mt]);const Kt=Ht[0],jt=c.convert(T.format,T.colorSpace),Pt=c.convert(T.type),Jt=N(T.internalFormat,jt,Pt,T.colorSpace),re=T.isVideoTexture!==!0,Ie=mt.__version===void 0||dt===!0,Z=St.dataReady;let wt=k(T,Kt);at(r.TEXTURE_CUBE_MAP,T);let ht;if(pe){re&&Ie&&i.texStorage2D(r.TEXTURE_CUBE_MAP,wt,Jt,Kt.width,Kt.height);for(let Mt=0;Mt<6;Mt++){ht=Ht[Mt].mipmaps;for(let Dt=0;Dt<ht.length;Dt++){const Lt=ht[Dt];T.format!==wi?jt!==null?re?Z&&i.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt,0,0,Lt.width,Lt.height,jt,Lt.data):i.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt,Jt,Lt.width,Lt.height,0,Lt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):re?Z&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt,0,0,Lt.width,Lt.height,jt,Pt,Lt.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt,Jt,Lt.width,Lt.height,0,jt,Pt,Lt.data)}}}else{if(ht=T.mipmaps,re&&Ie){ht.length>0&&wt++;const Mt=Rt(Ht[0]);i.texStorage2D(r.TEXTURE_CUBE_MAP,wt,Jt,Mt.width,Mt.height)}for(let Mt=0;Mt<6;Mt++)if(At){re?Z&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0,0,0,Ht[Mt].width,Ht[Mt].height,jt,Pt,Ht[Mt].data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0,Jt,Ht[Mt].width,Ht[Mt].height,0,jt,Pt,Ht[Mt].data);for(let Dt=0;Dt<ht.length;Dt++){const $t=ht[Dt].image[Mt].image;re?Z&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt+1,0,0,$t.width,$t.height,jt,Pt,$t.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt+1,Jt,$t.width,$t.height,0,jt,Pt,$t.data)}}else{re?Z&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0,0,0,jt,Pt,Ht[Mt]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0,Jt,jt,Pt,Ht[Mt]);for(let Dt=0;Dt<ht.length;Dt++){const Lt=ht[Dt];re?Z&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt+1,0,0,jt,Pt,Lt.image[Mt]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,Dt+1,Jt,jt,Pt,Lt.image[Mt])}}}M(T)&&x(r.TEXTURE_CUBE_MAP),mt.__version=St.version,T.onUpdate&&T.onUpdate(T)}U.__version=T.version}function xt(U,T,$,dt,St,mt){const Bt=c.convert($.format,$.colorSpace),Ct=c.convert($.type),It=N($.internalFormat,Bt,Ct,$.colorSpace),pe=s.get(T),At=s.get($);if(At.__renderTarget=T,!pe.__hasExternalTextures){const Ht=Math.max(1,T.width>>mt),Kt=Math.max(1,T.height>>mt);St===r.TEXTURE_3D||St===r.TEXTURE_2D_ARRAY?i.texImage3D(St,mt,It,Ht,Kt,T.depth,0,Bt,Ct,null):i.texImage2D(St,mt,It,Ht,Kt,0,Bt,Ct,null)}i.bindFramebuffer(r.FRAMEBUFFER,U),de(T)?d.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,dt,St,At.__webglTexture,0,le(T)):(St===r.TEXTURE_2D||St>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&St<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,dt,St,At.__webglTexture,mt),i.bindFramebuffer(r.FRAMEBUFFER,null)}function bt(U,T,$){if(r.bindRenderbuffer(r.RENDERBUFFER,U),T.depthBuffer){const dt=T.depthTexture,St=dt&&dt.isDepthTexture?dt.type:null,mt=w(T.stencilBuffer,St),Bt=T.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ct=le(T);de(T)?d.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Ct,mt,T.width,T.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,Ct,mt,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,mt,T.width,T.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Bt,r.RENDERBUFFER,U)}else{const dt=T.textures;for(let St=0;St<dt.length;St++){const mt=dt[St],Bt=c.convert(mt.format,mt.colorSpace),Ct=c.convert(mt.type),It=N(mt.internalFormat,Bt,Ct,mt.colorSpace),pe=le(T);$&&de(T)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,pe,It,T.width,T.height):de(T)?d.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,pe,It,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,It,T.width,T.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function Ft(U,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(i.bindFramebuffer(r.FRAMEBUFFER,U),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const dt=s.get(T.depthTexture);dt.__renderTarget=T,(!dt.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),ft(T.depthTexture,0);const St=dt.__webglTexture,mt=le(T);if(T.depthTexture.format===Nr)de(T)?d.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,St,0,mt):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,St,0);else if(T.depthTexture.format===Gr)de(T)?d.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,St,0,mt):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,St,0);else throw new Error("Unknown depthTexture format")}function Xt(U){const T=s.get(U),$=U.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==U.depthTexture){const dt=U.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),dt){const St=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,dt.removeEventListener("dispose",St)};dt.addEventListener("dispose",St),T.__depthDisposeCallback=St}T.__boundDepthTexture=dt}if(U.depthTexture&&!T.__autoAllocateDepthBuffer){if($)throw new Error("target.depthTexture not supported in Cube render targets");Ft(T.__webglFramebuffer,U)}else if($){T.__webglDepthbuffer=[];for(let dt=0;dt<6;dt++)if(i.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer[dt]),T.__webglDepthbuffer[dt]===void 0)T.__webglDepthbuffer[dt]=r.createRenderbuffer(),bt(T.__webglDepthbuffer[dt],U,!1);else{const St=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,mt=T.__webglDepthbuffer[dt];r.bindRenderbuffer(r.RENDERBUFFER,mt),r.framebufferRenderbuffer(r.FRAMEBUFFER,St,r.RENDERBUFFER,mt)}}else if(i.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=r.createRenderbuffer(),bt(T.__webglDepthbuffer,U,!1);else{const dt=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,St=T.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,St),r.framebufferRenderbuffer(r.FRAMEBUFFER,dt,r.RENDERBUFFER,St)}i.bindFramebuffer(r.FRAMEBUFFER,null)}function Yt(U,T,$){const dt=s.get(U);T!==void 0&&xt(dt.__webglFramebuffer,U,U.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),$!==void 0&&Xt(U)}function ze(U){const T=U.texture,$=s.get(U),dt=s.get(T);U.addEventListener("dispose",I);const St=U.textures,mt=U.isWebGLCubeRenderTarget===!0,Bt=St.length>1;if(Bt||(dt.__webglTexture===void 0&&(dt.__webglTexture=r.createTexture()),dt.__version=T.version,h.memory.textures++),mt){$.__webglFramebuffer=[];for(let Ct=0;Ct<6;Ct++)if(T.mipmaps&&T.mipmaps.length>0){$.__webglFramebuffer[Ct]=[];for(let It=0;It<T.mipmaps.length;It++)$.__webglFramebuffer[Ct][It]=r.createFramebuffer()}else $.__webglFramebuffer[Ct]=r.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){$.__webglFramebuffer=[];for(let Ct=0;Ct<T.mipmaps.length;Ct++)$.__webglFramebuffer[Ct]=r.createFramebuffer()}else $.__webglFramebuffer=r.createFramebuffer();if(Bt)for(let Ct=0,It=St.length;Ct<It;Ct++){const pe=s.get(St[Ct]);pe.__webglTexture===void 0&&(pe.__webglTexture=r.createTexture(),h.memory.textures++)}if(U.samples>0&&de(U)===!1){$.__webglMultisampledFramebuffer=r.createFramebuffer(),$.__webglColorRenderbuffer=[],i.bindFramebuffer(r.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let Ct=0;Ct<St.length;Ct++){const It=St[Ct];$.__webglColorRenderbuffer[Ct]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,$.__webglColorRenderbuffer[Ct]);const pe=c.convert(It.format,It.colorSpace),At=c.convert(It.type),Ht=N(It.internalFormat,pe,At,It.colorSpace,U.isXRRenderTarget===!0),Kt=le(U);r.renderbufferStorageMultisample(r.RENDERBUFFER,Kt,Ht,U.width,U.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ct,r.RENDERBUFFER,$.__webglColorRenderbuffer[Ct])}r.bindRenderbuffer(r.RENDERBUFFER,null),U.depthBuffer&&($.__webglDepthRenderbuffer=r.createRenderbuffer(),bt($.__webglDepthRenderbuffer,U,!0)),i.bindFramebuffer(r.FRAMEBUFFER,null)}}if(mt){i.bindTexture(r.TEXTURE_CUBE_MAP,dt.__webglTexture),at(r.TEXTURE_CUBE_MAP,T);for(let Ct=0;Ct<6;Ct++)if(T.mipmaps&&T.mipmaps.length>0)for(let It=0;It<T.mipmaps.length;It++)xt($.__webglFramebuffer[Ct][It],U,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Ct,It);else xt($.__webglFramebuffer[Ct],U,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Ct,0);M(T)&&x(r.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Bt){for(let Ct=0,It=St.length;Ct<It;Ct++){const pe=St[Ct],At=s.get(pe);i.bindTexture(r.TEXTURE_2D,At.__webglTexture),at(r.TEXTURE_2D,pe),xt($.__webglFramebuffer,U,pe,r.COLOR_ATTACHMENT0+Ct,r.TEXTURE_2D,0),M(pe)&&x(r.TEXTURE_2D)}i.unbindTexture()}else{let Ct=r.TEXTURE_2D;if((U.isWebGL3DRenderTarget||U.isWebGLArrayRenderTarget)&&(Ct=U.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(Ct,dt.__webglTexture),at(Ct,T),T.mipmaps&&T.mipmaps.length>0)for(let It=0;It<T.mipmaps.length;It++)xt($.__webglFramebuffer[It],U,T,r.COLOR_ATTACHMENT0,Ct,It);else xt($.__webglFramebuffer,U,T,r.COLOR_ATTACHMENT0,Ct,0);M(T)&&x(Ct),i.unbindTexture()}U.depthBuffer&&Xt(U)}function Ue(U){const T=U.textures;for(let $=0,dt=T.length;$<dt;$++){const St=T[$];if(M(St)){const mt=P(U),Bt=s.get(St).__webglTexture;i.bindTexture(mt,Bt),x(mt),i.unbindTexture()}}}const fe=[],G=[];function Je(U){if(U.samples>0){if(de(U)===!1){const T=U.textures,$=U.width,dt=U.height;let St=r.COLOR_BUFFER_BIT;const mt=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Bt=s.get(U),Ct=T.length>1;if(Ct)for(let It=0;It<T.length;It++)i.bindFramebuffer(r.FRAMEBUFFER,Bt.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+It,r.RENDERBUFFER,null),i.bindFramebuffer(r.FRAMEBUFFER,Bt.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+It,r.TEXTURE_2D,null,0);i.bindFramebuffer(r.READ_FRAMEBUFFER,Bt.__webglMultisampledFramebuffer),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Bt.__webglFramebuffer);for(let It=0;It<T.length;It++){if(U.resolveDepthBuffer&&(U.depthBuffer&&(St|=r.DEPTH_BUFFER_BIT),U.stencilBuffer&&U.resolveStencilBuffer&&(St|=r.STENCIL_BUFFER_BIT)),Ct){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Bt.__webglColorRenderbuffer[It]);const pe=s.get(T[It]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,pe,0)}r.blitFramebuffer(0,0,$,dt,0,0,$,dt,St,r.NEAREST),m===!0&&(fe.length=0,G.length=0,fe.push(r.COLOR_ATTACHMENT0+It),U.depthBuffer&&U.resolveDepthBuffer===!1&&(fe.push(mt),G.push(mt),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,G)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,fe))}if(i.bindFramebuffer(r.READ_FRAMEBUFFER,null),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),Ct)for(let It=0;It<T.length;It++){i.bindFramebuffer(r.FRAMEBUFFER,Bt.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+It,r.RENDERBUFFER,Bt.__webglColorRenderbuffer[It]);const pe=s.get(T[It]).__webglTexture;i.bindFramebuffer(r.FRAMEBUFFER,Bt.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+It,r.TEXTURE_2D,pe,0)}i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Bt.__webglMultisampledFramebuffer)}else if(U.depthBuffer&&U.resolveDepthBuffer===!1&&m){const T=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[T])}}}function le(U){return Math.min(l.maxSamples,U.samples)}function de(U){const T=s.get(U);return U.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function kt(U){const T=h.render.frame;g.get(U)!==T&&(g.set(U,T),U.update())}function Ae(U,T){const $=U.colorSpace,dt=U.format,St=U.type;return U.isCompressedTexture===!0||U.isVideoTexture===!0||$!==Vr&&$!==Xa&&(De.getTransfer($)===Ve?(dt!==wi||St!==pa)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",$)),T}function Rt(U){return typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement?(p.width=U.naturalWidth||U.width,p.height=U.naturalHeight||U.height):typeof VideoFrame<"u"&&U instanceof VideoFrame?(p.width=U.displayWidth,p.height=U.displayHeight):(p.width=U.width,p.height=U.height),p}this.allocateTextureUnit=et,this.resetTextureUnits=tt,this.setTexture2D=ft,this.setTexture2DArray=z,this.setTexture3D=W,this.setTextureCube=X,this.rebindTextures=Yt,this.setupRenderTarget=ze,this.updateRenderTargetMipmap=Ue,this.updateMultisampleRenderTarget=Je,this.setupDepthRenderbuffer=Xt,this.setupFrameBufferTexture=xt,this.useMultisampledRTT=de}function p2(r,t){function i(s,l=Xa){let c;const h=De.getTransfer(l);if(s===pa)return r.UNSIGNED_BYTE;if(s===Gd)return r.UNSIGNED_SHORT_4_4_4_4;if(s===Vd)return r.UNSIGNED_SHORT_5_5_5_1;if(s===rv)return r.UNSIGNED_INT_5_9_9_9_REV;if(s===av)return r.BYTE;if(s===sv)return r.SHORT;if(s===Zo)return r.UNSIGNED_SHORT;if(s===Hd)return r.INT;if(s===ws)return r.UNSIGNED_INT;if(s===fa)return r.FLOAT;if(s===Qo)return r.HALF_FLOAT;if(s===ov)return r.ALPHA;if(s===lv)return r.RGB;if(s===wi)return r.RGBA;if(s===cv)return r.LUMINANCE;if(s===uv)return r.LUMINANCE_ALPHA;if(s===Nr)return r.DEPTH_COMPONENT;if(s===Gr)return r.DEPTH_STENCIL;if(s===fv)return r.RED;if(s===kd)return r.RED_INTEGER;if(s===hv)return r.RG;if(s===jd)return r.RG_INTEGER;if(s===Xd)return r.RGBA_INTEGER;if(s===Bc||s===Fc||s===Hc||s===Gc)if(h===Ve)if(c=t.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(s===Bc)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Fc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Hc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Gc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=t.get("WEBGL_compressed_texture_s3tc"),c!==null){if(s===Bc)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Fc)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Hc)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Gc)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===ld||s===cd||s===ud||s===fd)if(c=t.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(s===ld)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===cd)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===ud)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===fd)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===hd||s===dd||s===pd)if(c=t.get("WEBGL_compressed_texture_etc"),c!==null){if(s===hd||s===dd)return h===Ve?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(s===pd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===md||s===gd||s===_d||s===vd||s===xd||s===yd||s===Sd||s===Md||s===bd||s===Ed||s===Td||s===Ad||s===Rd||s===Cd)if(c=t.get("WEBGL_compressed_texture_astc"),c!==null){if(s===md)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===gd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===_d)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===vd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===xd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===yd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Sd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Md)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===bd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Ed)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Td)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Ad)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Rd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Cd)return h===Ve?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Vc||s===wd||s===Dd)if(c=t.get("EXT_texture_compression_bptc"),c!==null){if(s===Vc)return h===Ve?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===wd)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Dd)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===dv||s===Ld||s===Ud||s===Nd)if(c=t.get("EXT_texture_compression_rgtc"),c!==null){if(s===Vc)return c.COMPRESSED_RED_RGTC1_EXT;if(s===Ld)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Ud)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Nd)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===Hr?r.UNSIGNED_INT_24_8:r[s]!==void 0?r[s]:null}return{convert:i}}const m2=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,g2=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class _2{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,i,s){if(this.texture===null){const l=new Hn,c=t.properties.get(l);c.__webglTexture=i.texture,(i.depthNear!==s.depthNear||i.depthFar!==s.depthFar)&&(this.depthNear=i.depthNear,this.depthFar=i.depthFar),this.texture=l}}getMesh(t){if(this.texture!==null&&this.mesh===null){const i=t.cameras[0].viewport,s=new Hi({vertexShader:m2,fragmentShader:g2,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new Qe(new eu(20,20),s)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class v2 extends Us{constructor(t,i){super();const s=this;let l=null,c=1,h=null,d="local-floor",m=1,p=null,g=null,_=null,y=null,v=null,b=null;const E=new _2,M=i.getContextAttributes();let x=null,P=null;const N=[],w=[],k=new se;let H=null;const I=new vi;I.viewport=new an;const j=new vi;j.viewport=new an;const L=[I,j],R=new B1;let B=null,tt=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let st=N[Y];return st===void 0&&(st=new Bh,N[Y]=st),st.getTargetRaySpace()},this.getControllerGrip=function(Y){let st=N[Y];return st===void 0&&(st=new Bh,N[Y]=st),st.getGripSpace()},this.getHand=function(Y){let st=N[Y];return st===void 0&&(st=new Bh,N[Y]=st),st.getHandSpace()};function et(Y){const st=w.indexOf(Y.inputSource);if(st===-1)return;const xt=N[st];xt!==void 0&&(xt.update(Y.inputSource,Y.frame,p||h),xt.dispatchEvent({type:Y.type,data:Y.inputSource}))}function ut(){l.removeEventListener("select",et),l.removeEventListener("selectstart",et),l.removeEventListener("selectend",et),l.removeEventListener("squeeze",et),l.removeEventListener("squeezestart",et),l.removeEventListener("squeezeend",et),l.removeEventListener("end",ut),l.removeEventListener("inputsourceschange",ft);for(let Y=0;Y<N.length;Y++){const st=w[Y];st!==null&&(w[Y]=null,N[Y].disconnect(st))}B=null,tt=null,E.reset(),t.setRenderTarget(x),v=null,y=null,_=null,l=null,P=null,vt.stop(),s.isPresenting=!1,t.setPixelRatio(H),t.setSize(k.width,k.height,!1),s.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){c=Y,s.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){d=Y,s.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return p||h},this.setReferenceSpace=function(Y){p=Y},this.getBaseLayer=function(){return y!==null?y:v},this.getBinding=function(){return _},this.getFrame=function(){return b},this.getSession=function(){return l},this.setSession=async function(Y){if(l=Y,l!==null){if(x=t.getRenderTarget(),l.addEventListener("select",et),l.addEventListener("selectstart",et),l.addEventListener("selectend",et),l.addEventListener("squeeze",et),l.addEventListener("squeezestart",et),l.addEventListener("squeezeend",et),l.addEventListener("end",ut),l.addEventListener("inputsourceschange",ft),M.xrCompatible!==!0&&await i.makeXRCompatible(),H=t.getPixelRatio(),t.getSize(k),typeof XRWebGLBinding<"u"&&"createProjectionLayer"in XRWebGLBinding.prototype){let xt=null,bt=null,Ft=null;M.depth&&(Ft=M.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,xt=M.stencil?Gr:Nr,bt=M.stencil?Hr:ws);const Xt={colorFormat:i.RGBA8,depthFormat:Ft,scaleFactor:c};_=new XRWebGLBinding(l,i),y=_.createProjectionLayer(Xt),l.updateRenderState({layers:[y]}),t.setPixelRatio(1),t.setSize(y.textureWidth,y.textureHeight,!1),P=new Ds(y.textureWidth,y.textureHeight,{format:wi,type:pa,depthTexture:new Av(y.textureWidth,y.textureHeight,bt,void 0,void 0,void 0,void 0,void 0,void 0,xt),stencilBuffer:M.stencil,colorSpace:t.outputColorSpace,samples:M.antialias?4:0,resolveDepthBuffer:y.ignoreDepthValues===!1,resolveStencilBuffer:y.ignoreDepthValues===!1})}else{const xt={antialias:M.antialias,alpha:!0,depth:M.depth,stencil:M.stencil,framebufferScaleFactor:c};v=new XRWebGLLayer(l,i,xt),l.updateRenderState({baseLayer:v}),t.setPixelRatio(1),t.setSize(v.framebufferWidth,v.framebufferHeight,!1),P=new Ds(v.framebufferWidth,v.framebufferHeight,{format:wi,type:pa,colorSpace:t.outputColorSpace,stencilBuffer:M.stencil,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1})}P.isXRRenderTarget=!0,this.setFoveation(m),p=null,h=await l.requestReferenceSpace(d),vt.setContext(l),vt.start(),s.isPresenting=!0,s.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return E.getDepthTexture()};function ft(Y){for(let st=0;st<Y.removed.length;st++){const xt=Y.removed[st],bt=w.indexOf(xt);bt>=0&&(w[bt]=null,N[bt].disconnect(xt))}for(let st=0;st<Y.added.length;st++){const xt=Y.added[st];let bt=w.indexOf(xt);if(bt===-1){for(let Xt=0;Xt<N.length;Xt++)if(Xt>=w.length){w.push(xt),bt=Xt;break}else if(w[Xt]===null){w[Xt]=xt,bt=Xt;break}if(bt===-1)break}const Ft=N[bt];Ft&&Ft.connect(xt)}}const z=new J,W=new J;function X(Y,st,xt){z.setFromMatrixPosition(st.matrixWorld),W.setFromMatrixPosition(xt.matrixWorld);const bt=z.distanceTo(W),Ft=st.projectionMatrix.elements,Xt=xt.projectionMatrix.elements,Yt=Ft[14]/(Ft[10]-1),ze=Ft[14]/(Ft[10]+1),Ue=(Ft[9]+1)/Ft[5],fe=(Ft[9]-1)/Ft[5],G=(Ft[8]-1)/Ft[0],Je=(Xt[8]+1)/Xt[0],le=Yt*G,de=Yt*Je,kt=bt/(-G+Je),Ae=kt*-G;if(st.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(Ae),Y.translateZ(kt),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),Ft[10]===-1)Y.projectionMatrix.copy(st.projectionMatrix),Y.projectionMatrixInverse.copy(st.projectionMatrixInverse);else{const Rt=Yt+kt,U=ze+kt,T=le-Ae,$=de+(bt-Ae),dt=Ue*ze/U*Rt,St=fe*ze/U*Rt;Y.projectionMatrix.makePerspective(T,$,dt,St,Rt,U),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function _t(Y,st){st===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(st.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(l===null)return;let st=Y.near,xt=Y.far;E.texture!==null&&(E.depthNear>0&&(st=E.depthNear),E.depthFar>0&&(xt=E.depthFar)),R.near=j.near=I.near=st,R.far=j.far=I.far=xt,(B!==R.near||tt!==R.far)&&(l.updateRenderState({depthNear:R.near,depthFar:R.far}),B=R.near,tt=R.far),I.layers.mask=Y.layers.mask|2,j.layers.mask=Y.layers.mask|4,R.layers.mask=I.layers.mask|j.layers.mask;const bt=Y.parent,Ft=R.cameras;_t(R,bt);for(let Xt=0;Xt<Ft.length;Xt++)_t(Ft[Xt],bt);Ft.length===2?X(R,I,j):R.projectionMatrix.copy(I.projectionMatrix),Et(Y,R,bt)};function Et(Y,st,xt){xt===null?Y.matrix.copy(st.matrixWorld):(Y.matrix.copy(xt.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(st.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(st.projectionMatrix),Y.projectionMatrixInverse.copy(st.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=Od*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return R},this.getFoveation=function(){if(!(y===null&&v===null))return m},this.setFoveation=function(Y){m=Y,y!==null&&(y.fixedFoveation=Y),v!==null&&v.fixedFoveation!==void 0&&(v.fixedFoveation=Y)},this.hasDepthSensing=function(){return E.texture!==null},this.getDepthSensingMesh=function(){return E.getMesh(R)};let O=null;function at(Y,st){if(g=st.getViewerPose(p||h),b=st,g!==null){const xt=g.views;v!==null&&(t.setRenderTargetFramebuffer(P,v.framebuffer),t.setRenderTarget(P));let bt=!1;xt.length!==R.cameras.length&&(R.cameras.length=0,bt=!0);for(let Yt=0;Yt<xt.length;Yt++){const ze=xt[Yt];let Ue=null;if(v!==null)Ue=v.getViewport(ze);else{const G=_.getViewSubImage(y,ze);Ue=G.viewport,Yt===0&&(t.setRenderTargetTextures(P,G.colorTexture,y.ignoreDepthValues?void 0:G.depthStencilTexture),t.setRenderTarget(P))}let fe=L[Yt];fe===void 0&&(fe=new vi,fe.layers.enable(Yt),fe.viewport=new an,L[Yt]=fe),fe.matrix.fromArray(ze.transform.matrix),fe.matrix.decompose(fe.position,fe.quaternion,fe.scale),fe.projectionMatrix.fromArray(ze.projectionMatrix),fe.projectionMatrixInverse.copy(fe.projectionMatrix).invert(),fe.viewport.set(Ue.x,Ue.y,Ue.width,Ue.height),Yt===0&&(R.matrix.copy(fe.matrix),R.matrix.decompose(R.position,R.quaternion,R.scale)),bt===!0&&R.cameras.push(fe)}const Ft=l.enabledFeatures;if(Ft&&Ft.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&_){const Yt=_.getDepthInformation(xt[0]);Yt&&Yt.isValid&&Yt.texture&&E.init(t,Yt,l.renderState)}}for(let xt=0;xt<N.length;xt++){const bt=w[xt],Ft=N[xt];bt!==null&&Ft!==void 0&&Ft.update(bt,st,p||h)}O&&O(Y,st),st.detectedPlanes&&s.dispatchEvent({type:"planesdetected",data:st}),b=null}const vt=new Cv;vt.setAnimationLoop(at),this.setAnimationLoop=function(Y){O=Y},this.dispose=function(){}}}const bs=new Fi,x2=new Ke;function y2(r,t){function i(M,x){M.matrixAutoUpdate===!0&&M.updateMatrix(),x.value.copy(M.matrix)}function s(M,x){x.color.getRGB(M.fogColor.value,Mv(r)),x.isFog?(M.fogNear.value=x.near,M.fogFar.value=x.far):x.isFogExp2&&(M.fogDensity.value=x.density)}function l(M,x,P,N,w){x.isMeshBasicMaterial||x.isMeshLambertMaterial?c(M,x):x.isMeshToonMaterial?(c(M,x),_(M,x)):x.isMeshPhongMaterial?(c(M,x),g(M,x)):x.isMeshStandardMaterial?(c(M,x),y(M,x),x.isMeshPhysicalMaterial&&v(M,x,w)):x.isMeshMatcapMaterial?(c(M,x),b(M,x)):x.isMeshDepthMaterial?c(M,x):x.isMeshDistanceMaterial?(c(M,x),E(M,x)):x.isMeshNormalMaterial?c(M,x):x.isLineBasicMaterial?(h(M,x),x.isLineDashedMaterial&&d(M,x)):x.isPointsMaterial?m(M,x,P,N):x.isSpriteMaterial?p(M,x):x.isShadowMaterial?(M.color.value.copy(x.color),M.opacity.value=x.opacity):x.isShaderMaterial&&(x.uniformsNeedUpdate=!1)}function c(M,x){M.opacity.value=x.opacity,x.color&&M.diffuse.value.copy(x.color),x.emissive&&M.emissive.value.copy(x.emissive).multiplyScalar(x.emissiveIntensity),x.map&&(M.map.value=x.map,i(x.map,M.mapTransform)),x.alphaMap&&(M.alphaMap.value=x.alphaMap,i(x.alphaMap,M.alphaMapTransform)),x.bumpMap&&(M.bumpMap.value=x.bumpMap,i(x.bumpMap,M.bumpMapTransform),M.bumpScale.value=x.bumpScale,x.side===Fn&&(M.bumpScale.value*=-1)),x.normalMap&&(M.normalMap.value=x.normalMap,i(x.normalMap,M.normalMapTransform),M.normalScale.value.copy(x.normalScale),x.side===Fn&&M.normalScale.value.negate()),x.displacementMap&&(M.displacementMap.value=x.displacementMap,i(x.displacementMap,M.displacementMapTransform),M.displacementScale.value=x.displacementScale,M.displacementBias.value=x.displacementBias),x.emissiveMap&&(M.emissiveMap.value=x.emissiveMap,i(x.emissiveMap,M.emissiveMapTransform)),x.specularMap&&(M.specularMap.value=x.specularMap,i(x.specularMap,M.specularMapTransform)),x.alphaTest>0&&(M.alphaTest.value=x.alphaTest);const P=t.get(x),N=P.envMap,w=P.envMapRotation;N&&(M.envMap.value=N,bs.copy(w),bs.x*=-1,bs.y*=-1,bs.z*=-1,N.isCubeTexture&&N.isRenderTargetTexture===!1&&(bs.y*=-1,bs.z*=-1),M.envMapRotation.value.setFromMatrix4(x2.makeRotationFromEuler(bs)),M.flipEnvMap.value=N.isCubeTexture&&N.isRenderTargetTexture===!1?-1:1,M.reflectivity.value=x.reflectivity,M.ior.value=x.ior,M.refractionRatio.value=x.refractionRatio),x.lightMap&&(M.lightMap.value=x.lightMap,M.lightMapIntensity.value=x.lightMapIntensity,i(x.lightMap,M.lightMapTransform)),x.aoMap&&(M.aoMap.value=x.aoMap,M.aoMapIntensity.value=x.aoMapIntensity,i(x.aoMap,M.aoMapTransform))}function h(M,x){M.diffuse.value.copy(x.color),M.opacity.value=x.opacity,x.map&&(M.map.value=x.map,i(x.map,M.mapTransform))}function d(M,x){M.dashSize.value=x.dashSize,M.totalSize.value=x.dashSize+x.gapSize,M.scale.value=x.scale}function m(M,x,P,N){M.diffuse.value.copy(x.color),M.opacity.value=x.opacity,M.size.value=x.size*P,M.scale.value=N*.5,x.map&&(M.map.value=x.map,i(x.map,M.uvTransform)),x.alphaMap&&(M.alphaMap.value=x.alphaMap,i(x.alphaMap,M.alphaMapTransform)),x.alphaTest>0&&(M.alphaTest.value=x.alphaTest)}function p(M,x){M.diffuse.value.copy(x.color),M.opacity.value=x.opacity,M.rotation.value=x.rotation,x.map&&(M.map.value=x.map,i(x.map,M.mapTransform)),x.alphaMap&&(M.alphaMap.value=x.alphaMap,i(x.alphaMap,M.alphaMapTransform)),x.alphaTest>0&&(M.alphaTest.value=x.alphaTest)}function g(M,x){M.specular.value.copy(x.specular),M.shininess.value=Math.max(x.shininess,1e-4)}function _(M,x){x.gradientMap&&(M.gradientMap.value=x.gradientMap)}function y(M,x){M.metalness.value=x.metalness,x.metalnessMap&&(M.metalnessMap.value=x.metalnessMap,i(x.metalnessMap,M.metalnessMapTransform)),M.roughness.value=x.roughness,x.roughnessMap&&(M.roughnessMap.value=x.roughnessMap,i(x.roughnessMap,M.roughnessMapTransform)),x.envMap&&(M.envMapIntensity.value=x.envMapIntensity)}function v(M,x,P){M.ior.value=x.ior,x.sheen>0&&(M.sheenColor.value.copy(x.sheenColor).multiplyScalar(x.sheen),M.sheenRoughness.value=x.sheenRoughness,x.sheenColorMap&&(M.sheenColorMap.value=x.sheenColorMap,i(x.sheenColorMap,M.sheenColorMapTransform)),x.sheenRoughnessMap&&(M.sheenRoughnessMap.value=x.sheenRoughnessMap,i(x.sheenRoughnessMap,M.sheenRoughnessMapTransform))),x.clearcoat>0&&(M.clearcoat.value=x.clearcoat,M.clearcoatRoughness.value=x.clearcoatRoughness,x.clearcoatMap&&(M.clearcoatMap.value=x.clearcoatMap,i(x.clearcoatMap,M.clearcoatMapTransform)),x.clearcoatRoughnessMap&&(M.clearcoatRoughnessMap.value=x.clearcoatRoughnessMap,i(x.clearcoatRoughnessMap,M.clearcoatRoughnessMapTransform)),x.clearcoatNormalMap&&(M.clearcoatNormalMap.value=x.clearcoatNormalMap,i(x.clearcoatNormalMap,M.clearcoatNormalMapTransform),M.clearcoatNormalScale.value.copy(x.clearcoatNormalScale),x.side===Fn&&M.clearcoatNormalScale.value.negate())),x.dispersion>0&&(M.dispersion.value=x.dispersion),x.iridescence>0&&(M.iridescence.value=x.iridescence,M.iridescenceIOR.value=x.iridescenceIOR,M.iridescenceThicknessMinimum.value=x.iridescenceThicknessRange[0],M.iridescenceThicknessMaximum.value=x.iridescenceThicknessRange[1],x.iridescenceMap&&(M.iridescenceMap.value=x.iridescenceMap,i(x.iridescenceMap,M.iridescenceMapTransform)),x.iridescenceThicknessMap&&(M.iridescenceThicknessMap.value=x.iridescenceThicknessMap,i(x.iridescenceThicknessMap,M.iridescenceThicknessMapTransform))),x.transmission>0&&(M.transmission.value=x.transmission,M.transmissionSamplerMap.value=P.texture,M.transmissionSamplerSize.value.set(P.width,P.height),x.transmissionMap&&(M.transmissionMap.value=x.transmissionMap,i(x.transmissionMap,M.transmissionMapTransform)),M.thickness.value=x.thickness,x.thicknessMap&&(M.thicknessMap.value=x.thicknessMap,i(x.thicknessMap,M.thicknessMapTransform)),M.attenuationDistance.value=x.attenuationDistance,M.attenuationColor.value.copy(x.attenuationColor)),x.anisotropy>0&&(M.anisotropyVector.value.set(x.anisotropy*Math.cos(x.anisotropyRotation),x.anisotropy*Math.sin(x.anisotropyRotation)),x.anisotropyMap&&(M.anisotropyMap.value=x.anisotropyMap,i(x.anisotropyMap,M.anisotropyMapTransform))),M.specularIntensity.value=x.specularIntensity,M.specularColor.value.copy(x.specularColor),x.specularColorMap&&(M.specularColorMap.value=x.specularColorMap,i(x.specularColorMap,M.specularColorMapTransform)),x.specularIntensityMap&&(M.specularIntensityMap.value=x.specularIntensityMap,i(x.specularIntensityMap,M.specularIntensityMapTransform))}function b(M,x){x.matcap&&(M.matcap.value=x.matcap)}function E(M,x){const P=t.get(x).light;M.referencePosition.value.setFromMatrixPosition(P.matrixWorld),M.nearDistance.value=P.shadow.camera.near,M.farDistance.value=P.shadow.camera.far}return{refreshFogUniforms:s,refreshMaterialUniforms:l}}function S2(r,t,i,s){let l={},c={},h=[];const d=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function m(P,N){const w=N.program;s.uniformBlockBinding(P,w)}function p(P,N){let w=l[P.id];w===void 0&&(b(P),w=g(P),l[P.id]=w,P.addEventListener("dispose",M));const k=N.program;s.updateUBOMapping(P,k);const H=t.render.frame;c[P.id]!==H&&(y(P),c[P.id]=H)}function g(P){const N=_();P.__bindingPointIndex=N;const w=r.createBuffer(),k=P.__size,H=P.usage;return r.bindBuffer(r.UNIFORM_BUFFER,w),r.bufferData(r.UNIFORM_BUFFER,k,H),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,N,w),w}function _(){for(let P=0;P<d;P++)if(h.indexOf(P)===-1)return h.push(P),P;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function y(P){const N=l[P.id],w=P.uniforms,k=P.__cache;r.bindBuffer(r.UNIFORM_BUFFER,N);for(let H=0,I=w.length;H<I;H++){const j=Array.isArray(w[H])?w[H]:[w[H]];for(let L=0,R=j.length;L<R;L++){const B=j[L];if(v(B,H,L,k)===!0){const tt=B.__offset,et=Array.isArray(B.value)?B.value:[B.value];let ut=0;for(let ft=0;ft<et.length;ft++){const z=et[ft],W=E(z);typeof z=="number"||typeof z=="boolean"?(B.__data[0]=z,r.bufferSubData(r.UNIFORM_BUFFER,tt+ut,B.__data)):z.isMatrix3?(B.__data[0]=z.elements[0],B.__data[1]=z.elements[1],B.__data[2]=z.elements[2],B.__data[3]=0,B.__data[4]=z.elements[3],B.__data[5]=z.elements[4],B.__data[6]=z.elements[5],B.__data[7]=0,B.__data[8]=z.elements[6],B.__data[9]=z.elements[7],B.__data[10]=z.elements[8],B.__data[11]=0):(z.toArray(B.__data,ut),ut+=W.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,tt,B.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function v(P,N,w,k){const H=P.value,I=N+"_"+w;if(k[I]===void 0)return typeof H=="number"||typeof H=="boolean"?k[I]=H:k[I]=H.clone(),!0;{const j=k[I];if(typeof H=="number"||typeof H=="boolean"){if(j!==H)return k[I]=H,!0}else if(j.equals(H)===!1)return j.copy(H),!0}return!1}function b(P){const N=P.uniforms;let w=0;const k=16;for(let I=0,j=N.length;I<j;I++){const L=Array.isArray(N[I])?N[I]:[N[I]];for(let R=0,B=L.length;R<B;R++){const tt=L[R],et=Array.isArray(tt.value)?tt.value:[tt.value];for(let ut=0,ft=et.length;ut<ft;ut++){const z=et[ut],W=E(z),X=w%k,_t=X%W.boundary,Et=X+_t;w+=_t,Et!==0&&k-Et<W.storage&&(w+=k-Et),tt.__data=new Float32Array(W.storage/Float32Array.BYTES_PER_ELEMENT),tt.__offset=w,w+=W.storage}}}const H=w%k;return H>0&&(w+=k-H),P.__size=w,P.__cache={},this}function E(P){const N={boundary:0,storage:0};return typeof P=="number"||typeof P=="boolean"?(N.boundary=4,N.storage=4):P.isVector2?(N.boundary=8,N.storage=8):P.isVector3||P.isColor?(N.boundary=16,N.storage=12):P.isVector4?(N.boundary=16,N.storage=16):P.isMatrix3?(N.boundary=48,N.storage=48):P.isMatrix4?(N.boundary=64,N.storage=64):P.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",P),N}function M(P){const N=P.target;N.removeEventListener("dispose",M);const w=h.indexOf(N.__bindingPointIndex);h.splice(w,1),r.deleteBuffer(l[N.id]),delete l[N.id],delete c[N.id]}function x(){for(const P in l)r.deleteBuffer(l[P]);h=[],l={},c={}}return{bind:m,update:p,dispose:x}}class M2{constructor(t={}){const{canvas:i=KS(),context:s=null,depth:l=!0,stencil:c=!1,alpha:h=!1,antialias:d=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:p=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:_=!1,reverseDepthBuffer:y=!1}=t;this.isWebGLRenderer=!0;let v;if(s!==null){if(typeof WebGLRenderingContext<"u"&&s instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");v=s.getContextAttributes().alpha}else v=h;const b=new Uint32Array(4),E=new Int32Array(4);let M=null,x=null;const P=[],N=[];this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Bn,this.toneMapping=Ka,this.toneMappingExposure=1;const w=this;let k=!1,H=0,I=0,j=null,L=-1,R=null;const B=new an,tt=new an;let et=null;const ut=new be(0);let ft=0,z=i.width,W=i.height,X=1,_t=null,Et=null;const O=new an(0,0,z,W),at=new an(0,0,z,W);let vt=!1;const Y=new qd;let st=!1,xt=!1;this.transmissionResolutionScale=1;const bt=new Ke,Ft=new Ke,Xt=new J,Yt=new an,ze={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ue=!1;function fe(){return j===null?X:1}let G=s;function Je(C,K){return i.getContext(C,K)}try{const C={alpha:!0,depth:l,stencil:c,antialias:d,premultipliedAlpha:m,preserveDrawingBuffer:p,powerPreference:g,failIfMajorPerformanceCaveat:_};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${Fd}`),i.addEventListener("webglcontextlost",Mt,!1),i.addEventListener("webglcontextrestored",Dt,!1),i.addEventListener("webglcontextcreationerror",Lt,!1),G===null){const K="webgl2";if(G=Je(K,C),G===null)throw Je(K)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let le,de,kt,Ae,Rt,U,T,$,dt,St,mt,Bt,Ct,It,pe,At,Ht,Kt,jt,Pt,Jt,re,Ie,Z;function wt(){le=new UE(G),le.init(),re=new p2(G,le),de=new TE(G,le,t,re),kt=new h2(G,le),de.reverseDepthBuffer&&y&&kt.buffers.depth.setReversed(!0),Ae=new PE(G),Rt=new $T,U=new d2(G,le,kt,Rt,de,re,Ae),T=new RE(w),$=new LE(w),dt=new G1(G),Ie=new bE(G,dt),St=new NE(G,dt,Ae,Ie),mt=new IE(G,St,dt,Ae),jt=new zE(G,de,U),At=new AE(Rt),Bt=new JT(w,T,$,le,de,Ie,At),Ct=new y2(w,Rt),It=new e2,pe=new o2(le),Kt=new ME(w,T,$,kt,mt,v,m),Ht=new u2(w,mt,de),Z=new S2(G,Ae,de,kt),Pt=new EE(G,le,Ae),Jt=new OE(G,le,Ae),Ae.programs=Bt.programs,w.capabilities=de,w.extensions=le,w.properties=Rt,w.renderLists=It,w.shadowMap=Ht,w.state=kt,w.info=Ae}wt();const ht=new v2(w,G);this.xr=ht,this.getContext=function(){return G},this.getContextAttributes=function(){return G.getContextAttributes()},this.forceContextLoss=function(){const C=le.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=le.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(C){C!==void 0&&(X=C,this.setSize(z,W,!1))},this.getSize=function(C){return C.set(z,W)},this.setSize=function(C,K,ot=!0){if(ht.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}z=C,W=K,i.width=Math.floor(C*X),i.height=Math.floor(K*X),ot===!0&&(i.style.width=C+"px",i.style.height=K+"px"),this.setViewport(0,0,C,K)},this.getDrawingBufferSize=function(C){return C.set(z*X,W*X).floor()},this.setDrawingBufferSize=function(C,K,ot){z=C,W=K,X=ot,i.width=Math.floor(C*ot),i.height=Math.floor(K*ot),this.setViewport(0,0,C,K)},this.getCurrentViewport=function(C){return C.copy(B)},this.getViewport=function(C){return C.copy(O)},this.setViewport=function(C,K,ot,lt){C.isVector4?O.set(C.x,C.y,C.z,C.w):O.set(C,K,ot,lt),kt.viewport(B.copy(O).multiplyScalar(X).round())},this.getScissor=function(C){return C.copy(at)},this.setScissor=function(C,K,ot,lt){C.isVector4?at.set(C.x,C.y,C.z,C.w):at.set(C,K,ot,lt),kt.scissor(tt.copy(at).multiplyScalar(X).round())},this.getScissorTest=function(){return vt},this.setScissorTest=function(C){kt.setScissorTest(vt=C)},this.setOpaqueSort=function(C){_t=C},this.setTransparentSort=function(C){Et=C},this.getClearColor=function(C){return C.copy(Kt.getClearColor())},this.setClearColor=function(){Kt.setClearColor(...arguments)},this.getClearAlpha=function(){return Kt.getClearAlpha()},this.setClearAlpha=function(){Kt.setClearAlpha(...arguments)},this.clear=function(C=!0,K=!0,ot=!0){let lt=0;if(C){let q=!1;if(j!==null){const Tt=j.texture.format;q=Tt===Xd||Tt===jd||Tt===kd}if(q){const Tt=j.texture.type,Ut=Tt===pa||Tt===ws||Tt===Zo||Tt===Hr||Tt===Gd||Tt===Vd,Ot=Kt.getClearColor(),zt=Kt.getClearAlpha(),te=Ot.r,ee=Ot.g,Wt=Ot.b;Ut?(b[0]=te,b[1]=ee,b[2]=Wt,b[3]=zt,G.clearBufferuiv(G.COLOR,0,b)):(E[0]=te,E[1]=ee,E[2]=Wt,E[3]=zt,G.clearBufferiv(G.COLOR,0,E))}else lt|=G.COLOR_BUFFER_BIT}K&&(lt|=G.DEPTH_BUFFER_BIT),ot&&(lt|=G.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),G.clear(lt)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){i.removeEventListener("webglcontextlost",Mt,!1),i.removeEventListener("webglcontextrestored",Dt,!1),i.removeEventListener("webglcontextcreationerror",Lt,!1),Kt.dispose(),It.dispose(),pe.dispose(),Rt.dispose(),T.dispose(),$.dispose(),mt.dispose(),Ie.dispose(),Z.dispose(),Bt.dispose(),ht.dispose(),ht.removeEventListener("sessionstart",Wr),ht.removeEventListener("sessionend",qr),Li.stop()};function Mt(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),k=!0}function Dt(){console.log("THREE.WebGLRenderer: Context Restored."),k=!1;const C=Ae.autoReset,K=Ht.enabled,ot=Ht.autoUpdate,lt=Ht.needsUpdate,q=Ht.type;wt(),Ae.autoReset=C,Ht.enabled=K,Ht.autoUpdate=ot,Ht.needsUpdate=lt,Ht.type=q}function Lt(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function $t(C){const K=C.target;K.removeEventListener("dispose",$t),Ye(K)}function Ye(C){hn(C),Rt.remove(C)}function hn(C){const K=Rt.get(C).programs;K!==void 0&&(K.forEach(function(ot){Bt.releaseProgram(ot)}),C.isShaderMaterial&&Bt.releaseShaderCache(C))}this.renderBufferDirect=function(C,K,ot,lt,q,Tt){K===null&&(K=ze);const Ut=q.isMesh&&q.matrixWorld.determinant()<0,Ot=Zr(C,K,ot,lt,q);kt.setMaterial(lt,Ut);let zt=ot.index,te=1;if(lt.wireframe===!0){if(zt=St.getWireframeAttribute(ot),zt===void 0)return;te=2}const ee=ot.drawRange,Wt=ot.attributes.position;let ye=ee.start*te,Se=(ee.start+ee.count)*te;Tt!==null&&(ye=Math.max(ye,Tt.start*te),Se=Math.min(Se,(Tt.start+Tt.count)*te)),zt!==null?(ye=Math.max(ye,0),Se=Math.min(Se,zt.count)):Wt!=null&&(ye=Math.max(ye,0),Se=Math.min(Se,Wt.count));const Xe=Se-ye;if(Xe<0||Xe===1/0)return;Ie.setup(q,lt,Ot,ot,zt);let Re,ie=Pt;if(zt!==null&&(Re=dt.get(zt),ie=Jt,ie.setIndex(Re)),q.isMesh)lt.wireframe===!0?(kt.setLineWidth(lt.wireframeLinewidth*fe()),ie.setMode(G.LINES)):ie.setMode(G.TRIANGLES);else if(q.isLine){let Zt=lt.linewidth;Zt===void 0&&(Zt=1),kt.setLineWidth(Zt*fe()),q.isLineSegments?ie.setMode(G.LINES):q.isLineLoop?ie.setMode(G.LINE_LOOP):ie.setMode(G.LINE_STRIP)}else q.isPoints?ie.setMode(G.POINTS):q.isSprite&&ie.setMode(G.TRIANGLES);if(q.isBatchedMesh)if(q._multiDrawInstances!==null)Es("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),ie.renderMultiDrawInstances(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount,q._multiDrawInstances);else if(le.get("WEBGL_multi_draw"))ie.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{const Zt=q._multiDrawStarts,dn=q._multiDrawCounts,Ee=q._multiDrawCount,Vn=zt?dt.get(zt).bytesPerElement:1,Si=Rt.get(lt).currentProgram.getUniforms();for(let On=0;On<Ee;On++)Si.setValue(G,"_gl_DrawID",On),ie.render(Zt[On]/Vn,dn[On])}else if(q.isInstancedMesh)ie.renderInstances(ye,Xe,q.count);else if(ot.isInstancedBufferGeometry){const Zt=ot._maxInstanceCount!==void 0?ot._maxInstanceCount:1/0,dn=Math.min(ot.instanceCount,Zt);ie.renderInstances(ye,Xe,dn)}else ie.render(ye,Xe)};function Te(C,K,ot){C.transparent===!0&&C.side===li&&C.forceSinglePass===!1?(C.side=Fn,C.needsUpdate=!0,$e(C,K,ot),C.side=Ja,C.needsUpdate=!0,$e(C,K,ot),C.side=li):$e(C,K,ot)}this.compile=function(C,K,ot=null){ot===null&&(ot=C),x=pe.get(ot),x.init(K),N.push(x),ot.traverseVisible(function(q){q.isLight&&q.layers.test(K.layers)&&(x.pushLight(q),q.castShadow&&x.pushShadow(q))}),C!==ot&&C.traverseVisible(function(q){q.isLight&&q.layers.test(K.layers)&&(x.pushLight(q),q.castShadow&&x.pushShadow(q))}),x.setupLights();const lt=new Set;return C.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;const Tt=q.material;if(Tt)if(Array.isArray(Tt))for(let Ut=0;Ut<Tt.length;Ut++){const Ot=Tt[Ut];Te(Ot,ot,q),lt.add(Ot)}else Te(Tt,ot,q),lt.add(Tt)}),x=N.pop(),lt},this.compileAsync=function(C,K,ot=null){const lt=this.compile(C,K,ot);return new Promise(q=>{function Tt(){if(lt.forEach(function(Ut){Rt.get(Ut).currentProgram.isReady()&&lt.delete(Ut)}),lt.size===0){q(C);return}setTimeout(Tt,10)}le.get("KHR_parallel_shader_compile")!==null?Tt():setTimeout(Tt,10)})};let Mn=null;function xi(C){Mn&&Mn(C)}function Wr(){Li.stop()}function qr(){Li.start()}const Li=new Cv;Li.setAnimationLoop(xi),typeof self<"u"&&Li.setContext(self),this.setAnimationLoop=function(C){Mn=C,ht.setAnimationLoop(C),C===null?Li.stop():Li.start()},ht.addEventListener("sessionstart",Wr),ht.addEventListener("sessionend",qr),this.render=function(C,K){if(K!==void 0&&K.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(k===!0)return;if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),K.parent===null&&K.matrixWorldAutoUpdate===!0&&K.updateMatrixWorld(),ht.enabled===!0&&ht.isPresenting===!0&&(ht.cameraAutoUpdate===!0&&ht.updateCamera(K),K=ht.getCamera()),C.isScene===!0&&C.onBeforeRender(w,C,K,j),x=pe.get(C,N.length),x.init(K),N.push(x),Ft.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),Y.setFromProjectionMatrix(Ft),xt=this.localClippingEnabled,st=At.init(this.clippingPlanes,xt),M=It.get(C,P.length),M.init(),P.push(M),ht.enabled===!0&&ht.isPresenting===!0){const Tt=w.xr.getDepthSensingMesh();Tt!==null&&$a(Tt,K,-1/0,w.sortObjects)}$a(C,K,0,w.sortObjects),M.finish(),w.sortObjects===!0&&M.sort(_t,Et),Ue=ht.enabled===!1||ht.isPresenting===!1||ht.hasDepthSensing()===!1,Ue&&Kt.addToRenderList(M,C),this.info.render.frame++,st===!0&&At.beginShadows();const ot=x.state.shadowsArray;Ht.render(ot,C,K),st===!0&&At.endShadows(),this.info.autoReset===!0&&this.info.reset();const lt=M.opaque,q=M.transmissive;if(x.setupLights(),K.isArrayCamera){const Tt=K.cameras;if(q.length>0)for(let Ut=0,Ot=Tt.length;Ut<Ot;Ut++){const zt=Tt[Ut];Yr(lt,q,C,zt)}Ue&&Kt.render(C);for(let Ut=0,Ot=Tt.length;Ut<Ot;Ut++){const zt=Tt[Ut];Os(M,C,zt,zt.viewport)}}else q.length>0&&Yr(lt,q,C,K),Ue&&Kt.render(C),Os(M,C,K);j!==null&&I===0&&(U.updateMultisampleRenderTarget(j),U.updateRenderTargetMipmap(j)),C.isScene===!0&&C.onAfterRender(w,C,K),Ie.resetDefaultState(),L=-1,R=null,N.pop(),N.length>0?(x=N[N.length-1],st===!0&&At.setGlobalState(w.clippingPlanes,x.state.camera)):x=null,P.pop(),P.length>0?M=P[P.length-1]:M=null};function $a(C,K,ot,lt){if(C.visible===!1)return;if(C.layers.test(K.layers)){if(C.isGroup)ot=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(K);else if(C.isLight)x.pushLight(C),C.castShadow&&x.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||Y.intersectsSprite(C)){lt&&Yt.setFromMatrixPosition(C.matrixWorld).applyMatrix4(Ft);const Ut=mt.update(C),Ot=C.material;Ot.visible&&M.push(C,Ut,Ot,ot,Yt.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||Y.intersectsObject(C))){const Ut=mt.update(C),Ot=C.material;if(lt&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Yt.copy(C.boundingSphere.center)):(Ut.boundingSphere===null&&Ut.computeBoundingSphere(),Yt.copy(Ut.boundingSphere.center)),Yt.applyMatrix4(C.matrixWorld).applyMatrix4(Ft)),Array.isArray(Ot)){const zt=Ut.groups;for(let te=0,ee=zt.length;te<ee;te++){const Wt=zt[te],ye=Ot[Wt.materialIndex];ye&&ye.visible&&M.push(C,Ut,ye,ot,Yt.z,Wt)}}else Ot.visible&&M.push(C,Ut,Ot,ot,Yt.z,null)}}const Tt=C.children;for(let Ut=0,Ot=Tt.length;Ut<Ot;Ut++)$a(Tt[Ut],K,ot,lt)}function Os(C,K,ot,lt){const q=C.opaque,Tt=C.transmissive,Ut=C.transparent;x.setupLightsView(ot),st===!0&&At.setGlobalState(w.clippingPlanes,ot),lt&&kt.viewport(B.copy(lt)),q.length>0&&ts(q,K,ot),Tt.length>0&&ts(Tt,K,ot),Ut.length>0&&ts(Ut,K,ot),kt.buffers.depth.setTest(!0),kt.buffers.depth.setMask(!0),kt.buffers.color.setMask(!0),kt.setPolygonOffset(!1)}function Yr(C,K,ot,lt){if((ot.isScene===!0?ot.overrideMaterial:null)!==null)return;x.state.transmissionRenderTarget[lt.id]===void 0&&(x.state.transmissionRenderTarget[lt.id]=new Ds(1,1,{generateMipmaps:!0,type:le.has("EXT_color_buffer_half_float")||le.has("EXT_color_buffer_float")?Qo:pa,minFilter:Cs,samples:4,stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:De.workingColorSpace}));const Tt=x.state.transmissionRenderTarget[lt.id],Ut=lt.viewport||B;Tt.setSize(Ut.z*w.transmissionResolutionScale,Ut.w*w.transmissionResolutionScale);const Ot=w.getRenderTarget();w.setRenderTarget(Tt),w.getClearColor(ut),ft=w.getClearAlpha(),ft<1&&w.setClearColor(16777215,.5),w.clear(),Ue&&Kt.render(ot);const zt=w.toneMapping;w.toneMapping=Ka;const te=lt.viewport;if(lt.viewport!==void 0&&(lt.viewport=void 0),x.setupLightsView(lt),st===!0&&At.setGlobalState(w.clippingPlanes,lt),ts(C,ot,lt),U.updateMultisampleRenderTarget(Tt),U.updateRenderTargetMipmap(Tt),le.has("WEBGL_multisampled_render_to_texture")===!1){let ee=!1;for(let Wt=0,ye=K.length;Wt<ye;Wt++){const Se=K[Wt],Xe=Se.object,Re=Se.geometry,ie=Se.material,Zt=Se.group;if(ie.side===li&&Xe.layers.test(lt.layers)){const dn=ie.side;ie.side=Fn,ie.needsUpdate=!0,yi(Xe,ot,lt,Re,ie,Zt),ie.side=dn,ie.needsUpdate=!0,ee=!0}}ee===!0&&(U.updateMultisampleRenderTarget(Tt),U.updateRenderTargetMipmap(Tt))}w.setRenderTarget(Ot),w.setClearColor(ut,ft),te!==void 0&&(lt.viewport=te),w.toneMapping=zt}function ts(C,K,ot){const lt=K.isScene===!0?K.overrideMaterial:null;for(let q=0,Tt=C.length;q<Tt;q++){const Ut=C[q],Ot=Ut.object,zt=Ut.geometry,te=lt===null?Ut.material:lt,ee=Ut.group;Ot.layers.test(ot.layers)&&yi(Ot,K,ot,zt,te,ee)}}function yi(C,K,ot,lt,q,Tt){C.onBeforeRender(w,K,ot,lt,q,Tt),C.modelViewMatrix.multiplyMatrices(ot.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),q.onBeforeRender(w,K,ot,lt,C,Tt),q.transparent===!0&&q.side===li&&q.forceSinglePass===!1?(q.side=Fn,q.needsUpdate=!0,w.renderBufferDirect(ot,K,lt,q,C,Tt),q.side=Ja,q.needsUpdate=!0,w.renderBufferDirect(ot,K,lt,q,C,Tt),q.side=li):w.renderBufferDirect(ot,K,lt,q,C,Tt),C.onAfterRender(w,K,ot,lt,q,Tt)}function $e(C,K,ot){K.isScene!==!0&&(K=ze);const lt=Rt.get(C),q=x.state.lights,Tt=x.state.shadowsArray,Ut=q.state.version,Ot=Bt.getParameters(C,q.state,Tt,K,ot),zt=Bt.getProgramCacheKey(Ot);let te=lt.programs;lt.environment=C.isMeshStandardMaterial?K.environment:null,lt.fog=K.fog,lt.envMap=(C.isMeshStandardMaterial?$:T).get(C.envMap||lt.environment),lt.envMapRotation=lt.environment!==null&&C.envMap===null?K.environmentRotation:C.envMapRotation,te===void 0&&(C.addEventListener("dispose",$t),te=new Map,lt.programs=te);let ee=te.get(zt);if(ee!==void 0){if(lt.currentProgram===ee&&lt.lightsStateVersion===Ut)return Gi(C,Ot),ee}else Ot.uniforms=Bt.getUniforms(C),C.onBeforeCompile(Ot,w),ee=Bt.acquireProgram(Ot,zt),te.set(zt,ee),lt.uniforms=Ot.uniforms;const Wt=lt.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Wt.clippingPlanes=At.uniform),Gi(C,Ot),lt.needsLights=su(C),lt.lightsStateVersion=Ut,lt.needsLights&&(Wt.ambientLightColor.value=q.state.ambient,Wt.lightProbe.value=q.state.probe,Wt.directionalLights.value=q.state.directional,Wt.directionalLightShadows.value=q.state.directionalShadow,Wt.spotLights.value=q.state.spot,Wt.spotLightShadows.value=q.state.spotShadow,Wt.rectAreaLights.value=q.state.rectArea,Wt.ltc_1.value=q.state.rectAreaLTC1,Wt.ltc_2.value=q.state.rectAreaLTC2,Wt.pointLights.value=q.state.point,Wt.pointLightShadows.value=q.state.pointShadow,Wt.hemisphereLights.value=q.state.hemi,Wt.directionalShadowMap.value=q.state.directionalShadowMap,Wt.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Wt.spotShadowMap.value=q.state.spotShadowMap,Wt.spotLightMatrix.value=q.state.spotLightMatrix,Wt.spotLightMap.value=q.state.spotLightMap,Wt.pointShadowMap.value=q.state.pointShadowMap,Wt.pointShadowMatrix.value=q.state.pointShadowMatrix),lt.currentProgram=ee,lt.uniformsList=null,ee}function bn(C){if(C.uniformsList===null){const K=C.currentProgram.getUniforms();C.uniformsList=jc.seqWithValue(K.seq,C.uniforms)}return C.uniformsList}function Gi(C,K){const ot=Rt.get(C);ot.outputColorSpace=K.outputColorSpace,ot.batching=K.batching,ot.batchingColor=K.batchingColor,ot.instancing=K.instancing,ot.instancingColor=K.instancingColor,ot.instancingMorph=K.instancingMorph,ot.skinning=K.skinning,ot.morphTargets=K.morphTargets,ot.morphNormals=K.morphNormals,ot.morphColors=K.morphColors,ot.morphTargetsCount=K.morphTargetsCount,ot.numClippingPlanes=K.numClippingPlanes,ot.numIntersection=K.numClipIntersection,ot.vertexAlphas=K.vertexAlphas,ot.vertexTangents=K.vertexTangents,ot.toneMapping=K.toneMapping}function Zr(C,K,ot,lt,q){K.isScene!==!0&&(K=ze),U.resetTextureUnits();const Tt=K.fog,Ut=lt.isMeshStandardMaterial?K.environment:null,Ot=j===null?w.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:Vr,zt=(lt.isMeshStandardMaterial?$:T).get(lt.envMap||Ut),te=lt.vertexColors===!0&&!!ot.attributes.color&&ot.attributes.color.itemSize===4,ee=!!ot.attributes.tangent&&(!!lt.normalMap||lt.anisotropy>0),Wt=!!ot.morphAttributes.position,ye=!!ot.morphAttributes.normal,Se=!!ot.morphAttributes.color;let Xe=Ka;lt.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Xe=w.toneMapping);const Re=ot.morphAttributes.position||ot.morphAttributes.normal||ot.morphAttributes.color,ie=Re!==void 0?Re.length:0,Zt=Rt.get(lt),dn=x.state.lights;if(st===!0&&(xt===!0||C!==R)){const tn=C===R&&lt.id===L;At.setState(lt,C,tn)}let Ee=!1;lt.version===Zt.__version?(Zt.needsLights&&Zt.lightsStateVersion!==dn.state.version||Zt.outputColorSpace!==Ot||q.isBatchedMesh&&Zt.batching===!1||!q.isBatchedMesh&&Zt.batching===!0||q.isBatchedMesh&&Zt.batchingColor===!0&&q.colorTexture===null||q.isBatchedMesh&&Zt.batchingColor===!1&&q.colorTexture!==null||q.isInstancedMesh&&Zt.instancing===!1||!q.isInstancedMesh&&Zt.instancing===!0||q.isSkinnedMesh&&Zt.skinning===!1||!q.isSkinnedMesh&&Zt.skinning===!0||q.isInstancedMesh&&Zt.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Zt.instancingColor===!1&&q.instanceColor!==null||q.isInstancedMesh&&Zt.instancingMorph===!0&&q.morphTexture===null||q.isInstancedMesh&&Zt.instancingMorph===!1&&q.morphTexture!==null||Zt.envMap!==zt||lt.fog===!0&&Zt.fog!==Tt||Zt.numClippingPlanes!==void 0&&(Zt.numClippingPlanes!==At.numPlanes||Zt.numIntersection!==At.numIntersection)||Zt.vertexAlphas!==te||Zt.vertexTangents!==ee||Zt.morphTargets!==Wt||Zt.morphNormals!==ye||Zt.morphColors!==Se||Zt.toneMapping!==Xe||Zt.morphTargetsCount!==ie)&&(Ee=!0):(Ee=!0,Zt.__version=lt.version);let Vn=Zt.currentProgram;Ee===!0&&(Vn=$e(lt,K,q));let Si=!1,On=!1,xn=!1;const Be=Vn.getUniforms(),Pn=Zt.uniforms;if(kt.useProgram(Vn.program)&&(Si=!0,On=!0,xn=!0),lt.id!==L&&(L=lt.id,On=!0),Si||R!==C){kt.buffers.depth.getReversed()?(bt.copy(C.projectionMatrix),JS(bt),$S(bt),Be.setValue(G,"projectionMatrix",bt)):Be.setValue(G,"projectionMatrix",C.projectionMatrix),Be.setValue(G,"viewMatrix",C.matrixWorldInverse);const En=Be.map.cameraPosition;En!==void 0&&En.setValue(G,Xt.setFromMatrixPosition(C.matrixWorld)),de.logarithmicDepthBuffer&&Be.setValue(G,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(lt.isMeshPhongMaterial||lt.isMeshToonMaterial||lt.isMeshLambertMaterial||lt.isMeshBasicMaterial||lt.isMeshStandardMaterial||lt.isShaderMaterial)&&Be.setValue(G,"isOrthographic",C.isOrthographicCamera===!0),R!==C&&(R=C,On=!0,xn=!0)}if(q.isSkinnedMesh){Be.setOptional(G,q,"bindMatrix"),Be.setOptional(G,q,"bindMatrixInverse");const tn=q.skeleton;tn&&(tn.boneTexture===null&&tn.computeBoneTexture(),Be.setValue(G,"boneTexture",tn.boneTexture,U))}q.isBatchedMesh&&(Be.setOptional(G,q,"batchingTexture"),Be.setValue(G,"batchingTexture",q._matricesTexture,U),Be.setOptional(G,q,"batchingIdTexture"),Be.setValue(G,"batchingIdTexture",q._indirectTexture,U),Be.setOptional(G,q,"batchingColorTexture"),q._colorsTexture!==null&&Be.setValue(G,"batchingColorTexture",q._colorsTexture,U));const Dn=ot.morphAttributes;if((Dn.position!==void 0||Dn.normal!==void 0||Dn.color!==void 0)&&jt.update(q,ot,Vn),(On||Zt.receiveShadow!==q.receiveShadow)&&(Zt.receiveShadow=q.receiveShadow,Be.setValue(G,"receiveShadow",q.receiveShadow)),lt.isMeshGouraudMaterial&&lt.envMap!==null&&(Pn.envMap.value=zt,Pn.flipEnvMap.value=zt.isCubeTexture&&zt.isRenderTargetTexture===!1?-1:1),lt.isMeshStandardMaterial&&lt.envMap===null&&K.environment!==null&&(Pn.envMapIntensity.value=K.environmentIntensity),On&&(Be.setValue(G,"toneMappingExposure",w.toneMappingExposure),Zt.needsLights&&au(Pn,xn),Tt&&lt.fog===!0&&Ct.refreshFogUniforms(Pn,Tt),Ct.refreshMaterialUniforms(Pn,lt,X,W,x.state.transmissionRenderTarget[C.id]),jc.upload(G,bn(Zt),Pn,U)),lt.isShaderMaterial&&lt.uniformsNeedUpdate===!0&&(jc.upload(G,bn(Zt),Pn,U),lt.uniformsNeedUpdate=!1),lt.isSpriteMaterial&&Be.setValue(G,"center",q.center),Be.setValue(G,"modelViewMatrix",q.modelViewMatrix),Be.setValue(G,"normalMatrix",q.normalMatrix),Be.setValue(G,"modelMatrix",q.matrixWorld),lt.isShaderMaterial||lt.isRawShaderMaterial){const tn=lt.uniformsGroups;for(let En=0,Ps=tn.length;En<Ps;En++){const kn=tn[En];Z.update(kn,Vn),Z.bind(kn,Vn)}}return Vn}function au(C,K){C.ambientLightColor.needsUpdate=K,C.lightProbe.needsUpdate=K,C.directionalLights.needsUpdate=K,C.directionalLightShadows.needsUpdate=K,C.pointLights.needsUpdate=K,C.pointLightShadows.needsUpdate=K,C.spotLights.needsUpdate=K,C.spotLightShadows.needsUpdate=K,C.rectAreaLights.needsUpdate=K,C.hemisphereLights.needsUpdate=K}function su(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return H},this.getActiveMipmapLevel=function(){return I},this.getRenderTarget=function(){return j},this.setRenderTargetTextures=function(C,K,ot){Rt.get(C.texture).__webglTexture=K,Rt.get(C.depthTexture).__webglTexture=ot;const lt=Rt.get(C);lt.__hasExternalTextures=!0,lt.__autoAllocateDepthBuffer=ot===void 0,lt.__autoAllocateDepthBuffer||le.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),lt.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(C,K){const ot=Rt.get(C);ot.__webglFramebuffer=K,ot.__useDefaultFramebuffer=K===void 0};const el=G.createFramebuffer();this.setRenderTarget=function(C,K=0,ot=0){j=C,H=K,I=ot;let lt=!0,q=null,Tt=!1,Ut=!1;if(C){const zt=Rt.get(C);if(zt.__useDefaultFramebuffer!==void 0)kt.bindFramebuffer(G.FRAMEBUFFER,null),lt=!1;else if(zt.__webglFramebuffer===void 0)U.setupRenderTarget(C);else if(zt.__hasExternalTextures)U.rebindTextures(C,Rt.get(C.texture).__webglTexture,Rt.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const Wt=C.depthTexture;if(zt.__boundDepthTexture!==Wt){if(Wt!==null&&Rt.has(Wt)&&(C.width!==Wt.image.width||C.height!==Wt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");U.setupDepthRenderbuffer(C)}}const te=C.texture;(te.isData3DTexture||te.isDataArrayTexture||te.isCompressedArrayTexture)&&(Ut=!0);const ee=Rt.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(ee[K])?q=ee[K][ot]:q=ee[K],Tt=!0):C.samples>0&&U.useMultisampledRTT(C)===!1?q=Rt.get(C).__webglMultisampledFramebuffer:Array.isArray(ee)?q=ee[ot]:q=ee,B.copy(C.viewport),tt.copy(C.scissor),et=C.scissorTest}else B.copy(O).multiplyScalar(X).floor(),tt.copy(at).multiplyScalar(X).floor(),et=vt;if(ot!==0&&(q=el),kt.bindFramebuffer(G.FRAMEBUFFER,q)&&lt&&kt.drawBuffers(C,q),kt.viewport(B),kt.scissor(tt),kt.setScissorTest(et),Tt){const zt=Rt.get(C.texture);G.framebufferTexture2D(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_CUBE_MAP_POSITIVE_X+K,zt.__webglTexture,ot)}else if(Ut){const zt=Rt.get(C.texture),te=K;G.framebufferTextureLayer(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,zt.__webglTexture,ot,te)}else if(C!==null&&ot!==0){const zt=Rt.get(C.texture);G.framebufferTexture2D(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_2D,zt.__webglTexture,ot)}L=-1},this.readRenderTargetPixels=function(C,K,ot,lt,q,Tt,Ut){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ot=Rt.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ut!==void 0&&(Ot=Ot[Ut]),Ot){kt.bindFramebuffer(G.FRAMEBUFFER,Ot);try{const zt=C.texture,te=zt.format,ee=zt.type;if(!de.textureFormatReadable(te)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!de.textureTypeReadable(ee)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}K>=0&&K<=C.width-lt&&ot>=0&&ot<=C.height-q&&G.readPixels(K,ot,lt,q,re.convert(te),re.convert(ee),Tt)}finally{const zt=j!==null?Rt.get(j).__webglFramebuffer:null;kt.bindFramebuffer(G.FRAMEBUFFER,zt)}}},this.readRenderTargetPixelsAsync=async function(C,K,ot,lt,q,Tt,Ut){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ot=Rt.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ut!==void 0&&(Ot=Ot[Ut]),Ot){const zt=C.texture,te=zt.format,ee=zt.type;if(!de.textureFormatReadable(te))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!de.textureTypeReadable(ee))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(K>=0&&K<=C.width-lt&&ot>=0&&ot<=C.height-q){kt.bindFramebuffer(G.FRAMEBUFFER,Ot);const Wt=G.createBuffer();G.bindBuffer(G.PIXEL_PACK_BUFFER,Wt),G.bufferData(G.PIXEL_PACK_BUFFER,Tt.byteLength,G.STREAM_READ),G.readPixels(K,ot,lt,q,re.convert(te),re.convert(ee),0);const ye=j!==null?Rt.get(j).__webglFramebuffer:null;kt.bindFramebuffer(G.FRAMEBUFFER,ye);const Se=G.fenceSync(G.SYNC_GPU_COMMANDS_COMPLETE,0);return G.flush(),await QS(G,Se,4),G.bindBuffer(G.PIXEL_PACK_BUFFER,Wt),G.getBufferSubData(G.PIXEL_PACK_BUFFER,0,Tt),G.deleteBuffer(Wt),G.deleteSync(Se),Tt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(C,K=null,ot=0){C.isTexture!==!0&&(Es("WebGLRenderer: copyFramebufferToTexture function signature has changed."),K=arguments[0]||null,C=arguments[1]);const lt=Math.pow(2,-ot),q=Math.floor(C.image.width*lt),Tt=Math.floor(C.image.height*lt),Ut=K!==null?K.x:0,Ot=K!==null?K.y:0;U.setTexture2D(C,0),G.copyTexSubImage2D(G.TEXTURE_2D,ot,0,0,Ut,Ot,q,Tt),kt.unbindTexture()};const es=G.createFramebuffer(),Kr=G.createFramebuffer();this.copyTextureToTexture=function(C,K,ot=null,lt=null,q=0,Tt=null){C.isTexture!==!0&&(Es("WebGLRenderer: copyTextureToTexture function signature has changed."),lt=arguments[0]||null,C=arguments[1],K=arguments[2],Tt=arguments[3]||0,ot=null),Tt===null&&(q!==0?(Es("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),Tt=q,q=0):Tt=0);let Ut,Ot,zt,te,ee,Wt,ye,Se,Xe;const Re=C.isCompressedTexture?C.mipmaps[Tt]:C.image;if(ot!==null)Ut=ot.max.x-ot.min.x,Ot=ot.max.y-ot.min.y,zt=ot.isBox3?ot.max.z-ot.min.z:1,te=ot.min.x,ee=ot.min.y,Wt=ot.isBox3?ot.min.z:0;else{const Dn=Math.pow(2,-q);Ut=Math.floor(Re.width*Dn),Ot=Math.floor(Re.height*Dn),C.isDataArrayTexture?zt=Re.depth:C.isData3DTexture?zt=Math.floor(Re.depth*Dn):zt=1,te=0,ee=0,Wt=0}lt!==null?(ye=lt.x,Se=lt.y,Xe=lt.z):(ye=0,Se=0,Xe=0);const ie=re.convert(K.format),Zt=re.convert(K.type);let dn;K.isData3DTexture?(U.setTexture3D(K,0),dn=G.TEXTURE_3D):K.isDataArrayTexture||K.isCompressedArrayTexture?(U.setTexture2DArray(K,0),dn=G.TEXTURE_2D_ARRAY):(U.setTexture2D(K,0),dn=G.TEXTURE_2D),G.pixelStorei(G.UNPACK_FLIP_Y_WEBGL,K.flipY),G.pixelStorei(G.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),G.pixelStorei(G.UNPACK_ALIGNMENT,K.unpackAlignment);const Ee=G.getParameter(G.UNPACK_ROW_LENGTH),Vn=G.getParameter(G.UNPACK_IMAGE_HEIGHT),Si=G.getParameter(G.UNPACK_SKIP_PIXELS),On=G.getParameter(G.UNPACK_SKIP_ROWS),xn=G.getParameter(G.UNPACK_SKIP_IMAGES);G.pixelStorei(G.UNPACK_ROW_LENGTH,Re.width),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,Re.height),G.pixelStorei(G.UNPACK_SKIP_PIXELS,te),G.pixelStorei(G.UNPACK_SKIP_ROWS,ee),G.pixelStorei(G.UNPACK_SKIP_IMAGES,Wt);const Be=C.isDataArrayTexture||C.isData3DTexture,Pn=K.isDataArrayTexture||K.isData3DTexture;if(C.isDepthTexture){const Dn=Rt.get(C),tn=Rt.get(K),En=Rt.get(Dn.__renderTarget),Ps=Rt.get(tn.__renderTarget);kt.bindFramebuffer(G.READ_FRAMEBUFFER,En.__webglFramebuffer),kt.bindFramebuffer(G.DRAW_FRAMEBUFFER,Ps.__webglFramebuffer);for(let kn=0;kn<zt;kn++)Be&&(G.framebufferTextureLayer(G.READ_FRAMEBUFFER,G.COLOR_ATTACHMENT0,Rt.get(C).__webglTexture,q,Wt+kn),G.framebufferTextureLayer(G.DRAW_FRAMEBUFFER,G.COLOR_ATTACHMENT0,Rt.get(K).__webglTexture,Tt,Xe+kn)),G.blitFramebuffer(te,ee,Ut,Ot,ye,Se,Ut,Ot,G.DEPTH_BUFFER_BIT,G.NEAREST);kt.bindFramebuffer(G.READ_FRAMEBUFFER,null),kt.bindFramebuffer(G.DRAW_FRAMEBUFFER,null)}else if(q!==0||C.isRenderTargetTexture||Rt.has(C)){const Dn=Rt.get(C),tn=Rt.get(K);kt.bindFramebuffer(G.READ_FRAMEBUFFER,es),kt.bindFramebuffer(G.DRAW_FRAMEBUFFER,Kr);for(let En=0;En<zt;En++)Be?G.framebufferTextureLayer(G.READ_FRAMEBUFFER,G.COLOR_ATTACHMENT0,Dn.__webglTexture,q,Wt+En):G.framebufferTexture2D(G.READ_FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_2D,Dn.__webglTexture,q),Pn?G.framebufferTextureLayer(G.DRAW_FRAMEBUFFER,G.COLOR_ATTACHMENT0,tn.__webglTexture,Tt,Xe+En):G.framebufferTexture2D(G.DRAW_FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_2D,tn.__webglTexture,Tt),q!==0?G.blitFramebuffer(te,ee,Ut,Ot,ye,Se,Ut,Ot,G.COLOR_BUFFER_BIT,G.NEAREST):Pn?G.copyTexSubImage3D(dn,Tt,ye,Se,Xe+En,te,ee,Ut,Ot):G.copyTexSubImage2D(dn,Tt,ye,Se,te,ee,Ut,Ot);kt.bindFramebuffer(G.READ_FRAMEBUFFER,null),kt.bindFramebuffer(G.DRAW_FRAMEBUFFER,null)}else Pn?C.isDataTexture||C.isData3DTexture?G.texSubImage3D(dn,Tt,ye,Se,Xe,Ut,Ot,zt,ie,Zt,Re.data):K.isCompressedArrayTexture?G.compressedTexSubImage3D(dn,Tt,ye,Se,Xe,Ut,Ot,zt,ie,Re.data):G.texSubImage3D(dn,Tt,ye,Se,Xe,Ut,Ot,zt,ie,Zt,Re):C.isDataTexture?G.texSubImage2D(G.TEXTURE_2D,Tt,ye,Se,Ut,Ot,ie,Zt,Re.data):C.isCompressedTexture?G.compressedTexSubImage2D(G.TEXTURE_2D,Tt,ye,Se,Re.width,Re.height,ie,Re.data):G.texSubImage2D(G.TEXTURE_2D,Tt,ye,Se,Ut,Ot,ie,Zt,Re);G.pixelStorei(G.UNPACK_ROW_LENGTH,Ee),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,Vn),G.pixelStorei(G.UNPACK_SKIP_PIXELS,Si),G.pixelStorei(G.UNPACK_SKIP_ROWS,On),G.pixelStorei(G.UNPACK_SKIP_IMAGES,xn),Tt===0&&K.generateMipmaps&&G.generateMipmap(dn),kt.unbindTexture()},this.copyTextureToTexture3D=function(C,K,ot=null,lt=null,q=0){return C.isTexture!==!0&&(Es("WebGLRenderer: copyTextureToTexture3D function signature has changed."),ot=arguments[0]||null,lt=arguments[1]||null,C=arguments[2],K=arguments[3],q=arguments[4]||0),Es('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(C,K,ot,lt,q)},this.initRenderTarget=function(C){Rt.get(C).__webglFramebuffer===void 0&&U.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?U.setTextureCube(C,0):C.isData3DTexture?U.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?U.setTexture2DArray(C,0):U.setTexture2D(C,0),kt.unbindTexture()},this.resetState=function(){H=0,I=0,j=null,kt.reset(),Ie.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ha}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const i=this.getContext();i.drawingBufferColorspace=De._getDrawingBufferColorSpace(t),i.unpackColorSpace=De._getUnpackColorSpace()}}const Z_={type:"change"},Qd={type:"start"},Nv={type:"end"},zc=new tu,K_=new ja,b2=Math.cos(70*ZS.DEG2RAD),mn=new J,Qn=2*Math.PI,ke={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Yh=1e-6;class E2 extends F1{constructor(t,i=null){super(t,i),this.state=ke.NONE,this.enabled=!0,this.target=new J,this.cursor=new J,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Lr.ROTATE,MIDDLE:Lr.DOLLY,RIGHT:Lr.PAN},this.touches={ONE:Cr.ROTATE,TWO:Cr.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new J,this._lastQuaternion=new Ls,this._lastTargetPosition=new J,this._quat=new Ls().setFromUnitVectors(t.up,new J(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new b_,this._sphericalDelta=new b_,this._scale=1,this._panOffset=new J,this._rotateStart=new se,this._rotateEnd=new se,this._rotateDelta=new se,this._panStart=new se,this._panEnd=new se,this._panDelta=new se,this._dollyStart=new se,this._dollyEnd=new se,this._dollyDelta=new se,this._dollyDirection=new J,this._mouse=new se,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=A2.bind(this),this._onPointerDown=T2.bind(this),this._onPointerUp=R2.bind(this),this._onContextMenu=O2.bind(this),this._onMouseWheel=D2.bind(this),this._onKeyDown=L2.bind(this),this._onTouchStart=U2.bind(this),this._onTouchMove=N2.bind(this),this._onMouseDown=C2.bind(this),this._onMouseMove=w2.bind(this),this._interceptControlDown=P2.bind(this),this._interceptControlUp=z2.bind(this),this.domElement!==null&&this.connect(),this.update()}connect(){this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Z_),this.update(),this.state=ke.NONE}update(t=null){const i=this.object.position;mn.copy(i).sub(this.target),mn.applyQuaternion(this._quat),this._spherical.setFromVector3(mn),this.autoRotate&&this.state===ke.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let s=this.minAzimuthAngle,l=this.maxAzimuthAngle;isFinite(s)&&isFinite(l)&&(s<-Math.PI?s+=Qn:s>Math.PI&&(s-=Qn),l<-Math.PI?l+=Qn:l>Math.PI&&(l-=Qn),s<=l?this._spherical.theta=Math.max(s,Math.min(l,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(s+l)/2?Math.max(s,this._spherical.theta):Math.min(l,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let c=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const h=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),c=h!=this._spherical.radius}if(mn.setFromSpherical(this._spherical),mn.applyQuaternion(this._quatInverse),i.copy(this.target).add(mn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let h=null;if(this.object.isPerspectiveCamera){const d=mn.length();h=this._clampDistance(d*this._scale);const m=d-h;this.object.position.addScaledVector(this._dollyDirection,m),this.object.updateMatrixWorld(),c=!!m}else if(this.object.isOrthographicCamera){const d=new J(this._mouse.x,this._mouse.y,0);d.unproject(this.object);const m=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),c=m!==this.object.zoom;const p=new J(this._mouse.x,this._mouse.y,0);p.unproject(this.object),this.object.position.sub(p).add(d),this.object.updateMatrixWorld(),h=mn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;h!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(h).add(this.object.position):(zc.origin.copy(this.object.position),zc.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(zc.direction))<b2?this.object.lookAt(this.target):(K_.setFromNormalAndCoplanarPoint(this.object.up,this.target),zc.intersectPlane(K_,this.target))))}else if(this.object.isOrthographicCamera){const h=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),h!==this.object.zoom&&(this.object.updateProjectionMatrix(),c=!0)}return this._scale=1,this._performCursorZoom=!1,c||this._lastPosition.distanceToSquared(this.object.position)>Yh||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Yh||this._lastTargetPosition.distanceToSquared(this.target)>Yh?(this.dispatchEvent(Z_),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?Qn/60*this.autoRotateSpeed*t:Qn/60/60*this.autoRotateSpeed}_getZoomScale(t){const i=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*i)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,i){mn.setFromMatrixColumn(i,0),mn.multiplyScalar(-t),this._panOffset.add(mn)}_panUp(t,i){this.screenSpacePanning===!0?mn.setFromMatrixColumn(i,1):(mn.setFromMatrixColumn(i,0),mn.crossVectors(this.object.up,mn)),mn.multiplyScalar(t),this._panOffset.add(mn)}_pan(t,i){const s=this.domElement;if(this.object.isPerspectiveCamera){const l=this.object.position;mn.copy(l).sub(this.target);let c=mn.length();c*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*c/s.clientHeight,this.object.matrix),this._panUp(2*i*c/s.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/s.clientWidth,this.object.matrix),this._panUp(i*(this.object.top-this.object.bottom)/this.object.zoom/s.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,i){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const s=this.domElement.getBoundingClientRect(),l=t-s.left,c=i-s.top,h=s.width,d=s.height;this._mouse.x=l/h*2-1,this._mouse.y=-(c/d)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientX),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const i=this.domElement;this._rotateLeft(Qn*this._rotateDelta.x/i.clientHeight),this._rotateUp(Qn*this._rotateDelta.y/i.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let i=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(Qn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),i=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-Qn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),i=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(Qn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),i=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-Qn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),i=!0;break}i&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{const i=this._getSecondPointerPosition(t),s=.5*(t.pageX+i.x),l=.5*(t.pageY+i.y);this._rotateStart.set(s,l)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{const i=this._getSecondPointerPosition(t),s=.5*(t.pageX+i.x),l=.5*(t.pageY+i.y);this._panStart.set(s,l)}}_handleTouchStartDolly(t){const i=this._getSecondPointerPosition(t),s=t.pageX-i.x,l=t.pageY-i.y,c=Math.sqrt(s*s+l*l);this._dollyStart.set(0,c)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{const s=this._getSecondPointerPosition(t),l=.5*(t.pageX+s.x),c=.5*(t.pageY+s.y);this._rotateEnd.set(l,c)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const i=this.domElement;this._rotateLeft(Qn*this._rotateDelta.x/i.clientHeight),this._rotateUp(Qn*this._rotateDelta.y/i.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{const i=this._getSecondPointerPosition(t),s=.5*(t.pageX+i.x),l=.5*(t.pageY+i.y);this._panEnd.set(s,l)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){const i=this._getSecondPointerPosition(t),s=t.pageX-i.x,l=t.pageY-i.y,c=Math.sqrt(s*s+l*l);this._dollyEnd.set(0,c),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const h=(t.pageX+i.x)*.5,d=(t.pageY+i.y)*.5;this._updateZoomParameters(h,d)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let i=0;i<this._pointers.length;i++)if(this._pointers[i]==t.pointerId){this._pointers.splice(i,1);return}}_isTrackingPointer(t){for(let i=0;i<this._pointers.length;i++)if(this._pointers[i]==t.pointerId)return!0;return!1}_trackPointer(t){let i=this._pointerPositions[t.pointerId];i===void 0&&(i=new se,this._pointerPositions[t.pointerId]=i),i.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){const i=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[i]}_customWheelEvent(t){const i=t.deltaMode,s={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(i){case 1:s.deltaY*=16;break;case 2:s.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(s.deltaY*=10),s}}function T2(r){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(r.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(r)&&(this._addPointer(r),r.pointerType==="touch"?this._onTouchStart(r):this._onMouseDown(r)))}function A2(r){this.enabled!==!1&&(r.pointerType==="touch"?this._onTouchMove(r):this._onMouseMove(r))}function R2(r){switch(this._removePointer(r),this._pointers.length){case 0:this.domElement.releasePointerCapture(r.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Nv),this.state=ke.NONE;break;case 1:const t=this._pointers[0],i=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:i.x,pageY:i.y});break}}function C2(r){let t;switch(r.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Lr.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(r),this.state=ke.DOLLY;break;case Lr.ROTATE:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=ke.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=ke.ROTATE}break;case Lr.PAN:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=ke.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=ke.PAN}break;default:this.state=ke.NONE}this.state!==ke.NONE&&this.dispatchEvent(Qd)}function w2(r){switch(this.state){case ke.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(r);break;case ke.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(r);break;case ke.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(r);break}}function D2(r){this.enabled===!1||this.enableZoom===!1||this.state!==ke.NONE||(r.preventDefault(),this.dispatchEvent(Qd),this._handleMouseWheel(this._customWheelEvent(r)),this.dispatchEvent(Nv))}function L2(r){this.enabled!==!1&&this._handleKeyDown(r)}function U2(r){switch(this._trackPointer(r),this._pointers.length){case 1:switch(this.touches.ONE){case Cr.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(r),this.state=ke.TOUCH_ROTATE;break;case Cr.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(r),this.state=ke.TOUCH_PAN;break;default:this.state=ke.NONE}break;case 2:switch(this.touches.TWO){case Cr.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(r),this.state=ke.TOUCH_DOLLY_PAN;break;case Cr.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(r),this.state=ke.TOUCH_DOLLY_ROTATE;break;default:this.state=ke.NONE}break;default:this.state=ke.NONE}this.state!==ke.NONE&&this.dispatchEvent(Qd)}function N2(r){switch(this._trackPointer(r),this.state){case ke.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(r),this.update();break;case ke.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(r),this.update();break;case ke.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(r),this.update();break;case ke.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(r),this.update();break;default:this.state=ke.NONE}}function O2(r){this.enabled!==!1&&r.preventDefault()}function P2(r){r.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function z2(r){r.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function I2(){const r=new N1,t=r.load("/textures/earth_day_4096.jpg");t.colorSpace=Bn;const i=r.load("/textures/earth_night_4096.jpg");i.colorSpace=Bn;const s=r.load("/textures/earth_specular_2048.jpg"),l=r.load("/textures/earth_normal_2048.jpg"),c=r.load("/textures/earth_clouds_1024.png");return c.colorSpace=Bn,c.wrapS=Xc,c.wrapT=Ya,{day:t,night:i,specular:s,normal:l,clouds:c}}function B2(){const r=new qo,t=new Rr({color:13751771,metalness:.85,roughness:.25}),i=new Rr({color:15857145,metalness:.6,roughness:.35}),s=new Rr({color:165063,emissive:536393,emissiveIntensity:.4,metalness:.9,roughness:.15,side:li}),l=new Rr({color:14870768,metalness:.4,roughness:.4,side:li}),c=new Qa(1.6,.04,.04),h=new Qe(c,t);r.add(h);const d=new wr(.06,.06,.5,16),m=new Qe(d,i);m.rotation.x=Math.PI/2,r.add(m);const p=new wr(.055,.055,.35,16),g=new Qe(p,i);g.rotation.x=Math.PI/2,g.position.set(0,0,.35),r.add(g);const _=new wr(.05,.05,.3,16),y=new Qe(_,i);y.rotation.x=Math.PI/2,y.position.set(0,0,-.35),r.add(y);const v=new wr(.05,.05,.3,16),b=new Qe(v,i);b.rotation.z=Math.PI/2,b.position.set(0,0,.2),r.add(b);const E=new Pr(.035,12,12,0,Math.PI*2,0,Math.PI/2),M=new Rr({color:58879,emissive:58879,emissiveIntensity:.6,metalness:.9,roughness:.1}),x=new Qe(E,M);x.rotation.x=Math.PI,x.position.set(0,-.06,.2),r.add(x);const P=new Qa(.35,.005,.16);[[.55,0,.12],[.55,0,-.12],[.75,0,.12],[.75,0,-.12],[-.55,0,.12],[-.55,0,-.12],[-.75,0,.12],[-.75,0,-.12]].forEach(([vt,Y,st])=>{const xt=new Qe(P,s);xt.position.set(vt,Y,st),r.add(xt)});const w=new Qa(.2,.18,.005),k=new Qe(w,l);k.position.set(.25,.1,0),r.add(k);const H=new Qe(w,l);H.position.set(-.25,.1,0),r.add(H),r.scale.set(.65,.65,.65);const I=new Gn;I.setAttribute("position",new Jn(new Float32Array(6),3));const j=new Pd({color:58879,transparent:!0,opacity:.6,linewidth:2,blending:qa}),L=new g_(I,j),R=new Qc(.55,.65,48),B=new Yc({color:58879,transparent:!0,opacity:.85,side:li,blending:qa,depthWrite:!1}),tt=new Qe(R,B),et=new Qc(.65,.8,48),ut=new Yc({color:3718648,transparent:!0,opacity:.45,side:li,blending:qa,depthWrite:!1}),ft=new Qe(et,ut),z=300,W=new Gn,X=new Float32Array(z*3);W.setAttribute("position",new Jn(X,3));const _t=new Pd({color:58879,transparent:!0,opacity:.55,blending:qa}),Et=new g_(W,_t);return{issGroup:r,nadirBeam:L,footprintRing:tt,pulseRing:ft,orbitLine:Et,updateOrbitTrail:vt=>{const Y=W.attributes.position,st=Math.min(vt.length,z);for(let xt=0;xt<st;xt++)Y.setXYZ(xt,vt[xt].x,vt[xt].y,vt[xt].z);W.setDrawRange(0,st),Y.needsUpdate=!0},updatePosition:(vt,Y)=>{r.position.copy(vt);const st=vt.clone().normalize();r.quaternion.setFromUnitVectors(new J(0,-1,0),st);const xt=I.attributes.position;xt.setXYZ(0,vt.x,vt.y,vt.z),xt.setXYZ(1,Y.x,Y.y,Y.z),xt.needsUpdate=!0;const bt=Y.clone().multiplyScalar(1.002);tt.position.copy(bt),tt.lookAt(Y.clone().multiplyScalar(2)),ft.position.copy(bt),ft.lookAt(Y.clone().multiplyScalar(2))}}}function F2(r=new J(1,.3,.6).normalize()){return new Hi({uniforms:{uSunDirection:{value:r}},vertexShader:`
      varying vec3 vNormal;
      varying vec3 vPosition;
      varying vec3 vWorldNormal;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        vWorldNormal = normalize((modelMatrix * vec4(normal, 0.0)).xyz);
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vPosition = mvPosition.xyz;
        gl_Position = projectionMatrix * mvPosition;
      }
    `,fragmentShader:`
      uniform vec3 uSunDirection;
      varying vec3 vNormal;
      varying vec3 vPosition;
      varying vec3 vWorldNormal;

      void main() {
        // View angle (Fresnel rim falloff)
        vec3 viewDir = normalize(-vPosition);
        float fresnel = pow(1.0 - abs(dot(vNormal, viewDir)), 3.2);

        // Sun illumination factor on the atmosphere
        vec3 sunDir = normalize(uSunDirection);
        float sunDot = dot(vWorldNormal, sunDir);
        
        // Day-side bright azure/cyan scattering, fading smoothly to dark side
        float dayAtmosphere = smoothstep(-0.25, 0.35, sunDot);
        
        // Subtle golden sunset glow on the limb near the terminator
        float twilightLimb = smoothstep(-0.2, 0.05, sunDot) * smoothstep(0.3, 0.05, sunDot);
        vec3 sunsetGlow = vec3(1.0, 0.55, 0.2) * twilightLimb * 0.6;
        
        // Soft diffused cyan / azure Rayleigh atmosphere
        vec3 dayGlow = vec3(0.08, 0.65, 1.0) * (dayAtmosphere * 0.95 + 0.12);
        
        vec3 finalColor = (dayGlow + sunsetGlow) * fresnel * 1.6;
        float alpha = fresnel * (dayAtmosphere * 0.85 + 0.2);

        gl_FragColor = vec4(finalColor, alpha);
      }
    `,blending:qa,side:Fn,transparent:!0,depthWrite:!1})}function H2(r,t=new J(1,.3,.6).normalize()){return new Hi({uniforms:{uDayTexture:{value:r.day},uNightTexture:{value:r.night},uSpecularTexture:{value:r.specular},uNormalTexture:{value:r.normal},uSunDirection:{value:t},uShowCityLights:{value:1},uShowTerminator:{value:1}},vertexShader:`
      varying vec2 vUv;
      varying vec3 vNormal;
      varying vec3 vWorldNormal;
      varying vec3 vViewPosition;

      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vWorldNormal = normalize((modelMatrix * vec4(normal, 0.0)).xyz);
        
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -mvPosition.xyz;
        
        gl_Position = projectionMatrix * mvPosition;
      }
    `,fragmentShader:`
      uniform sampler2D uDayTexture;
      uniform sampler2D uNightTexture;
      uniform sampler2D uSpecularTexture;
      uniform sampler2D uNormalTexture;
      uniform vec3 uSunDirection;
      uniform float uShowCityLights;
      uniform float uShowTerminator;

      varying vec2 vUv;
      varying vec3 vNormal;
      varying vec3 vWorldNormal;
      varying vec3 vViewPosition;

      void main() {
        // Sample textures
        vec3 rawDay = texture2D(uDayTexture, vUv).rgb;
        vec3 nightLights = texture2D(uNightTexture, vUv).rgb;
        float specularMask = texture2D(uSpecularTexture, vUv).r;

        // Normal and Sun illumination vector
        vec3 normal = normalize(vWorldNormal);
        vec3 sunDir = normalize(uSunDirection);
        float sunDot = dot(normal, sunDir);

        // Day factor with smooth physical twilight gradient
        float dayFactor = smoothstep(-0.12, 0.18, sunDot);

        // 1. RADIANT & VIBRANT DAYTIME LIGHTING
        // Specular Sun reflection glint on water
        vec3 viewDir = normalize(vViewPosition);
        vec3 halfDir = normalize(sunDir + viewDir);
        float specAngle = max(dot(normalize(vNormal), halfDir), 0.0);
        float specular = pow(specAngle, 32.0) * specularMask * 2.5 * dayFactor;
        vec3 sunSpecularColor = vec3(1.0, 0.98, 0.94) * specular;

        // Enhance daytime vibrancy, rich blue oceans, and lush continents
        vec3 vibrantDay = pow(rawDay, vec3(0.92)) * 1.65;
        float sunDirect = max(sunDot, 0.0);
        float sunIntensity = pow(sunDirect, 0.72) * 1.45 + 0.42;
        vec3 litDay = vibrantDay * sunIntensity + sunSpecularColor;

        // 2. GOLDEN-AMBER TWILIGHT SUNSET/SUNRISE TRANSITION LINE (TERMINATOR)
        float twilightBand = smoothstep(-0.16, 0.02, sunDot) * smoothstep(0.20, 0.02, sunDot);
        vec3 twilightGlow = vec3(1.0, 0.52, 0.16) * twilightBand * 0.55 * uShowTerminator;

        // 3. DEEP NIGHTTIME WITH SPARKLING CITY LIGHTS
        // Subtle ambient starlight on dark landmasses for silhouette recognition
        vec3 nightLandAmbient = rawDay * vec3(0.06, 0.09, 0.14) * 1.2;
        vec3 nightOceanAmbient = vec3(0.015, 0.025, 0.05);
        vec3 nightTerrain = mix(nightLandAmbient, nightOceanAmbient, specularMask);

        // Vibrant golden city lights
        vec3 nightCities = nightLights * vec3(1.4, 1.2, 0.85) * 3.4 * uShowCityLights;

        vec3 litNight = nightTerrain + nightCities;

        // 4. FINAL COMPOSITION
        vec3 finalSurface = mix(litNight, litDay, dayFactor) + twilightGlow;

        gl_FragColor = vec4(finalSurface, 1.0);
      }
    `})}const Ov=6371,Bi=51.64,zr=92.68;function Wa(r,t,i=10){const s=(90-r)*(Math.PI/180),l=(t+180)*(Math.PI/180),c=-i*Math.sin(s)*Math.cos(l),h=i*Math.cos(s),d=i*Math.sin(s)*Math.sin(l);return new J(c,h,d)}function G2(r,t,i,s,l=420){const c=Ov,h=(i-r)*Math.PI/180,d=(s-t)*Math.PI/180,m=Math.sin(h/2)*Math.sin(h/2)+Math.cos(r*Math.PI/180)*Math.cos(i*Math.PI/180)*Math.sin(d/2)*Math.sin(d/2),p=2*Math.atan2(Math.sqrt(m),Math.sqrt(1-m)),g=c*p;return Math.round(Math.sqrt(g*g+l*l))}function V2(r,t,i,s=27575,l=51.6){const c=s/3600,h=2*Math.PI*(Ov+420),d=c*i/h*360,p=(360/(zr*60)-360/86400)*i,g=(t+p+180)%360-180,_=l>90&&l<270,y=Math.max(-.999,Math.min(.999,r/Bi));let v=Math.asin(y);_&&(v=Math.PI-v);const b=d*Math.PI/180,E=v+b,M=Bi*Math.sin(E);return{lat:Math.max(-Bi,Math.min(Bi,M)),lon:g}}function Q_(r,t,i=51.6,s=10.66,l=240){const c=[],h=i>90&&i<270,d=Math.max(-.999,Math.min(.999,r/Bi));let m=Math.asin(d);h&&(m=Math.PI-m);for(let p=0;p<=l;p++){const _=(p/l-.33)*2*Math.PI*1.5,y=m+_,v=Bi*Math.sin(y),b=_/(2*Math.PI)*23.17,E=(t+_*180/Math.PI-b+180)%360-180,M=Wa(v,E,s);c.push({lat:v,lon:E,alt:420,x:M.x,y:M.y,z:M.z})}return c}function Zh(r,t,i,s=-45,l=90,c=.5){const h=[],d=i>90&&i<270,m=Math.max(-.999,Math.min(.999,r/Bi));let p=Math.asin(m);d&&(p=Math.PI-p);const g=2*Math.PI/zr,_=360/zr-360/1440;for(let y=s;y<=l;y+=c){const v=p+g*y,b=Bi*Math.sin(v),E=(t+_*y+180)%360-180;h.push({lat:b,lon:E,minutesOffset:y})}return h}function iu(r=new Date){const t=new Date(r.getUTCFullYear(),0,0),i=Math.floor((r.getTime()-t.getTime())/(1e3*60*60*24)),s=-23.44*Math.cos(2*Math.PI/365*(i+10)),c=-((r.getUTCHours()+r.getUTCMinutes()/60+r.getUTCSeconds()/3600-12)*15);return{lat:s,lon:(c+180)%360-180}}function k2(r=new Date,t=180){const i=iu(r),s=i.lat*Math.PI/180,l=i.lon*Math.PI/180,c=[];for(let h=0;h<=t;h++){const d=-180+360*h/t,p=d*Math.PI/180-l;let g=0;Math.abs(Math.tan(s))>1e-4&&(g=Math.atan(-Math.cos(p)/Math.tan(s)));const _=g*180/Math.PI;c.push([_,d])}return c}function Pv(r,t,i=new Date){const s=iu(i),l=Wa(r,t,1),c=Wa(s.lat,s.lon,1);return l.dot(c)>-.12}function j2(r,t,i,s,l=new Date){const c=i>90&&i<270,h=Math.max(-.999,Math.min(.999,r/Bi));let d=Math.asin(h);c&&(d=Math.PI-d);const m=2*Math.PI/zr,p=360/zr-360/1440;for(let g=.25;g<=zr;g+=.25){const _=d+m*g,y=Bi*Math.sin(_),v=((t+p*g+180)%360+360)%360-180,b=new Date(l.getTime()+g*60*1e3);if(Pv(y,v,b)!==s){const M=Math.max(1,Math.round(g));return{eventName:s?"sunset":"sunrise",countdownMinutes:M}}}return{eventName:s?"sunset":"sunrise",countdownMinutes:45}}const X2=({telemetry:r,cameraMode:t="free",layers:i={atmosphere:!0,clouds:!0,orbit:!0,terminator:!0,cityLights:!0,laserNadir:!0}})=>{const s=ne.useRef(null),l=ne.useRef(null),c=ne.useRef(r);c.current=r;const h=ne.useRef(t);h.current=t;const d=ne.useRef(i);d.current=i;const m=ne.useRef(null),p=ne.useRef(null);return ne.useEffect(()=>{var de,kt,Ae;const g=s.current;if(!g)return;const _=new E1;_.background=new be(198418);const y=g.clientWidth||window.innerWidth,v=g.clientHeight||window.innerHeight,b=new vi(42,y/v,.1,2e3);b.position.set(0,15,32);const E=new M2({antialias:!0,powerPreference:"high-performance"});E.setSize(y,v),E.setPixelRatio(Math.min(window.devicePixelRatio,2)),E.toneMapping=nv,E.toneMappingExposure=1.45,g.appendChild(E.domElement);const M=new E2(b,E.domElement);M.enableDamping=!0,M.dampingFactor=.05,M.minDistance=11.2,M.maxDistance=120,M.rotateSpeed=.8,M.zoomSpeed=1;const x=iu(new Date),P=Wa(x.lat,x.lon,60),N=new M_(16777215,3.8);N.position.copy(P),_.add(N);const w=new I1(1976635,.65);_.add(w);const k=new O1(12248829,988970,.45);_.add(k);const H=new M_(3718648,.4);H.position.set(-P.x,-P.y,-P.z),_.add(H);const I=I2(),j=10,L=10.66,R=new Pr(j,64,64),B=H2(I,P.clone().normalize()),tt=new Qe(R,B);_.add(tt);const et=new Pr(j*1.025,64,64),ut=F2(P.clone().normalize()),ft=new Qe(et,ut);_.add(ft),m.current=ft;const z=new Pr(j+.08,64,64),W=new Rr({map:I.clouds,transparent:!0,opacity:.8,blending:qa,depthWrite:!1}),X=new Qe(z,W);_.add(X),p.current=X;const _t=3500,Et=new Float32Array(_t*3),O=new Float32Array(_t*3);for(let Rt=0;Rt<_t;Rt++){const U=250+Math.random()*250,T=2*Math.PI*Math.random(),$=Math.acos(2*Math.random()-1);Et[Rt*3]=U*Math.sin($)*Math.cos(T),Et[Rt*3+1]=U*Math.sin($)*Math.sin(T),Et[Rt*3+2]=U*Math.cos($);const dt=Math.random();if(dt>.8)O[Rt*3]=.75,O[Rt*3+1]=.88,O[Rt*3+2]=1;else if(dt>.65)O[Rt*3]=1,O[Rt*3+1]=.95,O[Rt*3+2]=.8;else{const St=.6+Math.random()*.4;O[Rt*3]=St,O[Rt*3+1]=St,O[Rt*3+2]=St}}const at=new Gn;at.setAttribute("position",new Jn(Et,3)),at.setAttribute("color",new Jn(O,3));const vt=new Tv({size:1.2,vertexColors:!0,transparent:!0,opacity:.85}),Y=new R1(at,vt);_.add(Y);const st=B2();l.current=st,_.add(st.issGroup),_.add(st.nadirBeam),_.add(st.footprintRing),_.add(st.pulseRing),_.add(st.orbitLine);const xt=((de=c.current)==null?void 0:de.latitude)??6.724,bt=((kt=c.current)==null?void 0:kt.longitude)??-140.032,Ft=((Ae=c.current)==null?void 0:Ae.headingDeg)??51.6,Xt=Wa(xt,bt,L),Yt=Wa(xt,bt,j);st.updatePosition(Xt,Yt);const ze=Q_(xt,bt,Ft,L,240);st.updateOrbitTrail(ze.map(Rt=>new J(Rt.x,Rt.y,Rt.z)));const Ue=()=>{if(!g)return;const Rt=g.clientWidth||window.innerWidth,U=g.clientHeight||window.innerHeight;b.aspect=Rt/U,b.updateProjectionMatrix(),E.setSize(Rt,U)};window.addEventListener("resize",Ue);let fe,G=performance.now(),Je=Xt.clone();const le=Rt=>{fe=requestAnimationFrame(le);const U=(Rt-G)/1e3;G=Rt;const T=d.current;if(m.current&&(m.current.visible=T.atmosphere),p.current&&(p.current.visible=T.clouds,p.current.rotation.y+=U*.008),st.orbitLine&&(st.orbitLine.visible=T.orbit),st.nadirBeam&&(st.nadirBeam.visible=T.laserNadir),st.footprintRing&&(st.footprintRing.visible=T.laserNadir),st.pulseRing&&(st.pulseRing.visible=T.laserNadir),B.uniforms.uShowCityLights&&(B.uniforms.uShowCityLights.value=T.cityLights?1:0),B.uniforms.uShowTerminator&&(B.uniforms.uShowTerminator.value=T.terminator?1:0),st.pulseRing){const Bt=1+.35*Math.sin(Rt*.004);st.pulseRing.scale.set(Bt,Bt,Bt),st.pulseRing.material.opacity=.45*(1.35-(Bt-1))}const $=c.current;if($){const Bt=(Date.now()-$.timestamp)/1e3,Ct=V2($.latitude,$.longitude,Bt,$.velocityKmH,$.headingDeg),It=Wa(Ct.lat,Ct.lon,L),pe=Wa(Ct.lat,Ct.lon,j);st.updatePosition(It,pe),Je=It}const dt=h.current,St=new J,mt=new J;if(dt==="iss"){const Bt=Je.clone().normalize().multiplyScalar(4.5);St.copy(Je).add(Bt),mt.copy(Je),M.enabled=!1,b.position.lerp(St,.05),M.target.lerp(mt,.05),b.lookAt(M.target)}else dt==="cupola"?(St.copy(Je),mt.set(0,0,0),M.enabled=!1,b.position.lerp(St,.05),M.target.lerp(mt,.05),b.lookAt(M.target)):dt==="north"?(St.set(0,34,.1),mt.set(0,0,0),M.enabled=!1,b.position.lerp(St,.04),M.target.lerp(mt,.04),b.lookAt(M.target)):dt==="sun"?(St.copy(P).normalize().multiplyScalar(32),mt.set(0,0,0),M.enabled=!1,b.position.lerp(St,.04),M.target.lerp(mt,.04),b.lookAt(M.target)):(M.target.lengthSq()>1e-4&&M.target.lerp(new J(0,0,0),.08),M.enabled=!0,M.update());E.render(_,b)};return le(performance.now()),()=>{cancelAnimationFrame(fe),window.removeEventListener("resize",Ue),M.dispose(),E.dispose(),g.contains(E.domElement)&&g.removeChild(E.domElement)}},[]),ne.useEffect(()=>{if(r&&l.current){const g=Q_(r.latitude,r.longitude,r.headingDeg,10.66,240);l.current.updateOrbitTrail(g.map(_=>new J(_.x,_.y,_.z)))}},[r==null?void 0:r.latitude,r==null?void 0:r.longitude,r==null?void 0:r.headingDeg]),D.jsx("div",{className:"space-container",ref:s})};/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W2=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),zv=(...r)=>r.filter((t,i,s)=>!!t&&t.trim()!==""&&s.indexOf(t)===i).join(" ").trim();/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var q2={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y2=ne.forwardRef(({color:r="currentColor",size:t=24,strokeWidth:i=2,absoluteStrokeWidth:s,className:l="",children:c,iconNode:h,...d},m)=>ne.createElement("svg",{ref:m,...q2,width:t,height:t,stroke:r,strokeWidth:s?Number(i)*24/Number(t):i,className:zv("lucide",l),...d},[...h.map(([p,g])=>ne.createElement(p,g)),...Array.isArray(c)?c:[c]]));/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ne=(r,t)=>{const i=ne.forwardRef(({className:s,...l},c)=>ne.createElement(Y2,{ref:c,iconNode:t,className:zv(`lucide-${W2(r)}`,s),...l}));return i.displayName=`${r}`,i};/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z2=[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]],K2=Ne("ArrowUpRight",Z2);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q2=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],Iv=Ne("Bell",Q2);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J2=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],$2=Ne("Check",J2);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tA=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],eA=Ne("ChevronDown",tA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nA=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],iA=Ne("ChevronUp",nA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const aA=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]],Bv=Ne("CircleHelp",aA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sA=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],rA=Ne("Clock",sA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oA=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Jd=Ne("Compass",oA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lA=[["path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54",key:"1djwo0"}],["path",{d:"M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",key:"1tzkfa"}],["path",{d:"M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",key:"14pb5j"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],cA=Ne("Earth",lA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const uA=[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]],fA=Ne("EyeOff",uA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hA=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],$d=Ne("Eye",hA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dA=[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]],pA=Ne("Gauge",dA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mA=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],gA=Ne("Globe",mA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _A=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],vA=Ne("Layers",_A);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xA=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],Fv=Ne("MapPin",xA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yA=[["path",{d:"M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",key:"169xi5"}],["path",{d:"M15 5.764v15",key:"1pn4in"}],["path",{d:"M9 3.236v15",key:"1uimfh"}]],SA=Ne("Map",yA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const MA=[["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["polyline",{points:"9 21 3 21 3 15",key:"1avn1i"}],["line",{x1:"21",x2:"14",y1:"3",y2:"10",key:"ota7mn"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]],bA=Ne("Maximize2",MA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const EA=[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3",key:"1dcmit"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3",key:"1e4gt3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3",key:"wsl5sc"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3",key:"18trek"}]],TA=Ne("Maximize",EA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const AA=[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]],RA=Ne("Minimize2",AA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const CA=[["path",{d:"M8 3v3a2 2 0 0 1-2 2H3",key:"hohbtr"}],["path",{d:"M21 8h-3a2 2 0 0 1-2-2V3",key:"5jw1f3"}],["path",{d:"M3 16h3a2 2 0 0 1 2 2v3",key:"198tvr"}],["path",{d:"M16 21v-3a2 2 0 0 1 2-2h3",key:"ph8mxp"}]],wA=Ne("Minimize",CA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const DA=[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]],LA=Ne("Moon",DA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const UA=[["path",{d:"M4.9 19.1C1 15.2 1 8.8 4.9 4.9",key:"1vaf9d"}],["path",{d:"M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5",key:"u1ii0m"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5",key:"1j5fej"}],["path",{d:"M19.1 4.9C23 8.8 23 15.1 19.1 19",key:"10b0cb"}]],NA=Ne("Radio",UA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const OA=[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]],Hv=Ne("Rocket",OA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const PA=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],zA=Ne("Shield",PA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const IA=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],Gv=Ne("Sparkles",IA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const BA=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],Jc=Ne("Sun",BA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const FA=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],HA=Ne("Target",FA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const GA=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]],Vv=Ne("Users",GA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const VA=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],kv=Ne("Video",VA);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kA=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],tp=Ne("X",kA),jA=[{points:[[-168,65],[-160,71],[-140,70],[-120,69],[-85,70],[-75,60],[-60,50],[-65,44],[-75,35],[-80,25],[-97,26],[-97,18],[-88,16],[-83,10],[-77,8],[-80,9],[-88,14],[-105,20],[-110,23],[-117,32],[-124,38],[-125,48],[-135,58],[-150,60],[-165,60],[-168,65]]},{points:[[-77,8],[-72,11],[-60,10],[-50,0],[-35,-5],[-35,-10],[-39,-15],[-42,-23],[-50,-30],[-55,-35],[-65,-45],[-68,-55],[-75,-50],[-74,-40],[-70,-30],[-70,-18],[-80,-5],[-77,8]]},{points:[[-9,36],[-9,43],[0,44],[5,53],[10,58],[25,71],[40,68],[60,70],[80,73],[105,78],[140,72],[170,66],[180,65],[170,60],[140,50],[130,42],[122,30],[108,20],[100,5],[104,1],[98,10],[90,22],[80,10],[70,23],[60,25],[50,13],[44,12],[36,31],[27,38],[24,35],[15,40],[5,36],[-5,36],[-9,36]]},{points:[[-5,36],[10,37],[25,32],[32,30],[43,12],[51,12],[42,0],[40,-10],[35,-25],[28,-34],[18,-34],[12,-15],[10,0],[0,5],[-15,12],[-17,21],[-10,30],[-5,36]]},{points:[[114,-22],[122,-16],[136,-12],[142,-11],[150,-22],[153,-28],[150,-37],[138,-38],[130,-32],[115,-35],[113,-25],[114,-22]]},{points:[[-45,60],[-35,65],[-20,75],[-30,83],[-55,82],[-60,76],[-50,68],[-45,60]]},{points:[[-5,50],[1,51],[0,54],[-2,58],[-6,58],[-4,55],[-5,50]]},{points:[[130,32],[136,35],[141,38],[145,44],[140,45],[136,40],[131,34],[130,32]]},{points:[[-180,-65],[-120,-72],[-60,-65],[0,-68],[60,-66],[120,-65],[180,-65],[180,-90],[-180,-90],[-180,-65]]}],XA=({telemetry:r,userCoords:t,layers:i,lang:s="es"})=>{const l=ne.useRef(null),[c,h]=ne.useState(!0),[d,m]=ne.useState(!1),p=ne.useRef(null),g=ne.useRef(null),[,_]=ne.useState(!1);return ne.useEffect(()=>{let y=0;const v=()=>{y++,y>=2&&_(!0)},b=new Image;b.src="/textures/earth_day_4096.jpg",b.onload=()=>{p.current=b,v()};const E=new Image;E.src="/textures/earth_night_4096.jpg",E.onload=()=>{g.current=E,v()}},[]),ne.useEffect(()=>{if(!c)return;const y=l.current;if(!y)return;const v=y.getContext("2d");if(!v)return;const b=Math.min(window.devicePixelRatio||1,2),E=y.getBoundingClientRect(),M=E.width,x=E.height;y.width=M*b,y.height=x*b,v.scale(b,b);const P=R=>(R+180)/360*M,N=R=>(90-R)/180*x;if(p.current&&p.current.complete)v.drawImage(p.current,0,0,M,x),v.fillStyle="rgba(6, 24, 54, 0.1)",v.fillRect(0,0,M,x);else{v.fillStyle="#0a1e3f",v.fillRect(0,0,M,x),v.fillStyle="#1e3a5f",v.strokeStyle="rgba(56, 189, 248, 0.4)",v.lineWidth=1;for(const R of jA)v.beginPath(),R.points.forEach(([B,tt],et)=>{const ut=P(B),ft=N(tt);et===0?v.moveTo(ut,ft):v.lineTo(ut,ft)}),v.closePath(),v.fill(),v.stroke()}v.strokeStyle="rgba(255, 255, 255, 0.12)",v.lineWidth=.8;for(let R=-180;R<=180;R+=60){const B=P(R);v.beginPath(),v.moveTo(B,0),v.lineTo(B,x),v.stroke()}for(let R=-60;R<=60;R+=30){const B=N(R);v.beginPath(),v.moveTo(0,B),v.lineTo(M,B),v.stroke()}const w=i?i.terminator:!0,k=iu(new Date);if(w){const R=k2(new Date,160),tt=k.lat>=0?x:0;v.save(),v.beginPath(),v.moveTo(0,tt),R.forEach(([ft,z],W)=>{const X=P(z),_t=N(ft);v.lineTo(X,_t)}),v.lineTo(M,tt),v.closePath(),v.clip(),g.current&&g.current.complete?(v.drawImage(g.current,0,0,M,x),v.fillStyle="rgba(4, 12, 34, 0.38)",v.fillRect(0,0,M,x)):(v.fillStyle="rgba(4, 12, 34, 0.45)",v.fillRect(0,0,M,x)),v.restore(),v.save(),v.strokeStyle="#f97316",v.lineWidth=d?2:1.6,v.shadowColor="rgba(249, 115, 22, 0.8)",v.shadowBlur=6,v.beginPath(),R.forEach(([ft,z],W)=>{const X=P(z),_t=N(ft);W===0?v.moveTo(X,_t):v.lineTo(X,_t)}),v.stroke(),v.restore();const et=P(k.lon),ut=N(k.lat);v.save(),v.fillStyle="#facc15",v.shadowColor="#facc15",v.shadowBlur=10,v.beginPath(),v.arc(et,ut,d?6:4,0,Math.PI*2),v.fill(),v.strokeStyle="rgba(250, 204, 21, 0.7)",v.lineWidth=1.2,v.setLineDash([2,3]),v.beginPath(),v.arc(et,ut,d?12:8,0,Math.PI*2),v.stroke(),v.restore()}const H=(R,B,tt,et=!1,ut=!1)=>{if(R.length===0)return;v.save(),v.strokeStyle=B,v.lineWidth=tt,et?v.setLineDash([4,4]):v.setLineDash([]),ut&&(v.shadowColor=B,v.shadowBlur=6),v.beginPath();let ft=!1,z=0;for(let W=0;W<R.length;W++){const X=P(R[W].lon),_t=N(R[W].lat);!ft||Math.abs(X-z)>M/2?(v.moveTo(X,_t),ft=!0):v.lineTo(X,_t),z=X}v.stroke(),v.restore()};if(i?i.orbit:!0){const R=Zh(r.latitude,r.longitude,r.headingDeg,-135,-45);H(R,"rgba(148, 163, 184, 0.55)",d?1.4:1.1,!0);const B=Zh(r.latitude,r.longitude,r.headingDeg,90,180);H(B,"rgba(0, 229, 255, 0.75)",d?1.6:1.3,!0,!0);const tt=Zh(r.latitude,r.longitude,r.headingDeg,-45,90);H(tt,"#00e5ff",d?3:2.4,!1,!0),((ut,ft)=>{ft.forEach(z=>{const W=ut.findIndex(X=>X.minutesOffset>=z);if(W>0&&W<ut.length-1){const X=ut[W],_t=ut[W+1],Et=P(X.lon),O=N(X.lat),at=P(_t.lon),vt=N(_t.lat);if(Math.abs(at-Et)<M/3){const Y=Math.atan2(vt-O,at-Et),st=d?7.5:5.5;v.save(),v.translate(Et,O),v.rotate(Y),v.fillStyle="#00e5ff",v.shadowColor="#00e5ff",v.shadowBlur=8,v.beginPath(),v.moveTo(st,0),v.lineTo(-st*.7,-st*.6),v.lineTo(-st*.3,0),v.lineTo(-st*.7,st*.6),v.closePath(),v.fill(),v.restore()}}})})(tt,[-30,-10,20,50,75])}if(t){const R=P(t.longitude),B=N(t.latitude);v.fillStyle="#4ade80",v.shadowColor="#4ade80",v.shadowBlur=8,v.beginPath(),v.arc(R,B,d?5:3.5,0,Math.PI*2),v.fill(),v.shadowBlur=0}const j=P(r.longitude),L=N(r.latitude);v.save(),v.strokeStyle="rgba(74, 222, 128, 0.75)",v.lineWidth=d?2:1.4,v.beginPath(),v.arc(j,L,d?42:18,0,Math.PI*2),v.stroke(),v.strokeStyle="#00e5ff",v.lineWidth=d?2.2:1.8,v.shadowColor="#00e5ff",v.shadowBlur=10,v.beginPath(),v.arc(j,L,d?10:7.5,0,Math.PI*2),v.stroke(),v.fillStyle="#ffffff",v.beginPath(),v.arc(j,L,d?4:3,0,Math.PI*2),v.fill(),v.restore()},[r,t,i,c,d]),D.jsxs(D.Fragment,{children:[d&&D.jsx("div",{style:{position:"fixed",inset:0,backgroundColor:"rgba(3, 7, 18, 0.75)",backdropFilter:"blur(10px)",zIndex:45},onClick:()=>m(!1)}),D.jsxs("div",{className:"glass-panel",style:d?{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"min(980px, 92vw)",maxHeight:"88vh",zIndex:50,padding:"16px 20px",borderRadius:"16px",boxShadow:"0 25px 60px rgba(0, 0, 0, 0.9)",border:"1px solid rgba(56, 189, 248, 0.4)",display:"flex",flexDirection:"column"}:{position:"absolute",top:"72px",right:"16px",zIndex:20,padding:"10px 12px",width:"320px",transition:"all 0.25s cubic-bezier(0.4, 0, 0.2, 1)"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:c?"8px":0},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[D.jsx("span",{className:"live-dot",style:{width:"6px",height:"6px"}}),D.jsx("span",{style:{fontSize:d?"14px":"11px",fontWeight:700,letterSpacing:"0.08em",color:"#38bdf8",textTransform:"uppercase"},children:d?s==="es"?"Minimapa 2D — Vista Mission Control":"2D Map — Mission Control View":s==="es"?"Minimapa 2D":"2D Minimap"})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px"},children:[!d&&D.jsx("button",{onClick:()=>h(!c),style:{background:"transparent",border:"none",color:"#94a3b8",cursor:"pointer",padding:"3px",display:"flex",alignItems:"center"},title:c?"Ocultar":"Mostrar",children:c?D.jsx($d,{size:14}):D.jsx(fA,{size:14})}),D.jsx("button",{onClick:()=>m(!d),style:{background:d?"rgba(239, 68, 68, 0.2)":"rgba(56, 189, 248, 0.15)",border:`1px solid ${d?"rgba(239, 68, 68, 0.4)":"rgba(56, 189, 248, 0.3)"}`,borderRadius:"6px",color:d?"#fca5a5":"#00e5ff",cursor:"pointer",padding:"4px 6px",display:"flex",alignItems:"center",gap:"4px",fontSize:"10px",fontWeight:600},title:d?"Cerrar vista":"Maximizar minimapa",children:d?D.jsxs(D.Fragment,{children:[D.jsx(RA,{size:13}),D.jsx("span",{children:s==="es"?"Cerrar":"Close"})]}):D.jsx(bA,{size:13})})]})]}),c&&D.jsxs(D.Fragment,{children:[D.jsx("div",{style:{width:"100%",height:d?"480px":"150px",borderRadius:"10px",overflow:"hidden",border:"1px solid rgba(56, 189, 248, 0.25)",position:"relative",backgroundColor:"#040d1e",transition:"height 0.25s ease"},children:D.jsx("canvas",{ref:l,style:{width:"100%",height:"100%",display:"block"}})}),d?D.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(4, 1fr)",gap:"12px",marginTop:"12px",padding:"10px 14px",backgroundColor:"rgba(8, 20, 42, 0.6)",borderRadius:"10px",border:"1px solid rgba(56, 189, 248, 0.15)"},children:[D.jsxs("div",{children:[D.jsx("div",{style:{fontSize:"10px",color:"#94a3b8",textTransform:"uppercase"},children:"Ubicación"}),D.jsx("div",{className:"font-mono",style:{fontSize:"13px",fontWeight:600,color:"#00e5ff"},children:r.locationName})]}),D.jsxs("div",{children:[D.jsx("div",{style:{fontSize:"10px",color:"#94a3b8",textTransform:"uppercase"},children:"Coordenadas"}),D.jsxs("div",{className:"font-mono",style:{fontSize:"13px",fontWeight:600,color:"#f8fafc"},children:[r.latitude.toFixed(2),"°, ",r.longitude.toFixed(2),"°"]})]}),D.jsxs("div",{children:[D.jsx("div",{style:{fontSize:"10px",color:"#94a3b8",textTransform:"uppercase"},children:"Velocidad"}),D.jsxs("div",{className:"font-mono",style:{fontSize:"13px",fontWeight:600,color:"#f8fafc"},children:[r.velocityKmH.toLocaleString()," km/h (Mach ",r.mach,")"]})]}),D.jsxs("div",{children:[D.jsx("div",{style:{fontSize:"10px",color:"#94a3b8",textTransform:"uppercase"},children:"Altitud"}),D.jsxs("div",{className:"font-mono",style:{fontSize:"13px",fontWeight:600,color:"#f8fafc"},children:[r.altitudeKm," km"]})]})]}):D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:"6px",fontSize:"10px",color:"#94a3b8"},children:[t?D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[D.jsx("span",{style:{width:"5px",height:"5px",borderRadius:"50%",backgroundColor:"#4ade80"}}),D.jsx("span",{children:s==="es"?"Tu ubicación":"Your location"})]}):D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[D.jsx("span",{style:{width:"5px",height:"5px",borderRadius:"50%",backgroundColor:"#64748b"}}),D.jsx("span",{children:s==="es"?"GPS desactivado":"GPS disabled"})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[D.jsx("span",{style:{width:"5px",height:"5px",borderRadius:"50%",backgroundColor:"#facc15"}}),D.jsx("span",{children:s==="es"?"Sol":"Sun"})]})]})]})]})]})},WA={es:{appTitle:"ISS TRACKER 3D",liveBadge:"EN VIVO",nextPasses:"Próximos Pases",crewOnboard:"Tripulación a bordo",fullscreen:"Pantalla completa",exitFullscreen:"Salir de pantalla completa",groundLocation:"UBICACIÓN TERRESTRE",orbitalVelocity:"VELOCIDAD ORBITAL",altitude:"ALTITUD",leoOrbit:"LEO Orbit",solarCycle:"CICLO SOLAR ORBITAL",sunlitBadge:"A la luz solar",eclipsedBadge:"En sombra terrestre",nextEvent:"Próximo evento",orbitalSunset:"Puesta de sol orbital",orbitalSunrise:"Amanecer orbital",distanceToYou:"Distancia a ti",locatingUser:"Sin GPS",minimapTitle:"MINIMAPA 2D",userLocationDetected:"Tu ubicación detectada",hide:"Ocultar",show:"Mostrar",expand:"Expandir",reduce:"Reducir",camFree:"Órbita Libre",camFollow:"Fijar a la ISS",camCupola:"Vista Cúpula (Nadir)",camNorth:"Polo Norte",camSun:"Perspectiva Solar",visualLayers:"Capas Visuales",layerAtmosphere:"Atmósfera",layerClouds:"Capa de Nubes",layerOrbit:"Trayectoria Orbital",layerTerminator:"Terminador Solar",layerCityLights:"Luces Nocturnas",layerLaserNadir:"Haz Láser Nadir",crewTitle:"Tripulación a Bordo de la ISS",crewSubtitle:"Astronautas y cosmonautas actualmente en la Expedición Activa",roleCommander:"Comandante",roleFlightEngineer:"Ingeniero de Vuelo",roleMissionSpecialist:"Especialista de Misión",daysInSpace:"días en órbita",agency:"Agencia",craft:"Nave",close:"Cerrar",passesTitle:"Próximos Avistamientos de la ISS",passesSubtitle:"Pases visibles calculados sobre tu ubicación geográfica",passDate:"Fecha y Hora",passDuration:"Duración",passMaxElevation:"Elevación Máx.",passBrightness:"Brillo (Mag)",passTrajectory:"Trayectoria",noPassesFound:"No hay pases visibles en las próximas 48 horas para tu ubicación.",permissionDenied:"Activa la geolocalización para calcular pases exactos sobre tu ciudad.",requestLocation:"Activar Ubicación",missionGuide:"Guía de Misión",guideTitle:"Manual del Centro de Control",guideSubtitle:"Conceptos orbitales, telemetría y navegación de la Estación Espacial Internacional",tabMinimap:"Minimapa 2D",tabSolarCycle:"Día, Noche y Sol",tabTelemetry:"Telemetría",tabCameras:"Cámaras y 3D"},en:{appTitle:"ISS TRACKER 3D",liveBadge:"LIVE",nextPasses:"Upcoming Passes",crewOnboard:"Crew Onboard",missionGuide:"Mission Guide",fullscreen:"Fullscreen",exitFullscreen:"Exit Fullscreen",groundLocation:"GROUND LOCATION",orbitalVelocity:"ORBITAL VELOCITY",altitude:"ALTITUDE",leoOrbit:"LEO Orbit",solarCycle:"ORBITAL SOLAR CYCLE",sunlitBadge:"In Sunlight",eclipsedBadge:"In Earth Shadow",nextEvent:"Next event",orbitalSunset:"Orbital Sunset",orbitalSunrise:"Orbital Sunrise",distanceToYou:"Distance to you",locatingUser:"No GPS",minimapTitle:"2D MINIMAP",userLocationDetected:"Your detected location",hide:"Hide",show:"Show",expand:"Expand",reduce:"Reduce",camFree:"Free Orbit",camFollow:"Follow ISS",camCupola:"Cupola View (Nadir)",camNorth:"North Pole",camSun:"Solar Perspective",visualLayers:"Visual Layers",layerAtmosphere:"Atmosphere",layerClouds:"Clouds Layer",layerOrbit:"Orbital Trajectory",layerTerminator:"Solar Terminator",layerCityLights:"Night City Lights",layerLaserNadir:"Nadir Laser Beam",crewTitle:"ISS Onboard Crew",crewSubtitle:"Astronauts & Cosmonauts currently serving on Active Expedition",roleCommander:"Commander",roleFlightEngineer:"Flight Engineer",roleMissionSpecialist:"Mission Specialist",daysInSpace:"days in orbit",agency:"Agency",craft:"Spacecraft",close:"Close",passesTitle:"Upcoming ISS Sightings",passesSubtitle:"Visible passes calculated for your geographic location",passDate:"Date & Time",passDuration:"Duration",passMaxElevation:"Max Elevation",passBrightness:"Brightness (Mag)",passTrajectory:"Trajectory",noPassesFound:"No visible passes in the next 48 hours for your location.",permissionDenied:"Enable geolocation to calculate precise sightings over your city.",requestLocation:"Enable Geolocation",guideTitle:"Mission Control Manual",guideSubtitle:"Orbital mechanics, telemetry, and 3D navigation for the International Space Station",tabMinimap:"2D Minimap",tabSolarCycle:"Day, Night & Sun",tabTelemetry:"Telemetry",tabCameras:"Cameras & 3D"}};function Xr(r="es"){return WA[r]}const qA=({lang:r,onToggleLang:t,onOpenCrew:i,onOpenPasses:s,onOpenGuide:l,crewCount:c})=>{const h=Xr(r),[d,m]=ne.useState(""),[p,g]=ne.useState(!1);ne.useEffect(()=>{const y=()=>{const b=new Date,E=String(b.getUTCHours()).padStart(2,"0"),M=String(b.getUTCMinutes()).padStart(2,"0"),x=String(b.getUTCSeconds()).padStart(2,"0");m(`${E}:${M}:${x} UTC`)};y();const v=setInterval(y,1e3);return()=>clearInterval(v)},[]);const _=()=>{document.fullscreenElement?document.exitFullscreen().then(()=>g(!1)).catch(()=>{}):document.documentElement.requestFullscreen().then(()=>g(!0)).catch(()=>{})};return D.jsxs("header",{style:{position:"absolute",top:"16px",left:"16px",right:"16px",display:"flex",alignItems:"center",justifyContent:"space-between",zIndex:30,pointerEvents:"none"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px",pointerEvents:"auto"},children:[D.jsxs("div",{className:"glass-panel",style:{display:"flex",alignItems:"center",gap:"8px",padding:"7px 14px",borderRadius:"9999px"},children:[D.jsx("div",{style:{width:"24px",height:"24px",borderRadius:"50%",backgroundColor:"rgba(0, 229, 255, 0.15)",display:"flex",alignItems:"center",justifyContent:"center",border:"1px solid rgba(0, 229, 255, 0.4)"},children:D.jsx(NA,{size:14,color:"#00e5ff"})}),D.jsx("span",{style:{fontSize:"13px",fontWeight:700,letterSpacing:"0.06em",color:"#f8fafc"},children:h.appTitle})]}),D.jsxs("div",{className:"glass-panel",style:{display:"flex",alignItems:"center",gap:"6px",padding:"7px 12px",borderRadius:"9999px",fontSize:"11px",fontWeight:600,letterSpacing:"0.05em",color:"#4ade80"},children:[D.jsx("span",{className:"live-dot"}),D.jsx("span",{children:h.liveBadge})]}),D.jsx("div",{className:"glass-panel font-mono",style:{padding:"7px 14px",borderRadius:"9999px",fontSize:"12px",fontWeight:500,color:"#94a3b8",letterSpacing:"0.05em"},children:d})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",pointerEvents:"auto"},children:[D.jsxs("button",{onClick:l,className:"glass-panel glass-panel-interactive",style:{display:"flex",alignItems:"center",gap:"7px",padding:"7px 16px",borderRadius:"9999px",background:"linear-gradient(135deg, rgba(0, 229, 255, 0.22) 0%, rgba(14, 165, 233, 0.12) 100%)",border:"1px solid rgba(0, 229, 255, 0.55)",boxShadow:"0 0 16px rgba(0, 229, 255, 0.28)",color:"#f8fafc",fontSize:"12px",fontWeight:600,cursor:"pointer",letterSpacing:"0.02em",transition:"all 0.2s ease"},children:[D.jsx(Bv,{size:14,color:"#00e5ff"}),D.jsx("span",{style:{color:"#e0f2fe"},children:h.missionGuide})]}),D.jsxs("button",{onClick:s,className:"glass-panel glass-panel-interactive",style:{display:"flex",alignItems:"center",gap:"6px",padding:"7px 14px",borderRadius:"9999px",color:"#f8fafc",fontSize:"12px",fontWeight:500,cursor:"pointer",border:"1px solid rgba(56, 189, 248, 0.25)"},children:[D.jsx(Iv,{size:13,color:"#38bdf8"}),D.jsx("span",{children:h.nextPasses})]}),D.jsxs("button",{onClick:i,className:"glass-panel glass-panel-interactive",style:{display:"flex",alignItems:"center",gap:"6px",padding:"7px 14px",borderRadius:"9999px",color:"#f8fafc",fontSize:"12px",fontWeight:500,cursor:"pointer",border:"1px solid rgba(56, 189, 248, 0.25)"},children:[D.jsx(Vv,{size:13,color:"#38bdf8"}),D.jsxs("span",{children:[h.crewOnboard," (",c,")"]})]}),D.jsxs("button",{onClick:t,className:"glass-panel glass-panel-interactive",style:{display:"flex",alignItems:"center",gap:"5px",padding:"7px 12px",borderRadius:"9999px",color:"#f8fafc",fontSize:"12px",fontWeight:600,cursor:"pointer",border:"1px solid rgba(56, 189, 248, 0.25)"},children:[D.jsx(gA,{size:13,color:"#00e5ff"}),D.jsx("span",{style:{textTransform:"uppercase"},children:r})]}),D.jsx("button",{onClick:_,className:"glass-panel glass-panel-interactive",style:{display:"flex",alignItems:"center",justifyContent:"center",width:"34px",height:"34px",borderRadius:"50%",color:"#f8fafc",cursor:"pointer",border:"1px solid rgba(56, 189, 248, 0.25)"},title:p?h.exitFullscreen:h.fullscreen,children:p?D.jsx(wA,{size:14,color:"#94a3b8"}):D.jsx(TA,{size:14,color:"#94a3b8"})})]})]})},jv=({telemetry:r,lang:t})=>{const i=Xr(t),s=c=>{const h=c>=0?"N":"S";return`${Math.abs(c).toFixed(4)}° ${h}`},l=c=>{const h=c>=0?"E":"W";return`${Math.abs(c).toFixed(4)}° ${h}`};return D.jsxs("div",{style:{position:"absolute",top:"72px",left:"16px",width:"320px",display:"flex",flexDirection:"column",gap:"12px",zIndex:20,pointerEvents:"auto"},children:[D.jsxs("div",{className:"glass-panel",style:{padding:"12px 14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"6px"},children:[D.jsx("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:D.jsx("span",{style:{fontSize:"10px",fontWeight:700,letterSpacing:"0.08em",color:"#38bdf8",textTransform:"uppercase"},children:i.groundLocation})}),D.jsxs("div",{className:"font-mono",style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"10px",color:"#94a3b8"},children:[D.jsx(Jd,{size:11,color:"#38bdf8"}),D.jsxs("span",{children:[s(r.latitude)," · ",l(r.longitude)]})]})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginTop:"4px"},children:[D.jsx(cA,{size:16,color:"#00e5ff",style:{flexShrink:0}}),D.jsx("span",{style:{fontSize:"13px",fontWeight:600,color:"#00e5ff",letterSpacing:"0.02em"},children:r.locationName})]})]}),D.jsx("div",{className:"glass-panel",style:{padding:"14px"},children:D.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"16px"},children:[D.jsxs("div",{children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"5px",marginBottom:"4px"},children:[D.jsx(Hv,{size:12,color:"#38bdf8"}),D.jsx("span",{style:{fontSize:"10px",fontWeight:700,letterSpacing:"0.08em",color:"#94a3b8",textTransform:"uppercase"},children:i.orbitalVelocity})]}),D.jsxs("div",{style:{display:"flex",alignItems:"baseline",gap:"4px"},children:[D.jsx("span",{className:"font-mono",style:{fontSize:"22px",fontWeight:700,color:"#f8fafc",letterSpacing:"-0.02em"},children:r.velocityKmH.toLocaleString()}),D.jsx("span",{style:{fontSize:"11px",color:"#64748b"},children:"km/h"})]}),D.jsxs("div",{className:"font-mono",style:{fontSize:"10px",color:"#38bdf8",marginTop:"4px"},children:["Mach ",r.mach," · ",r.velocityMph.toLocaleString()," mph"]})]}),D.jsxs("div",{style:{borderLeft:"1px solid rgba(56, 189, 248, 0.15)",paddingLeft:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"5px",marginBottom:"4px"},children:[D.jsx(K2,{size:12,color:"#38bdf8"}),D.jsx("span",{style:{fontSize:"10px",fontWeight:700,letterSpacing:"0.08em",color:"#94a3b8",textTransform:"uppercase"},children:i.altitude})]}),D.jsxs("div",{style:{display:"flex",alignItems:"baseline",gap:"4px"},children:[D.jsx("span",{className:"font-mono",style:{fontSize:"22px",fontWeight:700,color:"#f8fafc",letterSpacing:"-0.02em"},children:r.altitudeKm.toFixed(1)}),D.jsx("span",{style:{fontSize:"11px",color:"#64748b"},children:"km"})]}),D.jsxs("div",{className:"font-mono",style:{fontSize:"10px",color:"#38bdf8",marginTop:"4px"},children:[r.altitudeMi.toFixed(1)," mi · ",i.leoOrbit]})]})]})}),D.jsxs("div",{className:"glass-panel",style:{padding:"12px 14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"8px"},children:[D.jsx("span",{style:{fontSize:"10px",fontWeight:700,letterSpacing:"0.08em",color:"#94a3b8",textTransform:"uppercase"},children:i.solarCycle}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",padding:"3px 8px",borderRadius:"9999px",backgroundColor:r.isSunlit?"rgba(250, 204, 21, 0.15)":"rgba(99, 102, 241, 0.15)",border:`1px solid ${r.isSunlit?"rgba(250, 204, 21, 0.4)":"rgba(99, 102, 241, 0.4)"}`,color:r.isSunlit?"#facc15":"#a5b4fc",fontSize:"10px",fontWeight:600},children:[r.isSunlit?D.jsx(Jc,{size:11}):D.jsx(LA,{size:11}),D.jsx("span",{children:r.isSunlit?i.sunlitBadge:i.eclipsedBadge})]})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:"11px",color:"#cbd5e1"},children:[D.jsxs("span",{children:[i.nextEvent,":"," ",D.jsx("strong",{style:{color:"#f8fafc"},children:r.sunEventName==="sunset"?i.orbitalSunset:i.orbitalSunrise})]}),D.jsxs("span",{className:"font-mono",style:{color:"#00e5ff",fontWeight:600},children:["~",r.sunEventCountdownMinutes," min"]})]})]}),D.jsxs("div",{className:"glass-panel",style:{padding:"10px 14px",display:"flex",alignItems:"center",justifyContent:"space-between"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[D.jsx(Fv,{size:13,color:"#4ade80"}),D.jsx("span",{style:{fontSize:"11px",color:"#cbd5e1",fontWeight:500},children:i.distanceToYou})]}),D.jsx("div",{className:"font-mono",style:{fontSize:"14px",fontWeight:700,color:"#4ade80",letterSpacing:"0.02em"},children:r.distanceToUserKm!==null?`${r.distanceToUserKm.toLocaleString()} km`:i.locatingUser})]})]})},YA=({activeMode:r,onSelectMode:t,layers:i,onToggleLayer:s,lang:l})=>{const c=Xr(l),[h,d]=ne.useState(!1),m=[{id:"free",label:c.camFree,icon:kv},{id:"iss",label:c.camFollow,icon:HA},{id:"cupola",label:c.camCupola,icon:$d},{id:"north",label:c.camNorth,icon:Jd},{id:"sun",label:c.camSun,icon:Jc}],p=[{key:"atmosphere",label:c.layerAtmosphere},{key:"clouds",label:c.layerClouds},{key:"orbit",label:c.layerOrbit},{key:"terminator",label:c.layerTerminator},{key:"cityLights",label:c.layerCityLights},{key:"laserNadir",label:c.layerLaserNadir}];return D.jsx("div",{style:{position:"absolute",bottom:"20px",left:"50%",transform:"translateX(-50%)",display:"flex",alignItems:"center",gap:"6px",zIndex:25,pointerEvents:"auto"},children:D.jsxs("div",{className:"glass-panel",style:{display:"flex",alignItems:"center",gap:"4px",padding:"5px 8px",borderRadius:"9999px",position:"relative"},children:[m.map(g=>{const _=g.icon,y=r===g.id;return D.jsxs("button",{onClick:()=>t(g.id),style:{display:"flex",alignItems:"center",gap:"6px",padding:"6px 12px",borderRadius:"9999px",border:"none",backgroundColor:y?"#0284c7":"transparent",color:y?"#ffffff":"#94a3b8",fontSize:"12px",fontWeight:y?600:500,cursor:"pointer",transition:"all 0.2s ease",boxShadow:y?"0 0 14px rgba(2, 132, 199, 0.6)":"none"},children:[D.jsx(_,{size:13,color:y?"#ffffff":"#38bdf8"}),D.jsx("span",{children:g.label})]},g.id)}),D.jsx("div",{style:{width:"1px",height:"16px",backgroundColor:"rgba(56, 189, 248, 0.2)",margin:"0 4px"}}),D.jsxs("div",{style:{position:"relative"},children:[D.jsxs("button",{onClick:()=>d(!h),style:{display:"flex",alignItems:"center",gap:"6px",padding:"6px 12px",borderRadius:"9999px",border:"none",backgroundColor:h?"rgba(56, 189, 248, 0.2)":"transparent",color:h?"#00e5ff":"#94a3b8",fontSize:"12px",fontWeight:500,cursor:"pointer",transition:"all 0.2s ease"},children:[D.jsx(vA,{size:13,color:h?"#00e5ff":"#38bdf8"}),D.jsx("span",{children:c.visualLayers})]}),h&&D.jsx("div",{className:"glass-panel",style:{position:"absolute",bottom:"46px",right:"0",width:"200px",padding:"8px",borderRadius:"12px",display:"flex",flexDirection:"column",gap:"4px",boxShadow:"0 12px 36px rgba(0,0,0,0.7)"},children:p.map(g=>{const _=i[g.key];return D.jsxs("button",{onClick:()=>s(g.key),style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"6px 10px",borderRadius:"8px",border:"none",backgroundColor:_?"rgba(0, 229, 255, 0.12)":"transparent",color:_?"#00e5ff":"#94a3b8",fontSize:"11px",fontWeight:500,cursor:"pointer",textAlign:"left"},children:[D.jsx("span",{children:g.label}),_&&D.jsx($2,{size:12,color:"#00e5ff"})]},g.key)})})]})]})})},ZA=({isOpen:r,onClose:t,crew:i,lang:s})=>{const l=Xr(s);return r?D.jsx("div",{style:{position:"fixed",inset:0,backgroundColor:"rgba(3, 7, 18, 0.75)",backdropFilter:"blur(8px)",zIndex:50,display:"flex",alignItems:"center",justifyContent:"center",padding:"20px"},onClick:t,children:D.jsxs("div",{className:"glass-panel",style:{width:"100%",maxWidth:"720px",maxHeight:"85vh",display:"flex",flexDirection:"column",borderRadius:"16px",overflow:"hidden",border:"1px solid rgba(56, 189, 248, 0.3)",boxShadow:"0 25px 50px -12px rgba(0, 0, 0, 0.85)"},onClick:c=>c.stopPropagation(),children:[D.jsxs("div",{style:{padding:"18px 24px",borderBottom:"1px solid rgba(56, 189, 248, 0.15)",display:"flex",alignItems:"center",justifyContent:"space-between",background:"linear-gradient(90deg, rgba(8, 20, 42, 0.9) 0%, rgba(12, 30, 60, 0.9) 100%)"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[D.jsx("div",{style:{width:"32px",height:"32px",borderRadius:"8px",backgroundColor:"rgba(0, 229, 255, 0.15)",display:"flex",alignItems:"center",justifyContent:"center",border:"1px solid rgba(0, 229, 255, 0.3)"},children:D.jsx(Vv,{size:16,color:"#00e5ff"})}),D.jsxs("div",{children:[D.jsxs("h2",{style:{fontSize:"16px",fontWeight:700,color:"#f8fafc",margin:0},children:[l.crewTitle," (",i.length,")"]}),D.jsx("p",{style:{fontSize:"11px",color:"#94a3b8",margin:"2px 0 0 0"},children:l.crewSubtitle})]})]}),D.jsx("button",{onClick:t,style:{background:"transparent",border:"none",color:"#94a3b8",cursor:"pointer",padding:"6px",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"},children:D.jsx(tp,{size:18})})]}),D.jsxs("div",{style:{padding:"20px 24px",overflowY:"auto",display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(300px, 1fr))",gap:"12px"},children:[i.length===0&&D.jsx("div",{style:{gridColumn:"1 / -1",textAlign:"center",padding:"40px 20px",color:"#94a3b8",fontSize:"13px"},children:D.jsx("div",{style:{color:"#00e5ff",marginBottom:"6px",fontWeight:600},children:s==="es"?"Sincronizando tripulación en órbita...":"Syncing astronauts in orbit..."})}),i.map((c,h)=>D.jsxs("div",{className:"glass-panel",style:{padding:"12px 14px",borderRadius:"12px",border:"1px solid rgba(56, 189, 248, 0.15)",display:"flex",alignItems:"center",gap:"12px",backgroundColor:"rgba(10, 24, 48, 0.5)"},children:[D.jsxs("div",{style:{width:"48px",height:"48px",borderRadius:"12px",backgroundColor:"rgba(15, 34, 68, 0.8)",border:"1px solid rgba(56, 189, 248, 0.3)",display:"flex",alignItems:"center",justifyContent:"center",position:"relative",flexShrink:0,overflow:"hidden"},children:[c.imageUrl?D.jsx("img",{src:c.imageUrl,alt:c.name,style:{width:"100%",height:"100%",objectFit:"cover"},onError:d=>{d.target.style.display="none"}}):D.jsx("span",{style:{fontSize:"22px"},children:c.flag}),D.jsx("span",{style:{position:"absolute",bottom:"1px",right:"2px",fontSize:"12px",filter:"drop-shadow(0 2px 4px rgba(0, 0, 0, 0.9))"},children:c.flag})]}),D.jsxs("div",{style:{flex:1,minWidth:0},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[D.jsx("h3",{style:{fontSize:"13px",fontWeight:600,color:"#f8fafc",margin:0,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},children:c.name}),D.jsx("span",{style:{fontSize:"10px",padding:"2px 6px",borderRadius:"4px",backgroundColor:"rgba(0, 229, 255, 0.12)",color:"#38bdf8",fontWeight:600},children:c.agency})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"11px",color:"#94a3b8",marginTop:"3px"},children:[D.jsx(zA,{size:11,color:"#38bdf8"}),D.jsx("span",{children:c.role})]}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"12px",marginTop:"6px",fontSize:"10px",color:"#64748b"},children:[D.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"3px"},children:[D.jsx(Hv,{size:10,color:"#64748b"})," ",c.craft]}),D.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"3px"},children:[D.jsx(rA,{size:10,color:"#64748b"})," ",c.daysInSpace," ",l.daysInSpace]})]})]})]},h))]})]})}):null},KA=({isOpen:r,onClose:t,hasPermission:i,onRequestLocation:s,lang:l})=>{const c=Xr(l);if(!r)return null;const h=new Date,d=[{id:"pass-1",startTime:new Date(h.getTime()+5.5*3600*1e3),maxElevationTime:new Date(h.getTime()+(5.5*3600+180)*1e3),endTime:new Date(h.getTime()+(5.5*3600+360)*1e3),durationSeconds:360,maxElevationDeg:78,apparentMagnitude:-3.4,startDirection:"SW",endDirection:"NE"},{id:"pass-2",startTime:new Date(h.getTime()+21.2*3600*1e3),maxElevationTime:new Date(h.getTime()+(21.2*3600+150)*1e3),endTime:new Date(h.getTime()+(21.2*3600+300)*1e3),durationSeconds:300,maxElevationDeg:54,apparentMagnitude:-2.8,startDirection:"WNW",endDirection:"SE"},{id:"pass-3",startTime:new Date(h.getTime()+29.8*3600*1e3),maxElevationTime:new Date(h.getTime()+(29.8*3600+210)*1e3),endTime:new Date(h.getTime()+(29.8*3600+420)*1e3),durationSeconds:420,maxElevationDeg:86,apparentMagnitude:-3.8,startDirection:"WSW",endDirection:"ENE"}],m=g=>g.toLocaleTimeString(l==="es"?"es-ES":"en-US",{hour:"2-digit",minute:"2-digit",second:"2-digit"}),p=g=>g.toLocaleDateString(l==="es"?"es-ES":"en-US",{weekday:"short",month:"short",day:"numeric"});return D.jsx("div",{style:{position:"fixed",inset:0,backgroundColor:"rgba(3, 7, 18, 0.75)",backdropFilter:"blur(8px)",zIndex:50,display:"flex",alignItems:"center",justifyContent:"center",padding:"20px"},onClick:t,children:D.jsxs("div",{className:"glass-panel",style:{width:"100%",maxWidth:"680px",maxHeight:"85vh",display:"flex",flexDirection:"column",borderRadius:"16px",overflow:"hidden",border:"1px solid rgba(56, 189, 248, 0.3)",boxShadow:"0 25px 50px -12px rgba(0, 0, 0, 0.85)"},onClick:g=>g.stopPropagation(),children:[D.jsxs("div",{style:{padding:"18px 24px",borderBottom:"1px solid rgba(56, 189, 248, 0.15)",display:"flex",alignItems:"center",justifyContent:"space-between",background:"linear-gradient(90deg, rgba(8, 20, 42, 0.9) 0%, rgba(12, 30, 60, 0.9) 100%)"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[D.jsx("div",{style:{width:"32px",height:"32px",borderRadius:"8px",backgroundColor:"rgba(0, 229, 255, 0.15)",display:"flex",alignItems:"center",justifyContent:"center",border:"1px solid rgba(0, 229, 255, 0.3)"},children:D.jsx(Iv,{size:16,color:"#00e5ff"})}),D.jsxs("div",{children:[D.jsx("h2",{style:{fontSize:"16px",fontWeight:700,color:"#f8fafc",margin:0},children:c.passesTitle}),D.jsx("p",{style:{fontSize:"11px",color:"#94a3b8",margin:"2px 0 0 0"},children:c.passesSubtitle})]})]}),D.jsx("button",{onClick:t,style:{background:"transparent",border:"none",color:"#94a3b8",cursor:"pointer",padding:"6px",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"},children:D.jsx(tp,{size:18})})]}),!i&&D.jsxs("div",{style:{padding:"10px 24px",backgroundColor:"rgba(250, 204, 21, 0.1)",borderBottom:"1px solid rgba(250, 204, 21, 0.2)",display:"flex",alignItems:"center",justifyContent:"space-between"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",fontSize:"11px",color:"#fef08a"},children:[D.jsx(Fv,{size:13,color:"#facc15"}),D.jsx("span",{children:c.permissionDenied})]}),D.jsx("button",{onClick:s,style:{padding:"4px 10px",borderRadius:"6px",border:"none",backgroundColor:"#facc15",color:"#0f172a",fontSize:"10px",fontWeight:700,cursor:"pointer"},children:c.requestLocation})]}),D.jsx("div",{style:{padding:"20px 24px",overflowY:"auto",display:"flex",flexDirection:"column",gap:"12px"},children:d.map(g=>D.jsxs("div",{className:"glass-panel",style:{padding:"14px 18px",borderRadius:"12px",border:"1px solid rgba(56, 189, 248, 0.15)",display:"grid",gridTemplateColumns:"1.4fr 1fr 1fr 1fr",alignItems:"center",gap:"12px",backgroundColor:"rgba(10, 24, 48, 0.5)"},children:[D.jsxs("div",{children:[D.jsx("div",{style:{fontSize:"11px",color:"#94a3b8",textTransform:"capitalize"},children:p(g.startTime)}),D.jsx("div",{className:"font-mono",style:{fontSize:"15px",fontWeight:700,color:"#f8fafc",marginTop:"2px"},children:m(g.startTime)})]}),D.jsxs("div",{children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"10px",color:"#94a3b8"},children:[D.jsx($d,{size:11,color:"#38bdf8"}),D.jsx("span",{children:c.passMaxElevation})]}),D.jsxs("div",{className:"font-mono",style:{fontSize:"14px",fontWeight:700,color:"#38bdf8",marginTop:"2px"},children:[g.maxElevationDeg,"° (Cénit)"]})]}),D.jsxs("div",{children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"10px",color:"#94a3b8"},children:[D.jsx(Gv,{size:11,color:"#facc15"}),D.jsx("span",{children:c.passBrightness})]}),D.jsxs("div",{className:"font-mono",style:{fontSize:"14px",fontWeight:700,color:"#facc15",marginTop:"2px"},children:[g.apparentMagnitude," mag"]})]}),D.jsxs("div",{children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"10px",color:"#94a3b8"},children:[D.jsx(Jd,{size:11,color:"#4ade80"}),D.jsx("span",{children:c.passTrajectory})]}),D.jsxs("div",{className:"font-mono",style:{fontSize:"13px",fontWeight:600,color:"#4ade80",marginTop:"2px"},children:[g.startDirection," → ",g.endDirection]})]})]},g.id))})]})})},QA=({isOpen:r,onClose:t,lang:i})=>{const s=Xr(i),[l,c]=ne.useState("minimap");return r?D.jsx("div",{style:{position:"fixed",inset:0,backgroundColor:"rgba(3, 7, 18, 0.78)",backdropFilter:"blur(12px)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:"16px"},onClick:t,children:D.jsxs("div",{className:"glass-panel",style:{width:"min(780px, 94vw)",maxHeight:"88vh",borderRadius:"16px",padding:"24px",display:"flex",flexDirection:"column",boxShadow:"0 25px 60px rgba(0, 0, 0, 0.85)",border:"1px solid rgba(56, 189, 248, 0.3)",overflow:"hidden"},onClick:h=>h.stopPropagation(),children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",borderBottom:"1px solid rgba(56, 189, 248, 0.15)",paddingBottom:"16px",marginBottom:"16px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[D.jsx("div",{style:{width:"36px",height:"36px",borderRadius:"8px",backgroundColor:"rgba(56, 189, 248, 0.15)",border:"1px solid rgba(56, 189, 248, 0.3)",display:"flex",alignItems:"center",justifyContent:"center",color:"#38bdf8"},children:D.jsx(Bv,{size:20})}),D.jsxs("div",{children:[D.jsx("h2",{style:{fontSize:"18px",fontWeight:700,color:"#f8fafc",margin:0},children:s.guideTitle}),D.jsx("p",{style:{fontSize:"12px",color:"#94a3b8",margin:"2px 0 0 0"},children:s.guideSubtitle})]})]}),D.jsx("button",{onClick:t,style:{background:"rgba(255, 255, 255, 0.05)",border:"1px solid rgba(255, 255, 255, 0.1)",borderRadius:"8px",padding:"6px",color:"#94a3b8",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"},children:D.jsx(tp,{size:18})})]}),D.jsxs("div",{style:{display:"flex",gap:"8px",marginBottom:"16px",borderBottom:"1px solid rgba(255, 255, 255, 0.08)",paddingBottom:"10px",overflowX:"auto"},children:[D.jsxs("button",{onClick:()=>c("minimap"),style:{background:l==="minimap"?"rgba(0, 229, 255, 0.15)":"transparent",border:`1px solid ${l==="minimap"?"rgba(0, 229, 255, 0.4)":"transparent"}`,borderRadius:"8px",color:l==="minimap"?"#00e5ff":"#94a3b8",padding:"6px 12px",fontSize:"12px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",whiteSpace:"nowrap"},children:[D.jsx(SA,{size:14}),D.jsx("span",{children:s.tabMinimap})]}),D.jsxs("button",{onClick:()=>c("solar"),style:{background:l==="solar"?"rgba(250, 204, 21, 0.15)":"transparent",border:`1px solid ${l==="solar"?"rgba(250, 204, 21, 0.4)":"transparent"}`,borderRadius:"8px",color:l==="solar"?"#facc15":"#94a3b8",padding:"6px 12px",fontSize:"12px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",whiteSpace:"nowrap"},children:[D.jsx(Jc,{size:14}),D.jsx("span",{children:s.tabSolarCycle})]}),D.jsxs("button",{onClick:()=>c("telemetry"),style:{background:l==="telemetry"?"rgba(74, 222, 128, 0.15)":"transparent",border:`1px solid ${l==="telemetry"?"rgba(74, 222, 128, 0.4)":"transparent"}`,borderRadius:"8px",color:l==="telemetry"?"#4ade80":"#94a3b8",padding:"6px 12px",fontSize:"12px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",whiteSpace:"nowrap"},children:[D.jsx(pA,{size:14}),D.jsx("span",{children:s.tabTelemetry})]}),D.jsxs("button",{onClick:()=>c("cameras"),style:{background:l==="cameras"?"rgba(168, 85, 247, 0.15)":"transparent",border:`1px solid ${l==="cameras"?"rgba(168, 85, 247, 0.4)":"transparent"}`,borderRadius:"8px",color:l==="cameras"?"#c084fc":"#94a3b8",padding:"6px 12px",fontSize:"12px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",whiteSpace:"nowrap"},children:[D.jsx(kv,{size:14}),D.jsx("span",{children:s.tabCameras})]})]}),D.jsxs("div",{style:{overflowY:"auto",flex:1,paddingRight:"4px"},children:[l==="minimap"&&D.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"14px"},children:[D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(56, 189, 248, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx("span",{style:{width:"10px",height:"3px",backgroundColor:"#00e5ff",borderRadius:"2px"}}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#00e5ff",margin:0},children:i==="es"?"Línea Cian Sólida y Flechas (Trayectoria Activa)":"Solid Cyan Line & Arrows (Active Path)"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"Representa los 45 minutos pasados (trayecto que la ISS acaba de recorrer) y los próximos 90 minutos futuros (una vuelta casi completa por delante). Las flechas cian señalan el sentido de avance en tiempo real.":"Represents the past 45 minutes of flight and the upcoming 90 minutes (nearly one full orbit ahead). The cyan arrows indicate flight direction in real time."})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(0, 229, 255, 0.25)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx("span",{style:{width:"12px",height:"2px",borderTop:"2px dashed #00e5ff"}}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#00e5ff",margin:0},children:i==="es"?"Línea Cian Discontinua (Próxima Órbita Futura)":"Cyan Dashed Line (Next Future Orbit)"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"Muestra la trayectoria que recorrerá la ISS en su siguiente vuelta (+90 a +180 min). Debido a la rotación de la Tierra hacia el este, cada nueva órbita sobre el suelo se desplaza unos 23° de longitud hacia el oeste.":"Shows the path the ISS will take on its next revolution (+90 to +180 min). Because the Earth rotates eastward, each new ground track shifts ~23° west."})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(249, 115, 22, 0.25)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx("span",{style:{width:"12px",height:"3px",backgroundColor:"#f97316",borderRadius:"2px"}}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#f97316",margin:0},children:i==="es"?"Línea Anaranjada Crepuscular (Terminador Solar)":"Orange Twilight Line (Solar Terminator)"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"Delimita la frontera viva entre el día y la noche terrestre (zonas de amanecer y atardecer), reflejando la misma franja crepuscular ámbar/dorada visible en el globo 3D.":"Marks the active boundary between day and night on Earth (sunrise and sunset zones), mirroring the same golden-amber twilight glow seen on the 3D globe."})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(74, 222, 128, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx("span",{style:{width:"8px",height:"8px",borderRadius:"50%",border:"1.5px solid #4ade80"}}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#4ade80",margin:0},children:i==="es"?"Círculo Verde de Cobertura (Horizonte Visual)":"Green Coverage Ring (Visual Horizon)"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"Delimita el área geográfica de ~2.200 km de radio sobre la superficie terrestre donde los observadores pueden ver la ISS en el cielo (siempre que coincida con noche o crepúsculo).":"Defines the ~2,200 km radius geographical footprint on Earth where observers can see the ISS in the sky during night or twilight."})]})]}),l==="solar"&&D.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"14px"},children:[D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(250, 204, 21, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx(Jc,{size:15,color:"#facc15"}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#facc15",margin:0},children:i==="es"?"Punto Subsolar (Sol en el Mapa)":"Subsolar Point (Sun on the Map)"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"El icono del Sol indica las coordenadas exactas de la Tierra donde los rayos solares caen 100% verticales (cenit a 90°), es decir, donde es exactamente el mediodía solar en ese instante.":"The Sun icon marks the exact coordinates on Earth receiving perpendicular sunlight (90° zenith), indicating solar noon at that instant."})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(249, 115, 22, 0.25)",borderRadius:"10px",padding:"14px"},children:[D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"6px"},children:[D.jsx(Gv,{size:15,color:"#f97316"}),D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#f97316",margin:0},children:i==="es"?"Terminador Solar y Franja Crepuscular Anaranjada":"Solar Terminator & Orange Twilight Band"})]}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"La línea anaranjada curvada separa el día de la noche y marca las zonas crepusculares de amanecer y atardecer. La ISS completa una vuelta cada 92.7 minutos, por lo que los astronautas experimentan 16 puestas de sol y 16 amaneceres cada 24 horas (~45 min de luz y ~45 min de sombra).":"The curved orange line marks the boundary between day and night (twilight sunrise and sunset zones). With a 92.7-minute orbit, astronauts experience 16 sunsets and 16 sunrises every 24 hours (~45 min of sunlight and ~45 min of orbital darkness)."})]})]}),l==="telemetry"&&D.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"14px"},children:[D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(56, 189, 248, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#38bdf8",marginBottom:"6px"},children:i==="es"?"Órbita LEO (Low Earth Orbit)":"LEO Orbit (Low Earth Orbit)"}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"La estación orbita a unos 420 km de altitud media. Para mantenerse en órbita sin caer ni escapar al espacio profundo, debe volar a 27.600 km/h (aproximadamente Mach 22.5 o 7.66 km por segundo).":"The station orbits at ~420 km altitude. To remain in orbit, it maintains a speed of 27,600 km/h (~Mach 22.5 or 7.66 km per second)."})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(74, 222, 128, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#4ade80",marginBottom:"6px"},children:i==="es"?"Distancia a tu Ubicación":"Distance to Your Location"}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?"Calcula en tiempo real la distancia euclidiana tridimensional en línea recta entre tus coordenadas GPS y la posición orbital de la estación en el espacio.":"Calculates the real-time 3D straight-line distance between your device GPS coordinates and the space station in orbit."})]})]}),l==="cameras"&&D.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"14px"},children:[D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(168, 85, 247, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#c084fc",marginBottom:"6px"},children:i==="es"?"Modos de Cámara Cinemática":"Cinematic Camera Modes"}),D.jsxs("ul",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.7",margin:0,paddingLeft:"18px"},children:[D.jsxs("li",{children:[D.jsxs("strong",{children:[s.camFree,":"]})," ",i==="es"?"Gira con el botón izquierdo y haz zoom con la rueda del ratón.":"Rotate with left-click and zoom with mouse wheel."]}),D.jsxs("li",{children:[D.jsxs("strong",{children:[s.camFollow,":"]})," ",i==="es"?"Fija la cámara detrás de la ISS para acompañar su vuelo en órbita.":"Locks camera behind the ISS to follow its orbital flight."]}),D.jsxs("li",{children:[D.jsxs("strong",{children:[s.camCupola,":"]})," ",i==="es"?"Perspectiva Nadir mirando directamente hacia abajo hacia la superficie de la Tierra.":"Nadir view looking straight down at the Earth."]}),D.jsxs("li",{children:[D.jsxs("strong",{children:[s.camNorth," / ",s.camSun,":"]})," ",i==="es"?"Perspectiva polar o alineada con la dirección de los rayos solares.":"Polar view or aligned with incoming sunlight."]})]})]}),D.jsxs("div",{style:{backgroundColor:"rgba(8, 20, 42, 0.6)",border:"1px solid rgba(56, 189, 248, 0.2)",borderRadius:"10px",padding:"14px"},children:[D.jsx("h3",{style:{fontSize:"13px",fontWeight:700,color:"#38bdf8",marginBottom:"6px"},children:i==="es"?"Capas Visuales":"Visual Layers"}),D.jsx("p",{style:{fontSize:"12px",color:"#cbd5e1",lineHeight:"1.6",margin:0},children:i==="es"?'En el menú "Capas Visuales" de la barra inferior puedes encender o apagar la atmósfera, las nubes dinámicas, las luces de ciudades nocturnas, el terminador y el haz láser Nadir.':'The "Visual Layers" menu on the bottom toolbar allows you to toggle atmosphere, dynamic clouds, night city lights, solar terminator, and the Nadir laser beam.'})]})]})]})]})}):null},JA=({telemetry:r,lang:t})=>{const[i,s]=ne.useState(!1);return D.jsx("div",{className:"mobile-sheet-container",style:{display:"none"},children:D.jsxs("div",{className:"glass-panel",style:{position:"fixed",bottom:0,left:0,right:0,borderTopLeftRadius:"20px",borderTopRightRadius:"20px",borderBottomLeftRadius:0,borderBottomRightRadius:0,borderBottom:"none",padding:"12px 16px 24px 16px",zIndex:40,transform:i?"translateY(0)":"translateY(calc(100% - 48px))",transition:"transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)"},children:[D.jsxs("div",{onClick:()=>s(!i),style:{display:"flex",flexDirection:"column",alignItems:"center",cursor:"pointer",paddingBottom:"8px"},children:[D.jsx("div",{style:{width:"36px",height:"4px",backgroundColor:"rgba(56, 189, 248, 0.4)",borderRadius:"2px",marginBottom:"6px"}}),D.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"11px",color:"#38bdf8",fontWeight:600},children:[D.jsx("span",{children:i?"Ocultar Telemetría":"Ver Telemetría Completa"}),i?D.jsx(eA,{size:14}):D.jsx(iA,{size:14})]})]}),D.jsx("div",{style:{marginTop:"12px"},children:D.jsx(jv,{telemetry:r,lang:t})})]})})},$A="https://api.wheretheiss.at/v1/satellites/25544";let Ic=null,J_=Date.now();async function tR(){try{const r=new AbortController,t=setTimeout(()=>r.abort(),4e3),i=await fetch($A,{signal:r.signal,headers:{Accept:"application/json"}});if(clearTimeout(t),!i.ok)throw new Error(`ISS API returned status ${i.status}`);const s=await i.json();return Ic=s,J_=Date.now(),s}catch(r){if(console.warn("Could not fetch live ISS data from API, using dead-reckoning extrapolation:",r),Ic){const i=(Date.now()-J_)/1e3,s=360/(92.68*60),l=(Ic.longitude+s*i+180)%360-180,c=51.64*Math.PI/180,h=l*Math.PI/180,d=c*180/Math.PI*Math.sin(h);return{...Ic,latitude:d,longitude:l,timestamp:Math.floor(Date.now()/1e3)}}return{name:"iss",id:25544,latitude:6.724,longitude:-140.032,altitude:420.4,velocity:27575,visibility:"daylight",footprint:4512.8,timestamp:Math.floor(Date.now()/1e3),daynum:246e4,solar_lat:12.5,solar_lon:-15.2,units:"kilometers"}}}const eR=[{nameEs:"Sobre Océano Pacífico Norte",nameEn:"Over North Pacific Ocean",minLat:0,maxLat:66,minLon:-180,maxLon:-100},{nameEs:"Sobre Océano Pacífico Norte",nameEn:"Over North Pacific Ocean",minLat:0,maxLat:66,minLon:120,maxLon:180},{nameEs:"Sobre Océano Pacífico Sur",nameEn:"Over South Pacific Ocean",minLat:-66,maxLat:0,minLon:-180,maxLon:-70},{nameEs:"Sobre Océano Pacífico Sur",nameEn:"Over South Pacific Ocean",minLat:-66,maxLat:0,minLon:145,maxLon:180},{nameEs:"Sobre Océano Atlántico Norte",nameEn:"Over North Atlantic Ocean",minLat:0,maxLat:66,minLon:-80,maxLon:-10},{nameEs:"Sobre Océano Atlántico Sur",nameEn:"Over South Atlantic Ocean",minLat:-66,maxLat:0,minLon:-70,maxLon:20},{nameEs:"Sobre Océano Índico",nameEn:"Over Indian Ocean",minLat:-66,maxLat:30,minLon:20,maxLon:110},{nameEs:"Sobre Mar de Coral",nameEn:"Over Coral Sea",minLat:-30,maxLat:-10,minLon:142,maxLon:165},{nameEs:"Sobre Mar de Tasmania",nameEn:"Over Tasman Sea",minLat:-50,maxLat:-30,minLon:145,maxLon:175},{nameEs:"Sobre Mar de Filipinas",nameEn:"Over Philippine Sea",minLat:5,maxLat:25,minLon:125,maxLon:145},{nameEs:"Sobre Mar Arábigo",nameEn:"Over Arabian Sea",minLat:10,maxLat:25,minLon:55,maxLon:75},{nameEs:"Sobre Mar Caribe",nameEn:"Over Caribbean Sea",minLat:9,maxLat:22,minLon:-88,maxLon:-60},{nameEs:"Sobre Mar Mediterráneo",nameEn:"Over Mediterranean Sea",minLat:30,maxLat:45,minLon:-5,maxLon:36},{nameEs:"Sobre América del Norte (EE.UU.)",nameEn:"Over North America (USA)",minLat:25,maxLat:49,minLon:-125,maxLon:-70},{nameEs:"Sobre América del Norte (Canadá)",nameEn:"Over North America (Canada)",minLat:49,maxLat:60,minLon:-140,maxLon:-55},{nameEs:"Sobre América del Norte (México)",nameEn:"Over North America (Mexico)",minLat:14,maxLat:32,minLon:-118,maxLon:-86},{nameEs:"Sobre América del Sur (Brasil)",nameEn:"Over South America (Brazil)",minLat:-33,maxLat:5,minLon:-73,maxLon:-34},{nameEs:"Sobre América del Sur (Argentina / Chile)",nameEn:"Over South America (Argentina / Chile)",minLat:-55,maxLat:-22,minLon:-75,maxLon:-53},{nameEs:"Sobre América del Sur (Colombia / Perú)",nameEn:"Over South America (Andean Region)",minLat:-18,maxLat:12,minLon:-81,maxLon:-68},{nameEs:"Sobre Europa Occidental (España / Francia)",nameEn:"Over Western Europe",minLat:36,maxLat:51,minLon:-9,maxLon:10},{nameEs:"Sobre Europa Central",nameEn:"Over Central Europe",minLat:45,maxLat:55,minLon:6,maxLon:25},{nameEs:"Sobre Europa Oriental / Rusia",nameEn:"Over Eastern Europe / Russia",minLat:45,maxLat:56,minLon:25,maxLon:60},{nameEs:"Sobre África del Norte (Sáhara)",nameEn:"Over North Africa (Sahara)",minLat:18,maxLat:37,minLon:-17,maxLon:35},{nameEs:"Sobre África Central",nameEn:"Over Central Africa",minLat:-10,maxLat:18,minLon:8,maxLon:45},{nameEs:"Sobre África del Sur",nameEn:"Over Southern Africa",minLat:-35,maxLat:-10,minLon:12,maxLon:40},{nameEs:"Sobre Oriente Medio",nameEn:"Over Middle East",minLat:15,maxLat:38,minLon:35,maxLon:60},{nameEs:"Sobre Asia del Sur (India)",nameEn:"Over South Asia (India)",minLat:8,maxLat:35,minLon:68,maxLon:90},{nameEs:"Sobre Asia Oriental (China / Japón)",nameEn:"Over East Asia (China / Japan)",minLat:20,maxLat:50,minLon:95,maxLon:145},{nameEs:"Sobre Sudeste Asiático (Indonesia)",nameEn:"Over Southeast Asia (Indonesia)",minLat:-11,maxLat:6,minLon:95,maxLon:141},{nameEs:"Sobre Oceanía (Australia)",nameEn:"Over Oceania (Australia)",minLat:-44,maxLat:-10,minLon:112,maxLon:154},{nameEs:"Sobre Oceanía (Nueva Zelanda)",nameEn:"Over Oceania (New Zealand)",minLat:-47,maxLat:-34,minLon:166,maxLon:178}];function nR(r,t,i="es"){const s=(t+180)%360-180;for(const l of eR)if(r>=l.minLat&&r<=l.maxLat&&s>=l.minLon&&s<=l.maxLon)return i==="es"?l.nameEs:l.nameEn;return r>0?s<-30&&s>-140?i==="es"?"Sobre Océano Pacífico Norte":"Over North Pacific Ocean":i==="es"?"Sobre Océano Atlántico Norte":"Over North Atlantic Ocean":s>20&&s<110?i==="es"?"Sobre Océano Índico":"Over Indian Ocean":s<-70||s>140?i==="es"?"Sobre Océano Pacífico Sur":"Over South Pacific Ocean":i==="es"?"Sobre Océano Atlántico Sur":"Over South Atlantic Ocean"}function iR(r,t="es"){const[i,s]=ne.useState({latitude:6.724,longitude:-140.032,altitudeKm:420.4,altitudeMi:261.2,velocityKmH:27575,velocityMph:17134,mach:22.3,headingDeg:51.6,isSunlit:!0,sunEventName:"sunset",sunEventCountdownMinutes:1,locationName:t==="es"?"Sobre Océano Pacífico Norte":"Over North Pacific Ocean",distanceToUserKm:null,timestamp:Date.now()}),[l,c]=ne.useState(null),h=ne.useRef(null);return ne.useEffect(()=>{let d=!0;const m=async()=>{try{const g=await tR();if(!d)return;c(g);let _=51.6;if(h.current){const I=g.longitude-h.current.lon,j=g.latitude-h.current.lat;_=(Math.atan2(I,j)*180/Math.PI+360)%360}h.current={lat:g.latitude,lon:g.longitude};const y=Math.round(g.velocity),v=Math.round(g.velocity*.621371),b=Number((g.velocity/1234.8).toFixed(1)),E=Number(g.altitude.toFixed(1)),M=Number((g.altitude*.621371).toFixed(1)),x=Pv(g.latitude,g.longitude),P=j2(g.latitude,g.longitude,_,x),N=P.eventName,w=P.countdownMinutes,k=nR(g.latitude,g.longitude,t);let H=null;r&&(H=G2(r.latitude,r.longitude,g.latitude,g.longitude,E)),s({latitude:g.latitude,longitude:g.longitude,altitudeKm:E,altitudeMi:M,velocityKmH:y,velocityMph:v,mach:b,headingDeg:_,isSunlit:x,sunEventName:N,sunEventCountdownMinutes:w,locationName:k,distanceToUserKm:H,timestamp:g.timestamp*1e3})}catch(g){console.error("Telemetry update error:",g)}};m();const p=setInterval(m,1500);return()=>{d=!1,clearInterval(p)}},[r,t]),{telemetry:i,rawISS:l}}function aR(){const[r,t]=ne.useState(null),[i,s]=ne.useState(!1),[l,c]=ne.useState(!0),h=()=>{if(!navigator.geolocation){t(null),s(!1),c(!1);return}navigator.geolocation.getCurrentPosition(d=>{t({latitude:d.coords.latitude,longitude:d.coords.longitude}),s(!0),c(!1)},d=>{console.warn("Geolocation permission not granted or unavailable:",d.message),t(null),s(!1),c(!1)},{enableHighAccuracy:!0,timeout:6e3})};return ne.useEffect(()=>{h()},[]),{coords:r,hasPermission:i,loading:l,requestPosition:h}}function sR(r){if(!r)return 0;const t=r.match(/P(?:(\d+)D)?/);return t&&t[1]?parseInt(t[1],10):0}function rR(r,t){const i=(r||"").toLowerCase(),s=(t||"").toUpperCase();return s==="USA"||i.includes("american")||i.includes("united states")?"🇺🇸":s==="RUS"||i.includes("russian")||i.includes("russia")?"🇷🇺":s==="FRA"||i.includes("french")||i.includes("france")?"🇫🇷":s==="DEU"||i.includes("german")||i.includes("germany")?"🇩🇪":s==="ITA"||i.includes("italian")||i.includes("italy")?"🇮🇹":s==="JPN"||i.includes("japanese")||i.includes("japan")?"🇯🇵":s==="CAN"||i.includes("canadian")||i.includes("canada")?"🇨🇦":s==="CHN"||i.includes("chinese")||i.includes("china")?"🇨🇳":s==="GBR"||i.includes("british")||i.includes("uk")?"🇬🇧":"🌐"}function oR(){const[r,t]=ne.useState([]),[i,s]=ne.useState(!0);return ne.useEffect(()=>{let l=!0;return(async()=>{try{s(!0);const h=sessionStorage.getItem("iss_live_crew_only_cache");if(h){const p=JSON.parse(h);Array.isArray(p)&&p.length>0&&l&&(t(p),s(!1))}const d=await fetch("https://ll.thespacedevs.com/2.2.0/astronaut/?in_space=true&limit=30",{signal:AbortSignal.timeout(6e3)});if(!d.ok)throw new Error(`HTTP ${d.status}`);const m=await d.json();if(m&&Array.isArray(m.results)&&l){const g=m.results.filter(_=>{var E,M,x;const y=(((E=_.agency)==null?void 0:E.abbrev)||"").toUpperCase(),v=(((M=_.agency)==null?void 0:M.name)||"").toLowerCase(),b=(_.name||"").toLowerCase();return!(((x=_.type)==null?void 0:x.name)==="Non-Human"||b.includes("starman")||b.includes("dummy")||y==="CNSA"||v.includes("china"))}).map((_,y)=>{var x,P,N,w;const v=((x=_.agency)==null?void 0:x.abbrev)||((P=_.agency)==null?void 0:P.name)||"NASA",b=rR(_.nationality,(N=_.agency)==null?void 0:N.country_code),E=sR(_.time_in_space),M=_.profile_image_thumbnail||_.profile_image||void 0;return{name:_.name,craft:"ISS",agency:v,role:y===0?"Comandante de Misión":"Especialista / Ingeniero de Vuelo",country:_.nationality||((w=_.agency)==null?void 0:w.country_code)||"Internacional",flag:b,daysInSpace:E,imageUrl:M}});g.length>0&&(t(g),sessionStorage.setItem("iss_live_crew_only_cache",JSON.stringify(g)))}}catch(h){console.warn("Live ISS astronaut API fallback:",h)}finally{l&&s(!1)}})(),()=>{l=!1}},[]),{crew:r,count:r.length,loading:i}}const lR=()=>{const[r,t]=ne.useState("es"),[i,s]=ne.useState("free"),[l,c]=ne.useState(!1),[h,d]=ne.useState(!1),[m,p]=ne.useState(!1),[g,_]=ne.useState({atmosphere:!0,clouds:!0,orbit:!0,terminator:!0,cityLights:!0,laserNadir:!0}),{coords:y,hasPermission:v,requestPosition:b}=aR(),{telemetry:E}=iR(y,r),{crew:M,count:x}=oR(),P=()=>{t(w=>w==="es"?"en":"es")},N=w=>{_(k=>({...k,[w]:!k[w]}))};return D.jsxs("main",{style:{width:"100vw",height:"100vh",position:"relative",overflow:"hidden",backgroundColor:"#030712"},children:[D.jsx(X2,{telemetry:E,cameraMode:i,layers:g}),D.jsx(qA,{lang:r,onToggleLang:P,onOpenCrew:()=>c(!0),onOpenPasses:()=>d(!0),onOpenGuide:()=>p(!0),crewCount:x}),D.jsx("div",{className:"desktop-telemetry",children:D.jsx(jv,{telemetry:E,lang:r})}),D.jsx(XA,{telemetry:E,userCoords:y,layers:g,lang:r}),D.jsx(YA,{activeMode:i,onSelectMode:s,layers:g,onToggleLayer:N,lang:r}),D.jsx(JA,{telemetry:E,lang:r}),D.jsx(QA,{isOpen:m,onClose:()=>p(!1),lang:r}),D.jsx(ZA,{isOpen:l,onClose:()=>c(!1),crew:M,lang:r}),D.jsx(KA,{isOpen:h,onClose:()=>d(!1),userCoords:y,hasPermission:v,onRequestLocation:b,lang:r})]})};oS.createRoot(document.getElementById("root")).render(D.jsx($y.StrictMode,{children:D.jsx(lR,{})}));
